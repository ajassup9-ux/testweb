const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbinenc0293", "binenc", 293)];
