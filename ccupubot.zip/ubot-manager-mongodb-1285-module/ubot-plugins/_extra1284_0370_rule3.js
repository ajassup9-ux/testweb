const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30370", "rule3", 370)];
