const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xhexdec0052", "hexdec", 52)];
