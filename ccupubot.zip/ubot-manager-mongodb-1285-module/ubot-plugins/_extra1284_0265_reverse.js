const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xreverse0265", "reverse", 265)];
