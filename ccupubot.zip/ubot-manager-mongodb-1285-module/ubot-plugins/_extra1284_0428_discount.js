const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdiscount0428", "discount", 428)];
