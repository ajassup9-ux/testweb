const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsum0241", "sum", 241)];
