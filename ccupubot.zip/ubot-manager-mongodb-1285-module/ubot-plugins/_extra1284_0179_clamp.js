const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xclamp0179", "clamp", 179)];
