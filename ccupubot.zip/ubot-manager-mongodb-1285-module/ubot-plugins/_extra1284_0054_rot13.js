const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130054", "rot13", 54)];
