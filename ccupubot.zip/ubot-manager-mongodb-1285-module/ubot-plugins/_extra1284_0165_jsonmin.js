const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonmin0165", "jsonmin", 165)];
