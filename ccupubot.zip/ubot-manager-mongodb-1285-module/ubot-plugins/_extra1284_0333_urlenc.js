const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurlenc0333", "urlenc", 333)];
