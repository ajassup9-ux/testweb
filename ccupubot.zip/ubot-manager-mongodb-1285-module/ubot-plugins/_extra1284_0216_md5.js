const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmd50216", "md5", 216)];
