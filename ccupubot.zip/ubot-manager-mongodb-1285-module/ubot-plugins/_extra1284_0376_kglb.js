const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkglb0376", "kglb", 376)];
