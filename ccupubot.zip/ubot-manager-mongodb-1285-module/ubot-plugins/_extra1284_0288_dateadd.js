const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdateadd0288", "dateadd", 288)];
