const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbmi0431", "bmi", 431)];
