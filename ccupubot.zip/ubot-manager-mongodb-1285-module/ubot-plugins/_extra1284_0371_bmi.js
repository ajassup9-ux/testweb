const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbmi0371", "bmi", 371)];
