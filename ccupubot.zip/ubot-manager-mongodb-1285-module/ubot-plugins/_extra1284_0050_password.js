const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpassword0050", "password", 50)];
