const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurlenc0153", "urlenc", 153)];
