const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcamel0450", "camel", 450)];
