const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsum0301", "sum", 301)];
