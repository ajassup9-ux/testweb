const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlcm0058", "lcm", 58)];
