const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrandom0440", "random", 440)];
