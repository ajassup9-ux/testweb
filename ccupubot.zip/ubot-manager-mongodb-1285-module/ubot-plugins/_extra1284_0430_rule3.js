const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30430", "rule3", 430)];
