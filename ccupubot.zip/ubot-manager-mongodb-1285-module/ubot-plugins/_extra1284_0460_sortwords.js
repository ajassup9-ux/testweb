const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortwords0460", "sortwords", 460)];
