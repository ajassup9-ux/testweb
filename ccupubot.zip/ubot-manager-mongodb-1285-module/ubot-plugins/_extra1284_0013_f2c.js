const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xf2c0013", "f2c", 13)];
