const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmin0123", "min", 123)];
