const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlbkg0257", "lbkg", 257)];
