const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdateadd0168", "dateadd", 168)];
