const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcompound0296", "compound", 296)];
