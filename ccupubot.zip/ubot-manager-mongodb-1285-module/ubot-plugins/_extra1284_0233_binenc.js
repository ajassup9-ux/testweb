const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbinenc0233", "binenc", 233)];
