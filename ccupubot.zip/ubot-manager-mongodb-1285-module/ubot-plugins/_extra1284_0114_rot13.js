const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130114", "rot13", 114)];
