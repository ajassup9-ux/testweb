const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560395", "sha256", 395)];
