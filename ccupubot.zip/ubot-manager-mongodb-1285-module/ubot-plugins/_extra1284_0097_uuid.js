const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xuuid0097", "uuid", 97)];
