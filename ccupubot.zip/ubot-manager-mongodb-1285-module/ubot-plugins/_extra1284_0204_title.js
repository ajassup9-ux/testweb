const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtitle0204", "title", 204)];
