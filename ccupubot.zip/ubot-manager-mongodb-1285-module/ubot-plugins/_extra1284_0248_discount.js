const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdiscount0248", "discount", 248)];
