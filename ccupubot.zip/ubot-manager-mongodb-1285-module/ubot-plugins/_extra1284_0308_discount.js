const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdiscount0308", "discount", 308)];
