const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmarkup0009", "markup", 9)];
