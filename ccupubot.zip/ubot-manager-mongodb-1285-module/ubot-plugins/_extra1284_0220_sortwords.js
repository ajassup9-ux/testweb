const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortwords0220", "sortwords", 220)];
