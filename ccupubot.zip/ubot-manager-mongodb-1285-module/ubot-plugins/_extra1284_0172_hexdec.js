const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xhexdec0172", "hexdec", 172)];
