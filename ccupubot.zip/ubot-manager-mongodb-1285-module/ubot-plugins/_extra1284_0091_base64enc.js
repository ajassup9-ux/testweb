const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbase64enc0091", "base64enc", 91)];
