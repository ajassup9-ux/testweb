const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xgcd0177", "gcd", 177)];
