const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurlenc0033", "urlenc", 33)];
