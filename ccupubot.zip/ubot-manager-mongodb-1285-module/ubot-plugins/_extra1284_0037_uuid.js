const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xuuid0037", "uuid", 37)];
