const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcamel0090", "camel", 90)];
