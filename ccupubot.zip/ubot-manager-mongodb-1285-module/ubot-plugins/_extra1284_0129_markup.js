const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmarkup0129", "markup", 129)];
