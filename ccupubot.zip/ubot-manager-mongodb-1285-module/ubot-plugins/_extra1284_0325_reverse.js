const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xreverse0325", "reverse", 325)];
