const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xhexenc0231", "hexenc", 231)];
