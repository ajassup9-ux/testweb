const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xage0169", "age", 169)];
