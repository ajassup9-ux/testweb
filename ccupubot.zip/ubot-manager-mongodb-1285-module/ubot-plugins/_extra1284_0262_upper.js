const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xupper0262", "upper", 262)];
