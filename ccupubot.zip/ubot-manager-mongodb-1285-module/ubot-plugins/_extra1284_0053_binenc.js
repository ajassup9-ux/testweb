const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbinenc0053", "binenc", 53)];
