const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpassword0470", "password", 470)];
