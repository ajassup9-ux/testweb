const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlcm0298", "lcm", 298)];
