const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30070", "rule3", 70)];
