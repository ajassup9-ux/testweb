const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xuniquewords0101", "uniquewords", 101)];
