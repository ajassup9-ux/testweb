const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtitle0024", "title", 24)];
