const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560455", "sha256", 455)];
