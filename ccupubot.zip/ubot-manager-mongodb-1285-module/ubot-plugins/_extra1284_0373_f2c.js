const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xf2c0373", "f2c", 373)];
