const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurldec0454", "urldec", 454)];
