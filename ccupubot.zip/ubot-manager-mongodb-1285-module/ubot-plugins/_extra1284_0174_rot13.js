const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130174", "rot13", 174)];
