const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpadleft0463", "padleft", 463)];
