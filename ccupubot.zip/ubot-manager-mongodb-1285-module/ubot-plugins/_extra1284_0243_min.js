const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmin0243", "min", 243)];
