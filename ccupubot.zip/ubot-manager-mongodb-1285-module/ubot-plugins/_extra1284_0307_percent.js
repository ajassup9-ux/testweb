const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpercent0307", "percent", 307)];
