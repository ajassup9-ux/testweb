const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtrim0098", "trim", 98)];
