const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xceil0360", "ceil", 360)];
