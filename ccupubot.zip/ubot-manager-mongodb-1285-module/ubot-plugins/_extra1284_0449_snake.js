const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsnake0449", "snake", 449)];
