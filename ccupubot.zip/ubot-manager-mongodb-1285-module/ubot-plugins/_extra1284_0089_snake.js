const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsnake0089", "snake", 89)];
