const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcount0326", "count", 326)];
