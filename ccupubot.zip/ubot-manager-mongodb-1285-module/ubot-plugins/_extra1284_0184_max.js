const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmax0184", "max", 184)];
