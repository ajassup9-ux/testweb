const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonpretty0106", "jsonpretty", 106)];
