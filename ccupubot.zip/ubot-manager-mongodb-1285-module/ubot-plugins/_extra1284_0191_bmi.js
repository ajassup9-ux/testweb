const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbmi0191", "bmi", 191)];
