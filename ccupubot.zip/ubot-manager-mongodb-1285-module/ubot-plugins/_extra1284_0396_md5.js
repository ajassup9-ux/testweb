const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmd50396", "md5", 396)];
