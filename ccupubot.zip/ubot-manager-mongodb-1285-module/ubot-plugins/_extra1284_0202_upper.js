const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xupper0202", "upper", 202)];
