const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonpretty0466", "jsonpretty", 466)];
