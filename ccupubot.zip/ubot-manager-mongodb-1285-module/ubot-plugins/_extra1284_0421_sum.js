const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsum0421", "sum", 421)];
