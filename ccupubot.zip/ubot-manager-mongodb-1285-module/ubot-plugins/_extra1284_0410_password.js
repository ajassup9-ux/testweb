const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpassword0410", "password", 410)];
