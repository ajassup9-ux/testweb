const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xupper0322", "upper", 322)];
