const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmd50276", "md5", 276)];
