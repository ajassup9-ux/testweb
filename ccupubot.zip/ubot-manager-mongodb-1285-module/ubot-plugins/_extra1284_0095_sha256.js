const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560095", "sha256", 95)];
