const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpadright0344", "padright", 344)];
