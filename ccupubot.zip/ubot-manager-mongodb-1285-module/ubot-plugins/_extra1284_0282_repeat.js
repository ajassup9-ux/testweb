const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrepeat0282", "repeat", 282)];
