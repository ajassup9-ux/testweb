const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xvat0295", "vat", 295)];
