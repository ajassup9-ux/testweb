const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbmi0311", "bmi", 311)];
