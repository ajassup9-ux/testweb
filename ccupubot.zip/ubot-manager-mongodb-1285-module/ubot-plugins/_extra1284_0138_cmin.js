const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcmin0138", "cmin", 138)];
