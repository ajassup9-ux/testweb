const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkglb0436", "kglb", 436)];
