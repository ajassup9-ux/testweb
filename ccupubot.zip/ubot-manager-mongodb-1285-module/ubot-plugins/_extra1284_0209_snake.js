const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsnake0209", "snake", 209)];
