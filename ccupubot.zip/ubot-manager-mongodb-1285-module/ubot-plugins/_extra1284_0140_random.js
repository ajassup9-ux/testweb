const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrandom0140", "random", 140)];
