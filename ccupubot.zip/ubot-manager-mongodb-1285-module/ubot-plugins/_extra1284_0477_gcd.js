const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xgcd0477", "gcd", 477)];
