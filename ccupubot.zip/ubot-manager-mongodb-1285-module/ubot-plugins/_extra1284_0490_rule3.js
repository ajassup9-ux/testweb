const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30490", "rule3", 490)];
