const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonmin0045", "jsonmin", 45)];
