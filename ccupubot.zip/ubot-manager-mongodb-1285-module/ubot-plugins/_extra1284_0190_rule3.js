const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30190", "rule3", 190)];
