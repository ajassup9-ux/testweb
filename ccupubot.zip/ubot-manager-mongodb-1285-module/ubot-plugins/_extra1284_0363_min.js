const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmin0363", "min", 363)];
