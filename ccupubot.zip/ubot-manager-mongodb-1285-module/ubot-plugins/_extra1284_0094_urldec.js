const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurldec0094", "urldec", 94)];
