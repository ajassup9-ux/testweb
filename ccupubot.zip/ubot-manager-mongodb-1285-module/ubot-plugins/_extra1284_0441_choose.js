const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xchoose0441", "choose", 441)];
