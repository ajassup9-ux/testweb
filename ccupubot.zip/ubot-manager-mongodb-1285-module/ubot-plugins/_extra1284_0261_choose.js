const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xchoose0261", "choose", 261)];
