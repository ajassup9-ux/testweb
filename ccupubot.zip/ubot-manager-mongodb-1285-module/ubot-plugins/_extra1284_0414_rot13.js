const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130414", "rot13", 414)];
