const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbase64enc0451", "base64enc", 451)];
