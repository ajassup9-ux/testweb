const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xreverse0385", "reverse", 385)];
