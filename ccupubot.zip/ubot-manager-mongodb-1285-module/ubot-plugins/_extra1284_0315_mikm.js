const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmikm0315", "mikm", 315)];
