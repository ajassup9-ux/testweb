const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcount0386", "count", 386)];
