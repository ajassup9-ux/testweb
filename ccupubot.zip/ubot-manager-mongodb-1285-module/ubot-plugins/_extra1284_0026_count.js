const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcount0026", "count", 26)];
