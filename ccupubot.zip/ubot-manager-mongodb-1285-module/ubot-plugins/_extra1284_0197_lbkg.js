const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlbkg0197", "lbkg", 197)];
