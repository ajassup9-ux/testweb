const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcamel0210", "camel", 210)];
