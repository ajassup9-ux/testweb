const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xuniquewords0341", "uniquewords", 341)];
