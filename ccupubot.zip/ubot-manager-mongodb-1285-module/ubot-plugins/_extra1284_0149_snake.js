const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsnake0149", "snake", 149)];
