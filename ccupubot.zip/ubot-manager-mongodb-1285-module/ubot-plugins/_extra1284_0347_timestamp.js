const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtimestamp0347", "timestamp", 347)];
