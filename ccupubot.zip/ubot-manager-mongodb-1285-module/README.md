# 🤖 Userbot Manager — Panduan Lengkap (Versi Firebase + Mini App)

Bot ini = **1 bot Telegram** yang ngatur banyak **userbot**. Ada sistem role berjenjang (Prem → Reseller → Admin → Owner → Tk → Ceo → Pemilik), 3000 command, panel kelola user, struk transaksi, dan **Mini App** (web di dalam Telegram). Versi ini pakai database **Firebase**.

> Panduan ini buat yang **belum tau apa-apa**. Ikutin urut dari atas, santai aja 👌
>
> 🔸 Mau versi **MongoDB tanpa Mini App**? Itu paket terpisah. Paket ini khusus **Firebase + Mini App**.

---

## 📋 DAFTAR ISI
1. Yang harus disiapkan
2. Cara dapat API Telegram
3. Cara dapat Token Bot
4. Cara dapat ID Telegram kamu (Owner)
5. Cara bikin Database Firebase (GRATIS)
6. Cara isi file .env
7. Cara deploy Mini App (opsional)
8. Cara jalanin bot
9. Cara ganti tulisan menu awal
10. Cara pakai (command penting)
11. Kalau error (troubleshooting)

---

## 1. Yang harus disiapkan
Semua GRATIS:
- ✅ **API ID & API HASH** — dari Telegram
- ✅ **Token Bot** — dari @BotFather
- ✅ **ID Telegram kamu** — dari @userinfobot
- ✅ **Firebase Realtime Database** — database online gratis

Plus tempat jalanin bot (panel Pterodactyl / VPS / hosting Node.js 18+).

---

## 2. Cara dapat API Telegram
1. Buka **https://my.telegram.org** → login pakai **nomor HP** (masukin OTP yang masuk ke Telegram)
2. Klik **"API development tools"**
3. Isi **App title** & **Short name** bebas (misal `Userbot` / `ubot`), sisanya kosong
4. Klik **Create application**
5. Catat **api_id** (angka) dan **api_hash** (huruf panjang)

---

## 3. Cara dapat Token Bot
1. Chat **@BotFather** → ketik `/newbot`
2. Isi **nama** bebas, lalu **username** harus diakhiri `bot` (misal `userbotku_bot`)
3. Catat **token**-nya (kayak `123456789:ABCdef...`)

> 💡 Sekalian `/setprivacy` di @BotFather → pilih bot → **Disable** (biar bisa baca pesan grup).

---

## 4. Cara dapat ID Telegram kamu (Owner)
1. Chat **@userinfobot** → dia kasih **Id:** kamu (angka)
2. Catat → jadi `OWNER_IDS`. Kamu = **Pemilik** (kuasa penuh, ga bisa di-stop).

---

## 5. Cara bikin Database Firebase (GRATIS)
1. Buka **https://console.firebase.google.com** → **Add project / Tambah proyek**
2. Kasih nama proyek bebas → **Continue**. Analytics boleh di-**off** (biar simpel) → **Create project**
3. Tunggu kelar → klik **Continue**
4. Di menu kiri, buka **Build → Realtime Database**
5. Klik **Create Database**
6. Pilih lokasi (misal **Singapore**) → **Next**
7. Pilih **Start in test mode** → **Enable**
8. Nanti muncul **URL database** di atas, kayak gini:
   ```
   https://namaproyek-default-rtdb.asia-southeast1.firebasedatabase.app
   ```
   **Catat URL ini** → jadi `FIREBASE_DB_URL` di `.env`

> ⚠️ **Test mode** bikin database bisa diakses siapa aja (buat coba-coba gampang). Kalau udah serius, amankan:
> - **Cara aman:** di tab **Rules** Realtime Database, set:
>   ```json
>   { "rules": { ".read": "auth != null", ".write": "auth != null" } }
>   ```
>   Terus ambil **Database secret**: ikon ⚙️ (Project Settings) → **Service accounts** → **Database secrets** → salin → masukin ke `FIREBASE_AUTH` di `.env`.

---

## 6. Cara isi file .env
Buka file `.env`, isi:
```
API_ID=12345678                 (langkah 2)
API_HASH=abcdef123              (langkah 2)
BOT_TOKEN=123456789:ABC...      (langkah 3)
OWNER_IDS=1940337435            (langkah 4 = ID kamu)
OWNER_USERNAMES=@username_kamu
DB_TYPE=firebase                (jangan diubah)
FIREBASE_DB_URL=https://...     (langkah 5)
FIREBASE_AUTH=                  (database secret, atau kosongin kalau test mode)
MINIAPP_URL=https://...         (langkah 7, kosongin kalau ga pakai Mini App)
UBOT_PREFIX=.
HEADER_PHOTO=                   (link foto header, boleh kosong)
MANAGER_GROUP_IDS=
SERPER_API_KEY=
```

> ⚠️ **ATURAN:** JANGAN ada spasi di sekitar `=`, JANGAN pakai tanda kutip.
> BENAR: `API_ID=12345678` — SALAH: `API_ID = "12345678"`

---

## 7. Cara deploy Mini App (opsional)
Mini App = halaman web yang kebuka di dalam Telegram (tombol "Open"). Filenya ada di folder **`miniapp/`**. Fungsinya: user bisa klik **Connect** dari web, **tapi kode OTP tetap dikirim & dimasukin lewat chat bot** (aman).

Cara paling gampang deploy (pakai **Cloudflare Workers**, gratis):
1. Daftar di **https://workers.cloudflare.com**
2. Install alat-nya di komputer: `npm install -g wrangler` lalu `wrangler login`
3. Masuk ke folder `miniapp/`, jalankan: `wrangler deploy`
4. Nanti dapet link `https://namanya.workers.dev` → masukin ke `MINIAPP_URL` di `.env`

> File `miniapp/index.html` bisa kamu buka di browser buat lihat tampilannya. Detail lengkap ada di `miniapp/README.md`.
>
> Kalau **ga mau pakai Mini App**, kosongin aja `MINIAPP_URL` di `.env` — bot tetap jalan normal lewat chat.

---

## 8. Cara jalanin bot
**Pakai Pterodactyl:**
1. Upload semua file (extract dulu, jangan zip-nya)
2. Tab **Startup** → perintah jalan: `node index.js`
3. Klik **Start** (panel otomatis `npm install`)
4. Tunggu sampai console muncul:
   ```
   🗄️  Database: FIREBASE
   ✅ Bot Manager aktif: @namabotmu
   📦 PLUGIN LOADED: ... command total
   ```
5. Berhasil! 🎉 Chat bot kamu, ketik `/start`

**Pakai komputer/VPS:**
```
npm install
node index.js
```

---

## 9. Cara ganti tulisan menu awal
Tulisan pas user ketik `/start` ada di file **`index.js`**, fungsi **`buildWelcome`** (sekitar **baris 84**):
```js
function buildWelcome(userName, role) {
  const line = "⏣─────────────────⏣";
  return (
    `✦ ʜᴀʟᴏ <b>${esc(userName)}</b> ✦\n` +
    `${line}\n\n` +
    `⚡ <b>${esc(BOT_USERNAME)}</b> ᴀᴅᴀʟᴀʜ ʙᴏᴛ ᴘᴇɴʏᴇᴅɪᴀ ᴜsᴇʀʙᴏᴛ ...\n\n` +
    `👤 ʀᴏʟᴇ ᴋᴀᴍᴜ: <b>${ROLE_LABEL[role]}</b>\n` +
    `${line}\n` +
    `📌 ᴘɪʟɪʜ ᴍᴇɴᴜ ...⬇️`
  );
}
```
**Boleh ubah:** cuma **kata-katanya**. Contoh:
```js
    `✦ Selamat datang <b>${esc(userName)}</b> di toko kami ✦\n` +
```
**JANGAN ubah/hapus:** tanda backtick ` di awal/akhir baris, `\n`, `${esc(userName)}`, `${esc(BOT_USERNAME)}`, `${ROLE_LABEL[role]}`, tanda `+` di akhir baris, `<b>`/`</b>`.

Huruf kecil aneh (ʜᴀʟᴏ) itu font **smallcaps** — boleh ganti huruf biasa, atau bikin di **lingojam.com** ("Small Caps Generator"). Setelah edit, **restart bot**.

Ganti harga menu "Beli": cari `tab_beli` di `index.js`, ganti angkanya.

---

## 10. Cara pakai (command penting)

**Di bot manager** (ketik ke bot):

| Command | Fungsi | Siapa |
|---------|--------|-------|
| `/start` | Menu utama | Semua |
| `/connect` | Sambungkan userbot (OTP) | Prem ke atas |
| `/addprem <id> <hari>` | Tambah Premium | Reseller ke atas |
| `/addreseller <id> <hari>` | Tambah Reseller | Admin ke atas |
| `/addadmin <id> <hari>` | Tambah Admin | Owner ke atas |
| `/addowner <id> <hari>` | Tambah Owner | Tk ke atas |
| `/addtk <id> <hari>` | Tambah Tk | Ceo ke atas |
| `/addceo <id> <hari>` | Tambah Ceo | Pemilik |

**Panel Kelola User:** di `/start` ada tombol **"{Role} Menu — Kelola User"** (Reseller ke atas). Klik → lihat daftar user → tap user → **Extend** / **Stop** (ada konfirmasi).

**Di userbot** (setelah connect, ketik di akun sendiri pakai prefix `.`):
- Command role nyesuai jabatan kamu. Contoh kalau kamu **Reseller**: cuma ada `.addprem`, `.extend`, `.remove` (remove cuma buat role di bawah kamu). Kalau **Admin**: nambah `.addreseller`. Dan seterusnya naik.
- `.done produk,harga,bayar` → bikin struk transaksi (gambar)
- `.sharetrx <nomor>` → forward struk transaksi itu ke channel testimoni
- `.sharetrx` (sambil reply pesan) → forward pesan yang di-reply ke channel
- `.addtesti <@channel/id/link>` → set channel testimoni dulu (akun kamu harus join channel itu)
- 🎮 <b>Game</b>: ketik `.gamemenu` buat lihat semua game. Game party (grup) join-nya ketik <b>Bergabung</b>, host `.mulai` / `.batal`.
- 📝 <b>Note</b>: `.addnote nama, isi` (atau reply), `.note nama/nomor`, `.listnote`, `.editnote`, `.delnote`. Nama note unik per user.
- `.help` → lihat semua 3000 command

---

## 11. Kalau error (troubleshooting)

**Database ga kesimpen / `Database: FIREBASE` tapi data ilang**
→ Cek `FIREBASE_DB_URL` bener (ada `-default-rtdb` & domain `firebasedatabase.app`). Kalau pakai rules `auth != null`, isi `FIREBASE_AUTH` dengan database secret. Kalau belum, pakai test mode dulu.

**Bot ga bales `/start`** → cek `BOT_TOKEN`, bot udah Start, lihat error di console.

**`/start` di grup ga bales** → @BotFather `/setprivacy` → **Disable**, dan isi `MANAGER_GROUP_IDS` di `.env`.

**Tombol "Open" Mini App ga muncul** → `MINIAPP_URL` belum diisi atau bukan https. Isi link hasil deploy (langkah 7).

**Bot bales 2x** → bot jalan di 2 tempat. Matiin salah satu. Cek console: baris `🤖 INSTANCE` muncul 2x = ada 2 proses.

**MODULE_NOT_FOUND / command ilang** → upload ga komplit atau `npm install` belum jalan. Upload ulang SEMUA file, restart panel. Cek baris `📦 PLUGIN LOADED`.

---

## 📞 Catatan
- Data disimpan di **Firebase**, aman walau pindah hosting (pakai `FIREBASE_DB_URL` yang sama).
- Owner/Pemilik diatur di `.env` (`OWNER_IDS`), bukan di kode.
- Mini App opsional — OTP connect **tetap lewat chat bot** demi keamanan.

Selamat pakai! 🚀
