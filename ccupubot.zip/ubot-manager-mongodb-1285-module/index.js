require("dotenv").config();
try { require("dotenv").config({ path: require("path").join(__dirname, "gwajib.env") }); } catch {}
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const { Button } = require("telegram/tl/custom/button");
const BTN_COLOR = process.env.GEN2_BTN_COLOR !== "0";
const _BTN_ROT = ["success", "primary", "danger"];
function _btnStyleFlags(style) {
  const flags = {};
  if (style === "primary") flags.bgPrimary = true;
  else if (style === "success") flags.bgSuccess = true;
  else if (style === "danger") flags.bgDanger = true;
  return flags;
}
function cBtn(label, data, style) {
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
  if (BTN_COLOR && style && Api.KeyboardButtonStyle) {
    return new Api.KeyboardButtonCallback({ text: label, data: buf, style: new Api.KeyboardButtonStyle(_btnStyleFlags(style)) });
  }
  return Button.inline(label, buf);
}
function colorRows(rows) {
  if (!BTN_COLOR || !Api.KeyboardButtonStyle || !rows) return rows;
  let idx = 0;
  for (const row of rows) {
    for (const b of (row || [])) {
      const real = b && b.button ? b.button : b;
      if (real && real.className === "KeyboardButtonCallback") {
        if (!real.style) real.style = new Api.KeyboardButtonStyle(_btnStyleFlags(_BTN_ROT[idx % _BTN_ROT.length]));
        idx++;
      }
    }
  }
  return rows;
}
const btnColorStore = require("./lib/btnColorStore");
function colorHelpMarkup(markup, userId) {
  if (!BTN_COLOR || !Api.KeyboardButtonStyle || !markup) return markup;
  if (btnColorStore.getStyle(userId) === "off") return markup;
  let idx = 0;
  for (const row of (markup.rows || [])) {
    for (const btn of (row.buttons || [])) {
      if (btn && btn.className === "KeyboardButtonCallback") {
        const st = btnColorStore.styleAt(userId, idx++);
        if (st) btn.style = new Api.KeyboardButtonStyle(_btnStyleFlags(st));
      }
    }
  }
  return markup;
}
const _diskoLoops = new Map();
function _diskoKey(msgId) { try { return String(msgId.id || "") + ":" + String(msgId.accessHash || "") + ":" + String(msgId.dcId || ""); } catch { return String(msgId); } }
function stopDisko(msgId) { const k = _diskoKey(msgId); const l = _diskoLoops.get(k); if (l) { clearInterval(l.timer); _diskoLoops.delete(k); } }
function startDisko(msgId, text, entities, markup, userId) {
  if (!BTN_COLOR || !Api.KeyboardButtonStyle || !msgId) return;
  if (btnColorStore.getStyle(userId) !== "cycle") { stopDisko(msgId); return; }
  const k = _diskoKey(msgId);
  stopDisko(msgId);
  const CYC = btnColorStore.CYCLE_COLORS || ["primary", "danger", "success"];
  const timer = setInterval(async () => {
    const l = _diskoLoops.get(k);
    if (!l) return;
    l.tick++;
    if (l.tick > 900) { stopDisko(msgId); return; }
    try {
      const col = CYC[l.tick % CYC.length];
      for (const row of (markup.rows || [])) for (const btn of (row.buttons || [])) if (btn && btn.className === "KeyboardButtonCallback") btn.style = new Api.KeyboardButtonStyle(_btnStyleFlags(col));
      await bot.invoke(new Api.messages.EditInlineBotMessage({ id: msgId, message: text, entities, replyMarkup: markup, noWebpage: true }));
      l.fails = 0;
    } catch (e) {
      const m = String((e && e.message) || "");
      if (/MESSAGE_NOT_MODIFIED/i.test(m)) { l.fails = 0; return; }
      if (/FLOOD|flood|Too many/i.test(m)) return;
      l.fails = (l.fails || 0) + 1;
      if (l.fails >= 5) stopDisko(msgId);
    }
  }, btnColorStore.CYCLE_INTERVAL_MS || 1000);
  _diskoLoops.set(k, { timer, tick: 0, fails: 0 });
}
const db = require("./lib/database");
const ubotMgr = require("./lib/ubotManager");
function __licensed() { try { return !!require("./lib/core").capable(); } catch { return false; } }
const sandbox = require("./lib/sandbox");
const websearch = require("./lib/websearch");
const harga = require("./lib/hargaStore");
const pakasir = require("./lib/pakasir");
const themes = require("./lib/themes");
const themeStore = require("./lib/themeStore");
const addonStore = require("./lib/addonStore");
const privacyStore = require("./lib/privacyStore");
const QRCode = require("qrcode");
const DISPLAY_MODULE_TOTAL = 1285;
const GEN2_VERSION = "Userbot Forgot Gen 2";


function pakasirReady() {
  return (process.env.METODE_PEMBAYARAN || "").trim().toLowerCase() === "pakasir" && pakasir.ready();
}
const pendingOrders = new Map();

// ========================================================
// AUTO REACTION & PAP AYANG — CONFIG & STATE
// ========================================================

const AR_FILE = require("path").join(__dirname, "autoreact.json");
const autoreactStore = new Map(); // userId -> config

// Load config dari disk
try {
  if (require("fs").existsSync(AR_FILE)) {
    const data = JSON.parse(require("fs").readFileSync(AR_FILE, "utf8"));
    for (const [k, v] of Object.entries(data)) autoreactStore.set(k, v);
  }
} catch (e) { console.error("load autoreact.json:", e.message); }

function saveAutoreact() {
  try {
    require("fs").writeFileSync(AR_FILE, JSON.stringify(Object.fromEntries(autoreactStore), null, 2));
  } catch (e) { console.error("save autoreact.json:", e.message); }
}

const AR_DEFAULT = {
  enabled: false,
  emoji: ["👍"],
  random: false,
  includeGroups: true,
  includeChannels: false,
  includePrivate: false,
  keywordOnly: false,
  keywords: [],
  skipAdmins: false,
  cooldownMs: 1500,
};

function getAR(userId) {
  const cur = autoreactStore.get(String(userId)) || {};
  return { ...AR_DEFAULT, ...cur, _lastReact: cur._lastReact || 0 };
}

function setAR(userId, patch) {
  const next = { ...getAR(userId), ...patch };
  autoreactStore.set(String(userId), next);
  saveAutoreact();
  return next;
}

// Cooldown map biar gak spam react
const arCooldown = new Map();

// ========================================================
// PAP AYANG — SUMBER GAMBAR (PUBLIC API, SFW)
// ========================================================
const PAP_AYANG_APIS = [
  { url: "https://api.botcahx.eu.org/api/random/cecan", jsonPath: "result" },
  { url: "https://api.vreden.my.id/api/cecan", jsonPath: "result.url" },
  { url: "https://api.yanzbotz.my.id/api/random/cecan", jsonPath: "result.url" },
];

async function fetchPapAyang() {
  const axios = require("axios");
  for (const api of PAP_AYANG_APIS) {
    try {
      const r = await axios.get(api.url, { timeout: 8000 });
      const data = r.data;
      // Coba beberapa path
      let imgUrl = null;
      if (typeof data === "string" && data.startsWith("http")) imgUrl = data;
      else if (data?.result?.url) imgUrl = data.result.url;
      else if (data?.result && typeof data.result === "string") imgUrl = data.result;
      else if (data?.url) imgUrl = data.url;
      else if (data?.data?.url) imgUrl = data.data.url;
      else if (data?.data && typeof data.data === "string") imgUrl = data.data;
      
      if (imgUrl && imgUrl.startsWith("http")) return imgUrl;
    } catch (e) { continue; }
  }
  return null;
}

const customStore = require("./lib/customStore");
const giveawayStore = require("./lib/giveawayStore");
const custInputState = new Map();
const payProofState = new Map();
const rejectReasonState = new Map();
const gaWizard = new Map();
const lastInlineHelp = new Map();
const QRIS_FILE = require("path").join(__dirname, "qris_forgot.jpg");

async function isMemberOfAll(userId) {
  const jf = customStore.get().joinFirst;
  if (!jf.enabled || !jf.chats.length) return true;
  for (const ch of jf.chats) {
    try {
      const chan = await bot.getInputEntity(ch.ref);
      const uid = await bot.getInputEntity(parseInt(userId));
      await bot.invoke(new Api.channels.GetParticipant({ channel: chan, participant: uid }));
    } catch (e) {
      return false;
    }
  }
  return true;
}

function joinGateView(userName) {
  const jf = customStore.get().joinFirst;
  const rows = jf.chats.map((c) => [Button.url("🔗 " + (c.title || "Join"), c.link)]);
  rows.push([Button.inline("✅ Cek / Lanjut", Buffer.from("jf_cek"))]);
  const list = jf.chats.map((c, i) => `${i + 1}. ${esc(c.title || c.link)}`).join("\n");
  const text = quote(
    `🔒 <b>WAJIB JOIN DULU</b>\n⏣────────────────⏣\n\n` +
    `Halo <b>${esc(userName)}</b>! Sebelum pakai bot, kamu wajib join channel/grup berikut:\n\n` +
    `${list}\n\nSetelah join SEMUA, tekan <b>✅ Cek / Lanjut</b>.`
  );
  return { text, buttons: rows };
}

function _buyBasePrice(role) {
  const DEF = { prem: 1000, reseller: 3000, admin: 5000, owner: 8000, tk: 11000, ceo: 13000 };
  return harga.getRolePrice(role) || DEF[role] || 0;
}
function computeOrderPrice(kind, role, userId, days) {
  let base;
  if (kind === "upg") {
    const cur = db.getRole(userId);
    base = Math.max(0, _buyBasePrice(role) - _buyBasePrice(cur));
  } else {
    base = _buyBasePrice(role);
  }
  const total = Math.round((base * days) / 30);
  return { base, total };
}
function daysPickerView(kind, role, userId, days) {
  days = Math.max(30, Math.min(3650, days));
  const { total } = computeOrderPrice(kind, role, userId, days);
  const label = harga.ROLE_LABEL[role] || role;
  const text = quote(
    `🗓 <b>PILIH DURASI</b>\n⏣────────────────⏣\n\n` +
    `${kind === "upg" ? "Upgrade ke" : "Role"}: <b>${label}</b>\n` +
    `Durasi: <b>${days} hari</b>\n` +
    `Total: <b>${harga.fmtRupiah(total)}</b>\n\n` +
    `<i>Minimal 30 hari. 30 hari = harga dasar; tiap hari tambahan dihitung pro-rata.</i>`
  );
  const d = (n) => `qd:${kind}:${role}:${Math.max(30, Math.min(3650, n))}`;
  const rows = [];
  if (days > 30) rows.push([cBtn("«", d(days - 1), "primary"), cBtn(`${days} hari`, "noop", "success"), cBtn("»", d(days + 1), "primary")]);
  else rows.push([cBtn(`${days} hari`, "noop", "success"), cBtn("»", d(days + 1), "primary")]);
  const adj = [];
  if (days > 30) { adj.push(cBtn("-30", d(days - 30), "danger")); adj.push(cBtn("-10", d(days - 10), "danger")); }
  adj.push(cBtn("+10", d(days + 10), "success"));
  adj.push(cBtn("+30", d(days + 30), "success"));
  rows.push(adj);
  rows.push([cBtn("✅ Selesai", `qdok:${kind}:${role}:${days}`, "success")]);
  rows.push([cBtn("« Batal", kind === "upg" ? "tab_upgrade" : "tab_beli", "danger")]);
  return { text, buttons: rows };
}
async function showManualQris(userId, role, amount, kind, days) {
  days = days || 30;
  try {
    const ie = await bot.getInputEntity(parseInt(userId));
    const cap = quote(
      `💳 <b>PEMBAYARAN QRIS</b>\n⏣────────────────⏣\n\n` +
      `${kind === "upgrade" || kind === "upg" ? "Upgrade ke" : "Role"}: <b>${harga.ROLE_LABEL[role] || role}</b>\n` +
      `Durasi: <b>${days} hari</b>\n` +
      `Total: <b>${harga.fmtRupiah(amount)}</b>\n\n` +
      `1. Scan QRIS di atas & bayar <b>${harga.fmtRupiah(amount)}</b>.\n` +
      `2. Tekan <b>✅ Selesai & Kirim Bukti</b>, lalu kirim <b>foto bukti transfer</b>.\n` +
      `3. Owner akan verifikasi & aktifkan role kamu.`
    );
    await bot.sendFile(ie, {
      file: QRIS_FILE,
      caption: cap,
      parseMode: "html",
      buttons: [[Button.inline("✅ Selesai & Kirim Bukti", Buffer.from(`payproof:${role}:${amount}:${days}`))]],
    });
  } catch (e) {
    try { const ie = await bot.getInputEntity(parseInt(userId)); await bot.sendMessage(ie, { message: quote(`❌ Gagal menampilkan QRIS: ${esc(e.message)}. Pastikan owner sudah Set QRIS.`), parseMode: "html" }); } catch {}
  }
}

const GA_ROLES = ["prem", "reseller", "admin", "owner", "tk", "ceo"];
function _gaLabel(r) { return harga.ROLE_LABEL[r] || r; }
function gaFmtMinutes(m) {
  m = Math.max(1, m | 0);
  if (m < 60) return `${m} menit`;
  if (m < 1440) { const h = Math.floor(m / 60), mm = m % 60; return `${h} jam${mm ? ` ${mm} mnt` : ""}`; }
  const d = Math.floor(m / 1440), hh = Math.floor((m % 1440) / 60);
  return `${d} hari${hh ? ` ${hh} jam` : ""}`;
}
function gaExpLabel(wiz) {
  if (wiz.expType === "time") return "waktu " + gaFmtMinutes(wiz.expVal);
  if (wiz.expType === "count") return wiz.expVal + " orang";
  return "tanpa expired";
}
function gaMenuView() {
  const gv = giveawayStore.get();
  const codeCount = Object.values(gv.codes).filter((c) => c.active).length;
  const text = quote(
    `🎁 <b>GIVEAWAY</b>\n⏣────────────────⏣\n\n` +
    `Kelola giveaway ubot kamu (khusus pemilik).\n\n` +
    `🎟 Redeem code aktif: <b>${codeCount}</b>\n` +
    `🎰 Peserta spin: <b>${gv.seen.length}</b> user\n` +
    `🎁 Trial: <b>${gv.trial.enabled ? `✅ Aktif (${gv.trial.days} hari)` : "❌ Nonaktif"}</b>`
  );
  const rows = [
    [cBtn("🎟 Redeem Code", "ga_redeem", "success")],
    [cBtn("🎰 Spin G.A", "ga_spin", "primary")],
    [cBtn(gv.trial.enabled ? "🎁 Trial (Kelola)" : "🎁 Trial", "ga_trial", "success")],
    [Button.inline("« Kembali", Buffer.from("tab_settings"))],
  ];
  return { text, buttons: rows };
}
function gaRolePickView() {
  const text = quote(`🎟 <b>REDEEM CODE — PILIH ROLE</b>\n⏣────────────────⏣\n\nRole apa yang didapat user yang redeem code ini?`);
  const rows = GA_ROLES.map((r) => [cBtn(_gaLabel(r), "garw:role:" + r, "success")]);
  rows.push([Button.inline("« Batal", Buffer.from("tab_giveaway"))]);
  return { text, buttons: rows };
}
function gaExpTypeView(wiz) {
  const text = quote(
    `🎟 <b>REDEEM CODE — TIPE EXPIRED</b>\n⏣────────────────⏣\n\n` +
    `Role: <b>${_gaLabel(wiz.role)}</b>\n\nKapan code ini kadaluarsa?`
  );
  const rows = [
    [cBtn("⏱ Berdasarkan Waktu", "garw:exptype:time", "primary")],
    [cBtn("👥 Berdasarkan Jumlah Orang", "garw:exptype:count", "primary")],
    [cBtn("♾ Tanpa Expired", "garw:exptype:none", "primary")],
    [Button.inline("« Batal", Buffer.from("tab_giveaway"))],
  ];
  return { text, buttons: rows };
}
function gaExpValView(wiz) {
  const isTime = wiz.expType === "time";
  const val = Math.max(1, wiz.expVal | 0);
  const disp = isTime ? gaFmtMinutes(val) : `${val} orang`;
  const text = quote(
    `🎟 <b>REDEEM CODE — ${isTime ? "DURASI" : "JUMLAH ORANG"}</b>\n⏣────────────────⏣\n\n` +
    `Role: <b>${_gaLabel(wiz.role)}</b>\n` +
    `${isTime ? "Code aktif selama" : "Code bisa dipakai"}: <b>${disp}</b>\n\n` +
    `<i>${isTime ? "Code otomatis mati setelah durasi ini." : "Code otomatis mati setelah dipakai sekian orang."}</i>`
  );
  const st = (n) => "garw:expset:" + Math.max(1, n);
  const rows = [];
  const arrow = [];
  if (val > 1) arrow.push(cBtn("«", st(val - 1), "primary"));
  arrow.push(cBtn(disp, "noop", "success"));
  arrow.push(cBtn("»", st(val + 1), "primary"));
  rows.push(arrow);
  const adj = [];
  if (isTime) {
    if (val > 1) { adj.push(cBtn("-30", st(val - 30), "danger")); adj.push(cBtn("-10", st(val - 10), "danger")); }
    adj.push(cBtn("+10", st(val + 10), "success"));
    adj.push(cBtn("+30", st(val + 30), "success"));
  } else {
    if (val > 1) { adj.push(cBtn("-10", st(val - 10), "danger")); adj.push(cBtn("-5", st(val - 5), "danger")); }
    adj.push(cBtn("+5", st(val + 5), "success"));
    adj.push(cBtn("+10", st(val + 10), "success"));
  }
  rows.push(adj);
  rows.push([cBtn("✅ Selesai", "garw:expdone", "success")]);
  rows.push([Button.inline("« Batal", Buffer.from("tab_giveaway"))]);
  return { text, buttons: rows };
}
function gaNoneConfirmView(wiz) {
  const text = quote(
    `🎟 <b>REDEEM CODE — TANPA EXPIRED</b>\n⏣────────────────⏣\n\n` +
    `Role: <b>${_gaLabel(wiz.role)}</b>\n\n` +
    `⚠️ Code ini <b>gak akan pernah kadaluarsa</b> & bisa dipakai <b>tanpa batas</b> orang. Yakin?`
  );
  const rows = [[cBtn("✅ Yakin", "garw:nonecfm", "success"), cBtn("❌ Batal", "garw:exptype_back", "danger")]];
  return { text, buttons: rows };
}
function gaCodeMethodView(wiz) {
  const text = quote(
    `🎟 <b>REDEEM CODE — BUAT KODE</b>\n⏣────────────────⏣\n\n` +
    `Role: <b>${_gaLabel(wiz.role)}</b>\n` +
    `Expired: <b>${gaExpLabel(wiz)}</b>\n\nMau kode random atau bikin sendiri?`
  );
  const rows = [
    [cBtn("🎲 Random Code", "garw:code:random", "success")],
    [cBtn("✍️ Set Kode Sendiri", "garw:code:set", "primary")],
    [Button.inline("« Batal", Buffer.from("tab_giveaway"))],
  ];
  return { text, buttons: rows };
}
function gaCodeResult(wiz, code) {
  const text = quote(
    `✅ <b>REDEEM CODE DIBUAT!</b>\n⏣────────────────⏣\n\n` +
    `🎟 Kode: <code>${esc(code)}</code>\n` +
    `🎭 Role: <b>${_gaLabel(wiz.role)}</b>\n` +
    `⏳ Expired: <b>${gaExpLabel(wiz)}</b>\n\n` +
    `Sebar / broadcast kode ini ke member. Mereka klaim dengan:\n<code>/redeem ${esc(code)}</code>`
  );
  const rows = [[Button.inline("« Ke Giveaway", Buffer.from("tab_giveaway"))]];
  return { text, rows };
}
function gaSpinView(resultHtml) {
  const text = quote(
    `🎰 <b>SPIN GIVEAWAY</b>\n⏣────────────────⏣\n\n` +
    (resultHtml || `Tekan <b>SPIN</b> di bawah. Bot pilih <b>1 user random</b> yang pernah start bot & kasih <b>role random</b> selama <b>5 hari</b>.`)
  );
  const rows = [[cBtn("🎰 SPIN!", "ga_spin_go", "success")], [Button.inline("« Kembali", Buffer.from("tab_giveaway"))]];
  return { text, buttons: rows };
}
function gaTrialView(userId) {
  const t = giveawayStore.getTrial();
  if (t.enabled) {
    const text = quote(
      `🎁 <b>TRIAL PREMIUM</b>\n⏣────────────────⏣\n\n` +
      `Status: <b>✅ Aktif</b>\n` +
      `Durasi: <b>${t.days} hari</b>\n` +
      `Sudah diklaim: <b>${t.claimedBy.length} user</b>\n\n` +
      `Tombol "Trial Premium ${t.days} hari" muncul di /start buat user biasa. Tekan di bawah buat matiin.`
    );
    return { text, buttons: [[cBtn("🗑 Hapus Trial", "ga_trial_del", "danger")], [Button.inline("« Kembali", Buffer.from("tab_giveaway"))]] };
  }
  const wiz = gaWizard.get(userId);
  const days = Math.max(1, (wiz && wiz.tdays) || 7);
  const text = quote(
    `🎁 <b>TRIAL PREMIUM — SET DURASI</b>\n⏣────────────────⏣\n\n` +
    `Durasi trial: <b>${days} hari</b>\n\n` +
    `<i>User biasa bisa klaim premium gratis selama ini dari /start. Atur pakai panah.</i>`
  );
  const arrow = [];
  if (days > 1) arrow.push(cBtn("«", "gatw:set:" + (days - 1), "primary"));
  arrow.push(cBtn(`${days} hari`, "noop", "success"));
  arrow.push(cBtn("»", "gatw:set:" + (days + 1), "primary"));
  const rows = [arrow, [cBtn("✅ Selesai", "gatw:done", "success")], [Button.inline("« Batal", Buffer.from("tab_giveaway"))]];
  return { text, buttons: rows };
}

function boldify(s) {
  let o = "";
  for (const ch of String(s)) {
    const c = ch.codePointAt(0);
    if (c >= 65 && c <= 90) o += String.fromCodePoint(0x1d5d4 + (c - 65));
    else if (c >= 97 && c <= 122) o += String.fromCodePoint(0x1d5ee + (c - 97));
    else if (c >= 48 && c <= 57) o += String.fromCodePoint(0x1d7ec + (c - 48));
    else o += ch;
  }
  return o;
}
function buildStruk({ nama, id, produk, hargaStr, waktu }) {
  const b = boldify;
  return (
    `🧾 ${b("STRUK PEMBELIAN PRODUK")}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━❍\n` +
    `🧑 ${b("IDENTITAS PEMBELI")}\n` +
    `├ 👤 ${b("Nama")} : ${esc(nama)}\n` +
    `╰ 🆔 ${b("ID")} : <code>${esc(String(id))}</code>\n` +
    `📦 ${b("DATA PRODUK")}\n` +
    `├ 🛒 ${b("Produk")} : ${esc(produk)}\n` +
    `├ 💰 ${b("Harga")} : ${b(hargaStr)}\n` +
    `╰ ⏰ ${b("Waktu")} : ${b(waktu)} WIB\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━❍\n` +
    `🛍️ ${b("Terimakasih Sudah Belanja")}`
  );
}
async function autoShareTrx({ buyerId, role, amount, kind }) {
  const ch = (process.env.CH_SHARE_TRX_AUTO || "").trim();
  if (!ch) return;
  try {
    let nama = "User";
    try { const u = await bot.getEntity(parseInt(buyerId)); nama = [u.firstName, u.lastName].filter(Boolean).join(" ") || (u.username ? "@" + u.username : "User"); } catch {}
    const waktu = new Date().toLocaleString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" });
    const roleLabel = harga.ROLE_LABEL[role] || role;
    const produk = kind === "upgrade" ? `UPGRADE ke ${roleLabel} (30 hari)` : `${roleLabel} (30 hari)`;
    const struk = buildStruk({ nama, id: buyerId, produk, hargaStr: harga.fmtRupiah(amount), waktu });
    let ref = ch;
    if (!ref.startsWith("@") && !/^-?\d+$/.test(ref)) ref = "@" + ref;
    const target = await bot.getInputEntity(ref);
    const photo = (process.env.HEADERS_PHOTO_TRX || "").trim();
    if (photo) await bot.sendFile(target, { file: photo, caption: struk, parseMode: "html" });
    else await bot.sendMessage(target, { message: struk, parseMode: "html" });
  } catch (e) { console.error("autoShareTrx:", e.message); }
}

const searchResults = new Map();
const shopResults = new Map();
function cleanupShop() {
  const now = Date.now();
  if (shopResults.size > 100) { const first = shopResults.keys().next().value; shopResults.delete(first); }
  for (const [k, v] of shopResults) if (now - v.ts > 3600000) shopResults.delete(k);
}
function cleanupSearch() {
  const now = Date.now();
  for (const [k, v] of searchResults) if (now - v.ts > 3600000) searchResults.delete(k);
}

const API_ID = parseInt(process.env.API_ID);
const API_HASH = process.env.API_HASH;
const BOT_TOKEN = process.env.BOT_TOKEN;
const HEADER_PHOTO = process.env.HEADER_PHOTO || "";
const OWNER_USERNAMES = process.env.OWNER_USERNAMES || "@syifaimyut, @syifaimyutl";

const MANAGER_GROUP_IDS = (process.env.MANAGER_GROUP_IDS || "-1004343431776")
  .split(",").map(s => s.trim()).filter(Boolean);

function isAllowedGroup(msg) {
  try {
    const cid = (msg.chatId ?? "").toString();
    if (!cid) return false;
    const norm = (x) => x.replace(/^-100/, "").replace(/^-/, "");
    const target = norm(cid);
    return MANAGER_GROUP_IDS.some(g => norm(g) === target);
  } catch { return false; }
}
const BOT_USERNAME = process.env.BOT_USERNAME || "@syifaubot_bot";

function cleanEnv(v) {
  return String(v || "").trim().replace(/^['"]|['"]$/g, "");
}
const MINIAPP_URL = cleanEnv(process.env.MINIAPP_URL);
function validMiniAppUrl(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== "https:") return false;
    return !/(miniappkamu|example\.com|localhost|127\.0\.0\.1)/i.test(u.hostname);
  } catch { return false; }
}

function buildMiniAppUrl(userId) {
  if (!MINIAPP_URL) return "";
  const role = db.getRole(userId);
  const owners = (OWNER_USERNAMES || "").replace(/\s/g, "");
  const sep = MINIAPP_URL.includes("?") ? "&" : "?";
  return MINIAPP_URL + sep +
    `role=${encodeURIComponent(role)}` +
    `&uid=${encodeURIComponent(userId)}` +
    `&owners=${encodeURIComponent(owners)}` +
    `&bot=${encodeURIComponent(BOT_USERNAME)}`;
}

if (!API_ID || !API_HASH || !BOT_TOKEN) {
  console.error("❌ Set API_ID, API_HASH, dan BOT_TOKEN di .env!");
  process.exit(1);
}

const bot = new TelegramClient(new StringSession(""), API_ID, API_HASH, {
  connectionRetries: 5,
});
try { require("./lib/emojiPrem").wrapClient(bot, (peer) => require("./lib/emojiPrem").idOf(peer)); } catch {}

const loginState = new Map();

const sandboxState = new Map();
const sandboxPanel = new Map();

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

const _scfmt = require("./ubot-plugins/_format");
function quote(html) {
  return `<blockquote>${_scfmt.styleHtml(String(html == null ? "" : html))}</blockquote>`;
}
function ensureQuote(html) {
  let s = String(html == null ? "" : html).trim();
  if (s.startsWith("<blockquote>") && s.endsWith("</blockquote>")) s = s.slice(12, -13);
  return `<blockquote>${_scfmt.styleHtml(s)}</blockquote>`;
}

const ROLE_LABEL = {
  pemilik: "💎 Pemilik", allrole: "🌈 Allrole", ceo: "🌟 Ceo", tk: "🔱 Tk",
  owner: "👑 Owner", admin: "🛡️ Admin", reseller: "💼 Reseller",
  prem: "⭐ Prem", user: "👤 User",
};

function buildWelcome(userName, role, userId) {
  const botUser = String(BOT_USERNAME || "").replace(/^@/, "") || "Userbot_Forgot_bot";
  const mention = `<a href="tg://user?id=${userId}">${esc(userName)}</a>`;
  const roleLabel = ROLE_LABEL[role] || role;
  return `<blockquote>👋 <b>ʜᴀʟᴏ, ${mention}!</b>
<b>✨ 𝖶𝖾𝗅𝖼𝗈𝗆𝖾 𝗍𝗈 ${esc(botUser)} ✨</b>

╭━━━━━━━━━━━━━━━━━━╮
┃ 🆔 <b>ɪᴅ</b>   : <code>${userId}</code>
┃ 🎭 <b>ʀᴏʟᴇ</b> : <b>${roleLabel}</b>
┃ 🤖 <b>ʙᴏᴛ</b>  : @${esc(botUser)}
╰━━━━━━━━━━━━━━━━━━╯

🚀 Berjalan di <b>Ubot Syifaa gen 2</b> — arsitektur baru, lebih cepat &amp; stabil.

📚 <code>/help</code>   🏓 <code>/ping</code>   ⚙️ <code>/settings</code>

📌 <i>Pilih menu di bawah untuk lanjut</i> ⬇️</blockquote>`;
}

function mainKeyboard(role, userId) {
  const rawTh = themeStore.getTheme(userId);
  const th = rawTh === "premium" ? "old" : rawTh;
  const B = (label, data, style) => {
    const p = themes.deco(th);
    return cBtn(p ? `${p} ${label}` : label, data, style);
  };
  const rows = [
    [B("💎 Beli Akses / Userbot", "tab_beli", "success")],
    [B("⚡ Upgrade Role System", "tab_upgrade", "success")],
    [B("👥 Group Ubot", "tab_group", "primary")],
  ];

  if (db.ROLES[role] >= db.ROLES.prem) {
    rows.push([B("🤖 Buat Userbot", "tab_connect", "success"), B("📖 Help Menu", "tab_help", "primary")]);
  } else {
    rows.push([B("📖 Help Menu", "tab_help", "primary")]);
  }

  rows.push([B("🛟 Support", "tab_support", "primary"), B("⚙️ Settings", "tab_settings", "primary")]);

  if (db.ROLES[role] >= db.ROLES.reseller) {
    rows.push([B(`${ROLE_LABEL[role]} Menu — Kelola User`, "rolemenu", "danger")]);
  }

  const _tr = giveawayStore.getTrial();
  if (_tr.enabled && db.ROLES[role] < db.ROLES.prem && !_tr.claimedBy.includes(String(userId)) && !db.OWNER_IDS.includes(String(userId))) {
    rows.push([cBtn(`🎁 Trial Premium ${_tr.days} hari`, "claim_trial", "success")]);
  }
  return rows;
}

function backKeyboard() {
  return [[Button.inline("« Kembali", Buffer.from("tab_main"))]];
}

async function showMainEdit(event, userId) {
  const role = db.getRole(userId);
  const me = await getUserName(userId);
  const caption = buildWelcome(me, role, userId);
  const buttons = mainKeyboard(role, userId);
  await editView(event, caption, buttons, true);
}

async function getUserName(userId) {
  try {
    const ent = await bot.getEntity(parseInt(userId));
    return ent.firstName || ent.username || "User";
  } catch {
    return "User";
  }
}

async function sendView(peerInput, caption, buttons, withPhoto) {
  caption = ensureQuote(caption);
  buttons = colorRows(buttons);
  let peer;
  try {
    peer = await bot.getInputEntity(peerInput);
  } catch (e) {
    console.error("sendView getInputEntity error:", e.message);
    return null;
  }
  try {
    if (withPhoto && HEADER_PHOTO) {
      return await bot.sendFile(peer, { file: HEADER_PHOTO, caption, parseMode: "html", buttons });
    }
    return await bot.sendMessage(peer, { message: caption, parseMode: "html", buttons });
  } catch (e) {
    console.error("sendView error:", e.message);
    try {
      return await bot.sendMessage(peer, { message: caption, parseMode: "html", buttons });
    } catch (e2) {
      console.error("sendView fallback error:", e2.message);
      return null;
    }
  }
}

async function editView(event, caption, buttons, withPhoto) {
  caption = ensureQuote(caption);
  buttons = colorRows(buttons);
  const msgId = event.messageId;
  let chat;
  try {
    chat = await event.getInputChat();
  } catch (e) {
    console.error("editView getInputChat error:", e.message);
    return;
  }

  try {
    if (withPhoto && HEADER_PHOTO) {
      await bot.editMessage(chat, {
        message: msgId,
        text: caption,
        parseMode: "html",
        buttons,
        file: HEADER_PHOTO,
      });
    } else {
      await bot.editMessage(chat, {
        message: msgId,
        text: caption,
        parseMode: "html",
        buttons,
      });
    }
  } catch (e) {
    console.error("editView error:", e.message);
    try {
      await bot.editMessage(chat, {
        message: msgId,
        text: caption,
        parseMode: "html",
        buttons,
      });
    } catch (e2) {
      console.error("editView fallback:", e2.message);
    }
  }
}

async function sbView(userId, peer, text, buttons, event) {
  const wrapped = `<blockquote><b>${_fmt.styleHtml(text)}</b></blockquote>`;

  let editMsgId = null, chat = null;
  if (event && event.messageId) {
    editMsgId = event.messageId;
    try { chat = await event.getInputChat(); } catch {}
  } else if (sandboxPanel.has(userId)) {
    editMsgId = sandboxPanel.get(userId);
    try { chat = await bot.getInputEntity(peer || parseInt(userId)); } catch {}
  }

  if (editMsgId && chat) {
    try {
      await bot.editMessage(chat, { message: editMsgId, text: wrapped, parseMode: "html", buttons });
      sandboxPanel.set(userId, editMsgId);
      return editMsgId;
    } catch (e) {
    }
  }

  try {
    const target = await bot.getInputEntity(peer || parseInt(userId));
    const sent = await bot.sendMessage(target, { message: wrapped, parseMode: "html", buttons });
    if (sent) sandboxPanel.set(userId, sent.id);
    return sent ? sent.id : null;
  } catch (e) {
    console.error("sbView send error:", e.message);
  }
}

async function sbPrompt(userId, peer, text, cancelData, event) {
  const buttons = [[Button.inline("✕ Batal", Buffer.from(cancelData || "sb_promptcancel"))]];
  return sbView(userId, peer, text, buttons, event);
}

async function showTab(tab, userId, event) {
  const role = db.getRole(userId);
  let caption = "";
  let buttons = backKeyboard();

  if (tab === "beli") {
    const prices = harga.getAllRolePrices();
    const DEF = { prem: 1000, reseller: 3000, admin: 5000, owner: 8000, tk: 11000, ceo: 13000 };
    const priceOf = (r) => (prices[r] != null ? prices[r] : DEF[r]);
    const listLines = harga.ROLE_ORDER.map((r) => `\u2022 ${harga.ROLE_LABEL[r]} \u2014 ${harga.fmtRupiah(priceOf(r))}`).join("\n");
    const _qOn = customStore.get().qrisSet;
    if (pakasirReady() || _qOn) {
      caption = quote(
        `\ud83d\udc8e <b>BELI AKSES / USERBOT</b>\n` +
        `\u23e3\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u23e3\n\n` +
        `Pilih role yang mau dibeli:\n\n` +
        `${listLines}\n\n` +
        (pakasirReady()
          ? `<i>Masa aktif 30 hari. Tekan tombol role di bawah, QRIS langsung muncul.</i>`
          : `<i>Tekan tombol role di bawah \u2014 pilih durasi (min 30 hari), lalu bayar via QRIS.</i>`)
      );
      const rows = harga.ROLE_ORDER.filter((r) => priceOf(r)).map((r) =>
        [Button.inline(`${harga.ROLE_LABEL[r]} \u2014 ${harga.fmtRupiah(priceOf(r))}`, Buffer.from("buyrole_" + r))]
      );
      rows.push([Button.inline("\u00ab Kembali", Buffer.from("tab_main"))]);
      buttons = rows;
    } else {
      caption = quote(
        `\ud83d\udc8e <b>BELI AKSES / USERBOT</b>\n` +
        `\u23e3\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u23e3\n\n` +
        `Untuk membeli akses userbot, hubungi owner utama:\n\n` +
        `${esc(OWNER_USERNAMES)}\n\n` +
        `\ud83d\udcb0 <b>DAFTAR HARGA (30 hari):</b>\n` +
        `${listLines}\n\n` +
        `<i>Transaksi masih manual.</i>`
      );
    }
  } else if (tab === "upgrade") {
    const up = harga.ROLE_ORDER.map((r) => {
      const u = harga.getUpgradePrice(r);
      return u ? `\u2022 ${harga.ROLE_LABEL[r]} \u2192 ${harga.ROLE_LABEL[u.to]} = ${harga.fmtRupiah(u.amount)}` : null;
    }).filter(Boolean).join("\n");
    caption = quote(
      `\u26a1 <b>UPGRADE ROLE SYSTEM</b>\n` +
      `\u23e3\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u23e3\n\n` +
      `<b>HIERARKI ROLE:</b>\n` +
      `\ud83d\udc8e Pemilik \u2192 kuasa penuh (tertinggi)\n` +
      `\ud83c\udf1f Ceo \u2192 bisa add Tk ke bawah\n` +
      `\ud83d\udd31 Tk \u2192 bisa add Owner ke bawah\n` +
      `\ud83d\udc51 Owner \u2192 bisa add Admin ke bawah\n` +
      `\ud83d\udee1\ufe0f Admin \u2192 bisa add Reseller, Prem\n` +
      `\ud83d\udcbc Reseller \u2192 bisa add Prem\n` +
      `\u2b50 Prem \u2192 hanya pakai ubot\n` +
      `\ud83d\udc64 User \u2192 tidak ada akses\n\n` +
      (up ? `\ud83d\udcb0 <b>BIAYA UPGRADE (per tingkat):</b>\n${up}\n\n` : ``) +
      `Role kamu: <b>${ROLE_LABEL[role]}</b>`
    );
    {
      const curRank = db.ROLES[role] ?? 0;
      const above = harga.ROLE_ORDER.filter((tr) => (db.ROLES[tr] ?? 0) > curRank);
      const payAvail = customStore.get().qrisSet || pakasirReady();
      if (payAvail && above.length) {
        const rows2 = [];
        for (const tr of above) {
          const price = computeOrderPrice("upg", tr, userId, 30).total;
          if (!price) continue;
          rows2.push([Button.inline(`\u2b06\ufe0f ${harga.ROLE_LABEL[tr]} \u2014 ${harga.fmtRupiah(price)}`, Buffer.from("upgto_" + tr))]);
        }
        rows2.push([Button.inline("\u00ab Kembali", Buffer.from("tab_main"))]);
        buttons = rows2;
      }
    }
  } else if (tab === "group") {
    caption = quote(
      `👥 <b>ɢʀᴏᴜᴘ ᴜʙᴏᴛ</b>\n` +
      `⏣────────────────⏣\n\n` +
      `ɢᴀʙᴜɴɢ ᴋᴏᴍᴜɴɪᴛᴀs ᴜɴᴛᴜᴋ ɪɴꜰᴏ, ᴜᴘᴅᴀᴛᴇ, ᴅᴀɴ ʙᴀɴᴛᴜᴀɴ:\n\n` +
      `📢 ᴄʜᴀɴɴᴇʟ & ɢʀᴜᴘ ʀᴇsᴍɪ ᴀᴋᴀɴ sᴇɢᴇʀᴀ ᴅɪʙᴜᴋᴀ.`
    );
  } else if (tab === "support") {
    caption = quote(
      `🛟 <b>sᴜᴘᴘᴏʀᴛ</b>\n` +
      `⏣────────────────⏣\n\n` +
      `ᴀᴅᴀ ᴋᴇɴᴅᴀʟᴀ ᴀᴛᴀᴜ ᴇʀᴏʀ? ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ:\n\n` +
      `${esc(OWNER_USERNAMES)}\n\n` +
      `⏱️ ʀᴇsᴘᴏɴ ʙɪᴀsᴀɴʏᴀ ᴄᴇᴘᴀᴛ.`
    );
  } else if (tab === "help") {
    let cmds = `<b>📖 ʜᴇʟᴘ ᴍᴇɴᴜ</b>\n⏣────────────────⏣\n\n`;
    cmds += `<b>ᴜᴍᴜᴍ:</b>\n`;
    cmds += `• <code>/start</code> — ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ\n`;
    cmds += `• <code>/connect</code> — sᴀᴍʙᴜɴɢᴋᴀɴ ᴜʙᴏᴛ\n`;
    cmds += `• <code>/myubot</code> — sᴛᴀᴛᴜs ᴜʙᴏᴛ\n`;
    cmds += `• <code>/disconnect</code> — ᴘᴜᴛᴜsᴋᴀɴ ᴜʙᴏᴛ\n`;
    const addable = db.CAN_ADD[role];
    if (addable && addable.length) {
      cmds += `\n<b>ᴍᴀɴᴀᴊᴇᴍᴇɴ ʀᴏʟᴇ:</b>\n`;
      for (const r of addable) {
        cmds += `• <code>/add${r} &lt;id&gt; [hari]</code>\n`;
      }
      cmds += `• <code>/remove &lt;id&gt;</code>\n`;
      for (const r of addable) {
        cmds += `• <code>/list${r}</code>\n`;
      }
      cmds += `• <code>/extend &lt;id&gt; &lt;hari&gt;</code> — perpanjang masa aktif\n`;
    }
    if (db.OWNER_IDS.includes(userId)) {
      cmds += `\n<b>owner:</b>\n`;
      cmds += `• <code>/stats</code> — statistik bot\n`;
      cmds += `• <code>/broadcast &lt;pesan&gt;</code> — kirim pengumuman\n`;
    }
    caption = quote(cmds);
  } else if (tab === "connect") {
    if (!db.canUseUbot(userId)) {
      caption = quote(
        `🤖 <b>ʙᴜᴀᴛ ᴜsᴇʀʙᴏᴛ</b>\n⏣────────────────⏣\n\n` +
        `❌ ʀᴏʟᴇ ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴘᴜɴʏᴀ ᴀᴋsᴇs ᴜʙᴏᴛ.\n` +
        `ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ᴜɴᴛᴜᴋ ᴜᴘɢʀᴀᴅᴇ.`
      );
    } else {
      caption = quote(
        `🤖 <b>ʙᴜᴀᴛ ᴜsᴇʀʙᴏᴛ</b>\n⏣────────────────⏣\n\n` +
        `ᴋᴇᴛɪᴋ <code>/connect</code> ᴜɴᴛᴜᴋ ᴍᴜʟᴀɪ ᴍᴇɴʏᴀᴍʙᴜɴɢᴋᴀɴ ᴜʙᴏᴛ ᴋᴀᴍᴜ.\n\n` +
        `ᴘʀᴏsᴇs: ᴀᴘɪ ɪᴅ → ᴀᴘɪ ʜᴀsʜ → ɴᴏᴍᴏʀ → ᴏᴛᴘ.`
      );
    }
  } else if (tab === "settings") {
    const th = themeStore.getTheme(userId);
    const cur = themes.get(th);
    caption = quote(
      `⚙️ <b>SETTINGS</b>\n⏣────────────────⏣\n\n` +
      `Atur tampilan menu kamu di sini.\n\n` +
      `🎨 Tema sekarang: <b>${esc(cur.name)}</b>`
    );
    buttons = [
      [Button.inline("🎨 Custom Theme", Buffer.from("tab_theme"))],
      [Button.inline("🧩 Button & Addon", Buffer.from("tab_addon"))],
      [Button.inline("🎛 Custom", Buffer.from("tab_custom"))],
      [Button.inline("🔒 Privacy", Buffer.from("tab_privacy"))],
      [Button.inline("« Kembali", Buffer.from("tab_main"))],
    ];
    if (db.OWNER_IDS.includes(userId)) buttons.splice(4, 0, [Button.inline("🎁 Giveaway", Buffer.from("tab_giveaway"))]);
  } else if (tab === "custom") {
    const a = addonStore.getAddon(userId);
    const isOwner = db.OWNER_IDS.includes(userId);
    const cc = customStore.get();
    let capt =
      `🎛 <b>CUSTOM</b>\n⏣────────────────⏣\n\n` +
      `Atur tata letak tombol module di menu <code>${PREFIX}help</code>.\n\n` +
      `📐 Layout sekarang: <b>${a.btnCols}:${a.btnRows}</b> (${a.btnCols} kolom × ${a.btnRows} baris = ${a.btnCols * a.btnRows} tombol/hal)\n`;
    if (isOwner) {
      capt +=
        `\n👑 <b>KHUSUS PEMILIK</b>\n` +
        `🔒 Join First: <b>${cc.joinFirst.enabled ? "✅ Aktif" : "❌ Nonaktif"}</b> (${cc.joinFirst.chats.length}/3 chat)\n` +
        `💳 QRIS: <b>${cc.qrisSet ? "✅ Terpasang" : "❌ Belum"}</b>\n` +
        `\n<i>Tombol hijau = channel/grup wajib-join. Tap buat hapus. Tap ➕ buat nambah (max 3).</i>\n`;
    }
    capt += `\n<i>Format K:B → K kolom, B baris. Tap salah satu di bawah.</i>`;
    caption = quote(capt);
    const rows = [];
    for (let c = 1; c <= 4; c++) {
      const r = [];
      for (let b = 1; b <= 4; b++) {
        const sel = (a.btnCols === c && a.btnRows === b) ? "✅ " : "";
        r.push(Button.inline(`${sel}${c}:${b}`, Buffer.from(`cust_layout:${c}:${b}`)));
      }
      rows.push(r);
    }
    if (isOwner) {
      rows.push([Button.inline(cc.joinFirst.enabled ? "🔒 Matikan Join First" : "🔒 Nyalakan Join First", Buffer.from("cust_jf_toggle"))]);
      cc.joinFirst.chats.forEach((ch, i) => {
        rows.push([cBtn("✅ " + (ch.title || ch.link || ("Chat " + (i + 1))), "cust_jf_del:" + i, "success")]);
      });
      if (cc.joinFirst.chats.length < 3) rows.push([cBtn("➕ Tambah Channel/Grup", "cust_jf_set", "primary")]);
      rows.push([Button.inline(cc.qrisSet ? "💳 Ganti QRIS" : "💳 Set QRIS", Buffer.from("cust_qris_set"))]);
    }
    rows.push([Button.inline("« Kembali", Buffer.from("tab_settings"))]);
    buttons = rows;
  } else if (tab === "privacy") {
    const p = privacyStore.get(userId);
    const onoff = (v) => v ? "✅ Aktif" : "❌ Nonaktif";
    caption = quote(
      `🔒 <b>PRIVACY</b>\n⏣────────────────⏣\n\n` +
      `Atur privasi userbot kamu. Semua default OFF.\n\n` +
      `🔘 Only you can press: <b>${onoff(p.onlyMe)}</b>\n` +
      `🧹 Auto-hapus perintah: <b>${onoff(p.hapusCmd)}</b>\n` +
      `🚫 Anti-PM asing: <b>${onoff(p.antiPM)}</b>\n` +
      `📥 Rekam PM asing: <b>${onoff(p.logPM)}</b>\n` +
      `⛔ Blokir PM asing: <b>${onoff(p.blokirAsing)}</b>\n\n` +
      `<i>Tap buat nyalain/matiin.</i>`
    );
    buttons = [
      [Button.inline(`${p.onlyMe ? "✅" : "⬜"} Only you can press`, Buffer.from("priv_onlyMe"))],
      [Button.inline(`${p.hapusCmd ? "✅" : "⬜"} Auto-hapus perintah`, Buffer.from("priv_hapusCmd"))],
      [Button.inline(`${p.antiPM ? "✅" : "⬜"} Anti-PM asing`, Buffer.from("priv_antiPM"))],
      [Button.inline(`${p.logPM ? "✅" : "⬜"} Rekam PM asing`, Buffer.from("priv_logPM"))],
      [Button.inline(`${p.blokirAsing ? "✅" : "⬜"} Blokir PM asing`, Buffer.from("priv_blokirAsing"))],
      [Button.inline("« Kembali", Buffer.from("tab_settings"))],
    ];
  } else if (tab === "addon") {
    const a = addonStore.getAddon(userId);
    const grup = (process.env.GRUP_UBOT || "").trim();
    const stat = (hidden) => hidden ? "❌ Disembunyikan" : "✅ Tampil";
    const lines = [
      `🧩 <b>BUTTON & ADDON</b>\n⏣────────────────⏣\n`,
      `Atur tombol yang muncul di menu <code>${PREFIX}help</code> userbot kamu.\n`,
      `📂 Open Perfolder: <b>${stat(a.hidePerfolder)}</b>`,
    ];
    if (grup) lines.push(`👥 Join Grup: <b>${stat(a.hideJoinGrup)}</b>`);
    lines.push(`🔤 Autocorrect (saran "Maksud lu"): <b>${a.autocorrect ? "✅ Aktif" : "❌ Nonaktif"}</b>`);
    lines.push(`✨ Emoji Prem (emoji premium di semua pesan): <b>${a.emojiPrem ? "✅ Aktif" : "❌ Nonaktif"}</b>`);
    lines.push(`\n<i>Tap tombol di bawah untuk atur.</i>`);
    caption = quote(lines.join("\n"));
    const rows = [
      [Button.inline(a.hidePerfolder ? "➕ Tampilkan Tombol Open Perfolder" : "🗑 Hapus Tombol Open Perfolder", Buffer.from("addon_pf"))],
    ];
    if (grup) {
      rows.push([Button.inline(a.hideJoinGrup ? "➕ Tampilkan Tombol Join Grup" : "🗑 Hapus Tombol Join Grup", Buffer.from("addon_jg"))]);
    }
    const allHidden = a.hidePerfolder && (!grup || a.hideJoinGrup);
    rows.push([Button.inline(allHidden ? "➕ Tampilkan Semua Tombol" : "🗑 Hapus Tombol Tidak Diperlukan", Buffer.from("addon_clean"))]);
    rows.push([Button.inline(a.autocorrect ? "🔤 Matikan Autocorrect" : "🔤 Nyalakan Autocorrect", Buffer.from("addon_ac"))]);
    rows.push([Button.inline(a.emojiPrem ? "✨ Matikan Emoji Prem" : "✨ Nyalakan Emoji Prem", Buffer.from("addon_ep"))]);
    rows.push([Button.inline(`🎨 Warna Tombol ${PREFIX}help`, Buffer.from("tab_btncolor"))]);
    rows.push([Button.inline("« Kembali", Buffer.from("tab_settings"))]);
    buttons = rows;
  } else if (tab === "btncolor") {
    const cur = btnColorStore.getStyle(userId);
    const label = { auto: "🌈 Auto", primary: "🔵 Biru", success: "🟢 Hijau", danger: "🔴 Merah", cycle: "🪩 Disko", off: "⬜ Polos" };
    caption = quote(
      `🎨 <b>WARNA TOMBOL ${PREFIX}help</b>\n⏣────────────────⏣\n\n` +
      `Atur warna tombol module di menu ${PREFIX}help.\n\n` +
      `Sekarang: <b>${label[cur] || cur}</b>\n\n` +
      `Disko = warna semua tombol ganti sendiri tiap 3 detik.`
    );
    const opt = (id, txt) => Button.inline((cur === id ? "✅ " : "") + txt, Buffer.from("bc_" + id));
    buttons = [
      [opt("auto", "🌈 Auto"), opt("cycle", "🪩 Disko")],
      [opt("primary", "🔵 Biru"), opt("success", "🟢 Hijau"), opt("danger", "🔴 Merah")],
      [opt("off", "⬜ Polos")],
      [Button.inline("« Kembali", Buffer.from("tab_addon"))],
    ];
  } else if (tab === "theme") {
    const th = themeStore.getTheme(userId);
    const list = themes.THEMES.map((t) => `${t.id === th ? "✅" : "▫️"} <b>${esc(t.name)}</b> — ${esc(t.desc)}`).join("\n");
    caption = quote(
      `🎨 <b>CUSTOM THEME</b>\n⏣────────────────⏣\n\n` +
      `Pilih tema buat tampilan menu. Otomatis kesimpen & kepakai tiap kamu buka bot.\n\n` +
      `${list}`
    );
    const rows = [];
    for (let i = 0; i < themes.THEMES.length; i += 2) {
      rows.push(
        themes.THEMES.slice(i, i + 2).map((t) =>
          Button.inline(`${t.id === th ? "✅ " : ""}${t.name}`, Buffer.from("settheme_" + t.id))
        )
      );
    }
    rows.push([Button.inline("« Kembali", Buffer.from("tab_settings"))]);
    buttons = rows;
  } else if (tab === "giveaway") {
    if (!db.OWNER_IDS.includes(userId)) {
      caption = quote("❌ Fitur ini khusus pemilik.");
      buttons = [[Button.inline("« Kembali", Buffer.from("tab_settings"))]];
    } else {
      const v = gaMenuView();
      caption = v.text;
      buttons = v.buttons;
    }
  }

  await editView(event, caption, buttons, true);
}

async function send(userId, html, peer) {
  try {
    const target = await bot.getInputEntity(peer || parseInt(userId));
    await bot.sendMessage(target, { message: quote(html), parseMode: "html" });
  } catch (e) {
    console.error("send error:", e.message);
  }
}

async function handleConnect(userId, peer) {
  if (!db.canUseUbot(userId)) {
    return send(userId, `❌ ʀᴏʟᴇ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴘᴜɴʏᴀ ᴀᴋsᴇs ᴜʙᴏᴛ.`, peer);
  }
  if (ubotMgr.getUbotStatus(userId)) {
    return send(userId, `⚠️ ᴜʙᴏᴛ ᴋᴀᴍᴜ sᴜᴅᴀʜ ᴀᴋᴛɪꜰ. ᴘᴀᴋᴀɪ <code>/disconnect</code> ᴅᴜʟᴜ.`, peer);
  }

  try {
    const target = await bot.getInputEntity(peer || parseInt(userId));
    await bot.sendMessage(target, {
      message:
        `<blockquote><b>🔗 <b>SAMBUNGKAN UBOT</b>\n\n` +
        `Pilih metode koneksi:\n\n` +
        `⚡ <b>Cepat</b> — cukup nomor + OTP (pakai API bawaan)\n` +
        `🔧 <b>Manual</b> — pakai API ID & Hash sendiri (lebih aman)</b></blockquote>`,
      parseMode: "html",
      buttons: [
        [Button.inline("⚡ Cepat (Nomor + OTP)", Buffer.from("conn_default"))],
        [Button.inline("🔧 Manual (API Sendiri)", Buffer.from("conn_own"))],
        [Button.inline("✕ Batal", Buffer.from("conn_cancel"))],
      ],
    });
  } catch (e) {
    console.error("handleConnect error:", e.message);
  }
}

async function handleLoginStep(userId, text, peer) {
  const state = loginState.get(userId);
  if (!state) return false;

  if (text === "/cancel") {
    if (state.client) { try { await state.client.disconnect(); } catch {} }
    loginState.delete(userId);
    await send(userId, `❌ ᴘʀᴏsᴇs ᴅɪʙᴀᴛᴀʟᴋᴀɴ.`, peer);
    return true;
  }

  try {
    if (state.step === "apiId") {
      const apiId = parseInt(text.trim());
      if (isNaN(apiId)) { await send(userId, `❌ ᴀᴘɪ ɪᴅ ʜᴀʀᴜs ᴀɴɢᴋᴀ. ᴄᴏʙᴀ ʟᴀɢɪ:`, peer); return true; }
      state.apiId = apiId; state.step = "apiHash";
      await send(userId, `✅ ᴀᴘɪ ɪᴅ ᴛᴇʀsɪᴍᴘᴀɴ.\n\nʟᴀɴɢᴋᴀʜ 2/4: ᴋɪʀɪᴍ <b>ᴀᴘɪ ʜᴀsʜ</b>.`, peer);
      return true;
    }
    if (state.step === "apiHash") {
      state.apiHash = text.trim(); state.step = "phone";
      await send(userId, `✅ ᴀᴘɪ ʜᴀsʜ ᴛᴇʀsɪᴍᴘᴀɴ.\n\nʟᴀɴɢᴋᴀʜ 3/4: ᴋɪʀɪᴍ <b>ɴᴏᴍᴏʀ ʜᴘ</b> (ꜰᴏʀᴍᴀᴛ +62...).`, peer);
      return true;
    }
    if (state.step === "phone") {
      state.phone = text.trim();
      const client = new TelegramClient(new StringSession(""), state.apiId, state.apiHash, { connectionRetries: 3 });
      await client.connect();
      state.client = client;
      const result = await client.invoke(new Api.auth.SendCode({
        phoneNumber: state.phone, apiId: state.apiId, apiHash: state.apiHash,
        settings: new Api.CodeSettings({}),
      }));
      state.phoneCodeHash = result.phoneCodeHash; state.step = "otp";
      await send(userId,
        `📨 <b>ᴋᴏᴅᴇ ᴏᴛᴘ ᴅɪᴋɪʀɪᴍ!</b>\n\n` +
        `ʟᴀɴɢᴋᴀʜ 4/4: ᴄᴇᴋ ᴛᴇʟᴇɢʀᴀᴍ ᴋᴀᴍᴜ, ʟᴀʟᴜ ᴋɪʀɪᴍ ᴋᴏᴅᴇ ᴏᴛᴘ.\n\n` +
        `⚠️ <i>ᴘɪsᴀʜᴋᴀɴ ᴀɴɢᴋᴀ ᴅᴇɴɢᴀɴ sᴘᴀsɪ (ᴄᴏɴᴛᴏʜ: 1 2 3 4 5).</i>`,
        peer
      );
      return true;
    }
    if (state.step === "otp") {
      const code = text.replace(/\s/g, "").trim();
      try {
        await state.client.invoke(new Api.auth.SignIn({
          phoneNumber: state.phone, phoneCodeHash: state.phoneCodeHash, phoneCode: code,
        }));
      } catch (e) {
        if (e.errorMessage === "SESSION_PASSWORD_NEEDED") {
          state.step = "password";
          await send(userId, `🔑 ᴀᴋᴜɴ ᴘᴀᴋᴀɪ 2ꜰᴀ.\n\nᴋɪʀɪᴍ <b>ᴘᴀssᴡᴏʀᴅ 2ꜰᴀ</b> ᴋᴀᴍᴜ.`, peer);
          return true;
        }
        throw e;
      }
      await finishLogin(userId, peer);
      return true;
    }
    if (state.step === "password") {
      const { computeCheck } = require("telegram/Password");
      const pwd = await state.client.invoke(new Api.account.GetPassword());
      const check = await computeCheck(pwd, text.trim());
      await state.client.invoke(new Api.auth.CheckPassword({ password: check }));
      await finishLogin(userId, peer);
      return true;
    }
  } catch (e) {
    console.error("login step error:", e.message);
    await send(userId, `❌ ᴇʀᴏʀ: ${esc(e.message)}\n\nᴘʀᴏsᴇs ᴅɪʙᴀᴛᴀʟᴋᴀɴ.`, peer);
    if (state.client) { try { await state.client.disconnect(); } catch {} }
    loginState.delete(userId);
    return true;
  }
  return true;
}

async function finishLogin(userId, peer) {
  const state = loginState.get(userId);
  const sessionStr = state.client.session.save();
  db.saveSession(userId, sessionStr, { apiId: state.apiId, apiHash: state.apiHash, phone: state.phone });
  await state.client.disconnect();
  loginState.delete(userId);
  const res = await ubotMgr.startUbot(userId, sessionStr, state.apiId, state.apiHash);

  const usingManagerApi = String(state.apiId) === String(API_ID);
  const apiWarning = usingManagerApi
    ? `\n\n⚠️ <b>ᴘᴇʀʜᴀᴛɪᴀɴ:</b> ᴋᴀᴍᴜ ᴘᴀᴋᴀɪ ᴀᴘɪ ʙᴀᴡᴀᴀɴ (sʜᴀʀɪɴɢ ᴅᴇɴɢᴀɴ ᴜsᴇʀ ʟᴀɪɴ). ` +
      `ᴋᴀʟᴀᴜ ᴀᴘɪ-ɴʏᴀ ᴋᴇɴᴀ ʟɪᴍɪᴛ/ʙᴀɴ, <b>ᴄꜰᴅ & sᴇᴍᴜᴀ ᴄᴏᴍᴍᴀɴᴅ ʙɪsᴀ ᴇʀʀᴏʀ</b>. ` +
      `ʟᴇʙɪʜ ᴀᴍᴀɴ & sᴛᴀʙɪʟ: ᴘᴀᴋᴀɪ ᴀᴘɪ sᴇɴᴅɪʀɪ → <code>/connect</code> → ᴘɪʟɪʜ 🔧 ᴍᴀɴᴜᴀʟ.`
    : `\n\n✅ ᴋᴀᴍᴜ ᴘᴀᴋᴀɪ ᴀᴘɪ sᴇɴᴅɪʀɪ — ᴘᴀʟɪɴɢ sᴛᴀʙɪʟ, ᴛɪᴅᴀᴋ ᴛᴇʀᴘᴇɴɢᴀʀᴜʜ ʟɪᴍɪᴛ ᴜsᴇʀ ʟᴀɪɴ.`;

  if (res.ok) {
    const okText =
      `✅ <b>ᴜʙᴏᴛ ʙᴇʀʜᴀsɪʟ ᴛᴇʀsᴀᴍʙᴜɴɢ!</b>\n\n` +
      `ᴀᴋᴜɴ: <b>${esc(res.me?.firstName || "")}</b>\n` +
      `ᴄᴏʙᴀ ᴋᴇᴛɪᴋ <code>${ubotMgr.PREFIX}help</code> ᴅɪ ᴛᴇʟᴇɢʀᴀᴍ ᴋᴀᴍᴜ.` +
      apiWarning;
    const grup = (process.env.GRUP_UBOT || "").trim();
    if (grup) {
      try {
        const peerEnt = await bot.getInputEntity(peer);
        await bot.sendMessage(peerEnt, { message: okText, parseMode: "html", buttons: [[Button.url("👥 Join Grup", grup)]] });
      } catch { await send(userId, okText, peer); }
    } else {
      await send(userId, okText, peer);
    }
  } else {
    await send(userId, `⚠️ sᴇssɪᴏɴ ᴛᴇʀsɪᴍᴘᴀɴ ᴛᴀᴘɪ ɢᴀɢᴀʟ sᴛᴀʀᴛ: ${esc(res.error)}`, peer);
  }
}

async function handleAddRole(userId, targetRole, args, peer) {
  if (!db.canAddRole(userId, targetRole)) {
    return send(userId, `❌ ʀᴏʟᴇ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ <b>${targetRole}</b>.`, peer);
  }
  const targetId = args[0];
  if (!targetId || isNaN(parseInt(targetId))) {
    return send(userId, `❌ ꜰᴏʀᴍᴀᴛ: <code>/add${targetRole} &lt;user_id&gt; [hari]</code>`, peer);
  }
  const days = args[1] ? parseInt(args[1]) : 30;
  if (isNaN(days) || days < 1) return send(userId, `❌ ᴅᴜʀᴀsɪ ʜᴀʀɪ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ.`, peer);
  const added = db.addUser(targetId, targetRole, userId, days);
  const expDate = new Date(added.expiresAt).toLocaleDateString("id-ID", {
    day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta",
  });
  await send(userId,
    `✅ <b>${targetRole} ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ</b>\n\n` +
    `ᴜsᴇʀ ɪᴅ: <code>${targetId}</code>\n` +
    `ʀᴏʟᴇ: <b>${targetRole}</b>\n` +
    `ᴀᴋᴛɪꜰ: <b>${days} ʜᴀʀɪ</b> (sᴀᴍᴘᴀɪ ${expDate})`,
    peer
  );
  await send(targetId, `🎉 ᴋᴀᴍᴜ ᴍᴇɴᴅᴀᴘᴀᴛ ʀᴏʟᴇ <b>${targetRole}</b> sᴇʟᴀᴍᴀ ${days} ʜᴀʀɪ!\nᴋᴇᴛɪᴋ /start ᴜɴᴛᴜᴋ ᴍᴜʟᴀɪ.`);
}

async function handleRemove(userId, args, peer) {
  const role = db.getRole(userId);
  if (db.ROLES[role] < db.ROLES.reseller) {
    return send(userId, `❌ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴘᴜɴʏᴀ ɪᴢɪɴ ᴍᴇɴɢʜᴀᴘᴜs ᴜsᴇʀ.`, peer);
  }
  const targetId = args[0];
  if (!targetId) return send(userId, `❌ ꜰᴏʀᴍᴀᴛ: <code>/remove &lt;user_id&gt;</code>`, peer);
  const targetRole = db.getRole(targetId);
  if (db.ROLES[targetRole] >= db.ROLES[role]) {
    return send(userId, `❌ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴍᴇɴɢʜᴀᴘᴜs ᴜsᴇʀ ᴅᴇɴɢᴀɴ ʀᴏʟᴇ sᴇᴛᴀʀᴀ/ʟᴇʙɪʜ ᴛɪɴɢɢɪ.`, peer);
  }
  const ok = db.removeUser(targetId);
  if (ok) {
    await ubotMgr.stopUbot(targetId);
    await send(userId, `✅ ᴜsᴇʀ <code>${targetId}</code> ᴛᴇʟᴀʜ ᴅɪʜᴀᴘᴜs.`, peer);
  } else {
    await send(userId, `❌ ɢᴀɢᴀʟ ᴍᴇɴɢʜᴀᴘᴜs (ᴍᴜɴɢᴋɪɴ ᴏᴡɴᴇʀ).`, peer);
  }
}

async function handleListRole(userId, targetRole, peer) {
  const role = db.getRole(userId);
  if (db.ROLES[role] < db.ROLES.reseller) {
    return send(userId, `❌ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴘᴜɴʏᴀ ɪᴢɪɴ ᴍᴇʟɪʜᴀᴛ ᴅᴀꜰᴛᴀʀ.`, peer);
  }
  const users = db.getUsersByRole(targetRole);
  if (!users.length) return send(userId, `📋 ʙᴇʟᴜᴍ ᴀᴅᴀ ᴜsᴇʀ ᴅᴇɴɢᴀɴ ʀᴏʟᴇ <b>${targetRole}</b>.`, peer);
  const lines = [`📋 <b>ᴅᴀꜰᴛᴀʀ ${targetRole}</b> (${users.length})\n`];
  users.forEach((u, i) => {
    const exp = u.expiresAt
      ? new Date(u.expiresAt).toLocaleDateString("id-ID", { day: "numeric", month: "short", timeZone: "Asia/Jakarta" })
      : "permanen";
    lines.push(`${i + 1}. <code>${u.id}</code> — exp: ${exp}`);
  });
  await send(userId, lines.join("\n"), peer);
}

async function handleMyUbot(userId, peer) {
  if (!db.canUseUbot(userId)) return send(userId, `❌ ʀᴏʟᴇ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴘᴜɴʏᴀ ᴀᴋsᴇs ᴜʙᴏᴛ.`, peer);
  const status = ubotMgr.getUbotStatus(userId);
  if (!status) return send(userId, `📴 ᴜʙᴏᴛ ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴀᴋᴛɪꜰ. ᴘᴀᴋᴀɪ <code>/connect</code>.`, peer);
  const h = Math.floor(status.uptime / 3600000);
  const m = Math.floor((status.uptime % 3600000) / 60000);
  await send(userId,
    `🟢 <b>ᴜʙᴏᴛ ᴀᴋᴛɪꜰ</b>\n\nᴀᴋᴜɴ: <b>${esc(status.name)}</b>\n` +
    `ᴜsᴇʀɴᴀᴍᴇ: @${esc(status.username || "-")}\nᴜᴘᴛɪᴍᴇ: ${h}ᴊ ${m}ᴍ`,
    peer
  );
}

async function handleDisconnect(userId, peer) {
  const stopped = await ubotMgr.stopUbot(userId);
  db.deleteSession(userId);
  await send(userId, stopped ? `🛑 ᴜʙᴏᴛ ᴋᴀᴍᴜ ᴛᴇʟᴀʜ ᴅɪᴘᴜᴛᴜs.` : `ℹ️ ᴜʙᴏᴛ ᴋᴀᴍᴜ ᴍᴇᴍᴀɴɢ ᴛɪᴅᴀᴋ ᴀᴋᴛɪꜰ.`, peer);
}

async function handleAddLimit(userId, args, peer) {
  if (!db.OWNER_IDS.includes(userId)) {
    return send(userId, `❌ Hanya owner yang bisa menambah limit.`, peer);
  }
  const targetId = args[0];
  const amount = parseInt(args[1]);
  if (!targetId || isNaN(amount)) {
    return send(userId, `❌ Format: <code>/addlimit &lt;id&gt; &lt;jumlah&gt;</code>`, peer);
  }
  const newLimit = db.setLimit(targetId, amount);
  await send(userId,
    `✅ <b>Limit Diset</b>\n\n` +
    `User ID: <code>${targetId}</code>\n` +
    `Limit sandbox: <b>${newLimit}</b> project`,
    peer
  );
  await send(targetId, `🎉 Kamu dapat limit sandbox <b>${newLimit}</b> project! Ketik /sandbox untuk mulai.`);
}

const KEY_CAPS = {
  send_text:   "💬 Kirim Teks",
  reply:       "↩️ Balas Pesan",
  forward:     "📤 Forward Pesan",
  delete:      "🗑️ Hapus Pesan",
  react:       "👍 Kasih Reaksi",
  pin:         "📌 Pin Pesan",
  mention_all: "📢 Tag Semua Member",
  get_info:    "ℹ️ Ambil Info Chat/User",
  spam:        "🔁 Spam Pesan",
  ban:         "🔨 Ban Member",
  kick:        "👢 Kick Member",
  mute:        "🔇 Mute Member",
};

async function showKeyCaps(userId, peer, event) {
  const state = sandboxState.get(userId);
  if (!state?.keyDraft) return;
  const caps = state.keyDraft.capabilities || [];

  const text =
    `🔑 <b>KEY: ${esc(state.keyDraft.name)}</b>\n` +
    `⏣────────────────⏣\n\n` +
    `Pilih apa saja yang bisa dilakukan key ini.\n` +
    `Centang lalu tekan <b>Simpan Key</b>:\n\n` +
    `<b>Terpilih:</b> ${caps.length ? caps.length + " aksi" : "belum ada"}`;

  const capKeys = Object.keys(KEY_CAPS);
  const rows = [];
  for (let i = 0; i < capKeys.length; i += 2) {
    const row = [];
    for (let j = i; j < Math.min(i + 2, capKeys.length); j++) {
      const k = capKeys[j];
      const on = caps.includes(k);
      row.push(Button.inline((on ? "✅ " : "⬜ ") + KEY_CAPS[k], Buffer.from("sb_keycap:" + k)));
    }
    rows.push(row);
  }
  rows.push([Button.inline("💾 Simpan Key", Buffer.from("sb_savekey"))]);
  rows.push([Button.inline("✕ Batal", Buffer.from("sb_cancelkey"))]);

  await sbView(userId, peer, text, rows, event);
}

async function showTabStyle(userId, peer, event) {
  const st = sandboxState.get(userId);
  if (!st?.tabDraft) return;
  const d = st.tabDraft;
  const text =
    `📑 <b>TAB: ${esc(d.name)}</b>\n` +
    `⏣────────────────⏣\n\n` +
    `<b>Teks:</b> ${d.text ? esc(d.text.slice(0, 40)) + (d.text.length > 40 ? "..." : "") : "(belum ada)"}\n` +
    `<b>Foto:</b> ${d.photo ? "✅ ada" : "⬜ belum"}\n\n` +
    `<b>Gaya tampilan:</b>\n` +
    `${d.quote ? "✅" : "⬜"} Kutip (blockquote)\n` +
    `${d.bold ? "✅" : "⬜"} Tebal (bold)\n` +
    `${d.smallcaps ? "✅" : "⬜"} Font kecil (small caps)\n\n` +
    `<i>Atur gaya lalu Simpan Tab.</i>`;
  const rows = [
    [Button.inline((d.quote ? "✅" : "⬜") + " Kutip", Buffer.from("sb_tabsty:quote")),
     Button.inline((d.bold ? "✅" : "⬜") + " Tebal", Buffer.from("sb_tabsty:bold"))],
    [Button.inline((d.smallcaps ? "✅" : "⬜") + " Font Kecil", Buffer.from("sb_tabsty:smallcaps"))],
    [Button.inline("📝 Set Teks", Buffer.from("sb_tabtext")),
     Button.inline("🖼️ Set Foto", Buffer.from("sb_tabphoto"))],
    [Button.inline("💾 Simpan Tab", Buffer.from("sb_savetab"))],
    [Button.inline("✕ Batal", Buffer.from("sb_canceltab"))],
  ];
  await sbView(userId, peer, text, rows, event);
}

async function showProjectContent(userId, peer, projectId, event) {
  const p = sandbox.getProject(userId, projectId);
  if (!p) return;
  const lines = [
    `📋 <b>ISI PROJECT — ${esc(p.name)}</b>`,
    `⏣────────────────⏣\n`,
  ];
  lines.push(`<b>🔑 Keys (${p.keys.length}):</b>`);
  if (p.keys.length) p.keys.forEach(k => lines.push(`  • <code>${esc(p.prefix + k.name)}</code> (${k.capabilities.length} aksi)`));
  else lines.push(`  <i>belum ada</i>`);
  lines.push(`\n<b>📑 Tabs (${p.tabs.length}):</b>`);
  if (p.tabs.length) p.tabs.forEach(t => {
    const sty = [t.quote && "kutip", t.bold && "tebal", t.smallcaps && "kecil"].filter(Boolean).join("+") || "polos";
    lines.push(`  • <b>${esc(t.name)}</b> [${sty}]${t.photo ? " 🖼️" : ""} — ${t.buttons.length} tombol`);
  });
  else lines.push(`  <i>belum ada</i>`);

  const buttons = [[Button.inline("« Kembali ke Edit", Buffer.from("sb_edit:" + projectId))]];
  await sbView(userId, peer, lines.join("\n"), buttons, event);
}



async function handleSandbox(userId, peer, event) {
  await sbView(userId, peer, `🛠️ <b>Sandbox</b>\n\n<i>Fitur sandbox tidak tersedia di build ini.</i>`, [[Button.inline("« Tutup", Buffer.from("sb_close"))]], event);
}

async function sandboxStartNew(userId, peer, event) {
  const projects = sandbox.getProjects(userId);
  const limit = db.getLimit(userId);
  if (projects.length >= limit) {
    return sbView(userId, peer, `❌ Limit project habis (${projects.length}/${limit === Infinity ? "∞" : limit}). Hubungi owner.`, [[Button.inline("« Tutup", Buffer.from("sb_close"))]], event);
  }
  sandboxState.set(userId, { step: "name", draft: { features: {} }, peer });
  await sbPrompt(userId, peer,
    `🛠️ <b>BUAT PROJECT BARU</b>\n\n` +
    `Langkah 1/3: Kirim <b>nama project/ubot</b> kamu.\n\n` +
    `Ketik /cancel untuk batal.`,
    "sb_cancelnew", event
  );
}

async function showEditMode(userId, peer, projectId, event) {
  const project = sandbox.getProject(userId, projectId);
  if (!project) {
    return send(userId, `❌ Project tidak ditemukan.`, peer);
  }
  sandboxState.set(userId, { step: "edit", projectId, peer });

  const f = project.features || {};
  const featList = [];
  if (f.noApi) featList.push("✅ Connect tanpa API ID/Hash");

  const aktif = !!project.active || sandbox.getProjects(userId).length === 1;
  const text =
    `✏️ <b>EDIT MODE — ${esc(project.name)}</b>\n` +
    `⏣────────────────⏣\n\n` +
    `<b>Status:</b> ${aktif ? "🟢 AKTIF (dipakai ubot kamu)" : "⚪ nonaktif"}\n` +
    `<b>Prefix:</b> <code>${esc(project.prefix)}</code>\n` +
    `<b>Keys (command):</b> ${project.keys.length}\n` +
    `<b>Tabs:</b> ${project.tabs.length}\n` +
    `<b>Fitur:</b> ${featList.length ? featList.join(", ") : "-"}\n\n` +
    (project.keys.length
      ? `<i>Ubot kamu akan jalanin command: ${project.keys.slice(0, 6).map((k) => "<code>" + esc(project.prefix + k.name) + "</code>").join(", ")}${project.keys.length > 6 ? "…" : ""}</i>`
      : `<i>💡 Belum ada command. Tekan <b>🤖 Build by AI</b> biar AI bikinin otomatis, atau <b>Add Key</b> manual.</i>`);

  const buttons = [];
  if (!project.aiUsed) buttons.push([Button.inline("🤖 Build by AI (sekali pakai)", Buffer.from("sb_ai:" + projectId))]);
  buttons.push([Button.inline(aktif ? "🟢 Ubot Aktif (project ini)" : "▶️ Jalankan Ubot Ini", Buffer.from("sb_activate:" + projectId))]);
  buttons.push(
    [Button.inline("🔑 Add Key", Buffer.from("sb_addkey:" + projectId)),
     Button.inline("📑 Add Tab", Buffer.from("sb_addtab:" + projectId))],
    [Button.inline("🔘 Add Button", Buffer.from("sb_addbtn:" + projectId)),
     Button.inline("🖼️ Add Photo", Buffer.from("sb_addphoto:" + projectId))],
    [Button.inline("✏️ Edit", Buffer.from("sb_editmenu:" + projectId)),
     Button.inline("📋 Lihat Isi", Buffer.from("sb_view:" + projectId))],
    [Button.inline("💾 Save", Buffer.from("sb_save:" + projectId)),
     Button.inline("🗑️ Delete", Buffer.from("sb_del:" + projectId))],
    [Button.inline("✕ Cancel", Buffer.from("sb_cancel:" + projectId))],
  );

  await sbView(userId, peer, text, buttons, event);
}

async function showEditMenu(userId, peer, projectId, event) {
  const project = sandbox.getProject(userId, projectId);
  if (!project) return;
  sandboxState.set(userId, { step: "editmenu", projectId, peer });

  const text =
    `✏️ <b>EDIT — ${esc(project.name)}</b>\n` +
    `⏣────────────────⏣\n\n` +
    `Pilih apa yang mau diedit:\n\n` +
    `🔑 Keys: ${project.keys.length}\n` +
    `📑 Tabs: ${project.tabs.length}\n` +
    `🔘 Buttons: ${(project.buttons || []).length}`;

  const buttons = [
    [Button.inline("🔑 Edit Key", Buffer.from("sb_editkey:" + projectId))],
    [Button.inline("📑 Edit Tab", Buffer.from("sb_edittab:" + projectId))],
    [Button.inline("🔘 Edit Button", Buffer.from("sb_editbtn:" + projectId))],
    [Button.inline("« Kembali", Buffer.from("sb_edit:" + projectId))],
  ];
  await sbView(userId, peer, text, buttons, event);
}

async function showEditKeyList(userId, peer, projectId, event) {
  const project = sandbox.getProject(userId, projectId);
  if (!project) return;

  if (!project.keys.length) {
    return sbView(userId, peer,
      `🔑 <b>EDIT KEY</b>\n⏣────────────────⏣\n\n` +
      `Kamu belum punya key.\n` +
      `Buat dulu lewat <b>Add Key</b> di menu Edit Mode.`,
      [[Button.inline("« Kembali", Buffer.from("sb_editmenu:" + projectId))]],
      event
    );
  }

  const text = `🔑 <b>EDIT KEY</b>\n⏣────────────────⏣\n\nPilih key yang mau diedit:`;
  const buttons = project.keys.map(k =>
    [Button.inline(`🔑 ${k.name} (${k.capabilities.length} aksi)`, Buffer.from("sb_pickkey:" + projectId + ":" + k.name))]
  );
  buttons.push([Button.inline("« Kembali", Buffer.from("sb_editmenu:" + projectId))]);
  await sbView(userId, peer, text, buttons, event);
}

async function showKeyEditor(userId, peer, projectId, keyName, event) {
  const project = sandbox.getProject(userId, projectId);
  if (!project) return;
  const key = project.keys.find(k => k.name === keyName);
  if (!key) {
    return sbView(userId, peer, `❌ Key tidak ditemukan.`,
      [[Button.inline("« Kembali", Buffer.from("sb_editkey:" + projectId))]], event);
  }

  let state = sandboxState.get(userId);
  if (!state || state.editKeyName !== keyName || !state.keyDraft) {
    state = {
      step: "keyedit", projectId, peer,
      editKeyName: keyName,
      keyDraft: {
        name: key.name,
        capabilities: [...(key.capabilities || [])],
        config: { ...(key.config || {}) },
      },
    };
    sandboxState.set(userId, state);
  } else {
    state.step = "keyedit";
  }

  const draft = state.keyDraft;
  const caps = draft.capabilities || [];
  const cfg = draft.config || {};

  const text =
    `🔑 <b>EDIT KEY: ${esc(key.name)}</b>\n` +
    `⏣────────────────⏣\n\n` +
    `<b>Trigger:</b> <code>${esc(project.prefix + key.name)}</code>\n` +
    `<b>Aksi terpilih:</b> ${caps.length ? caps.map(c => KEY_CAPS[c] || c).join(", ") : "belum ada"}\n\n` +
    `<b>📝 Teks respons:</b>\n${cfg.text ? esc(cfg.text.slice(0, 120)) : "<i>(belum diatur)</i>"}\n\n` +
    `<i>Atur aksi (centang) & teks respons di bawah, lalu Simpan:</i>`;

  const capKeys = Object.keys(KEY_CAPS);
  const rows = [];
  for (let i = 0; i < capKeys.length; i += 2) {
    const row = [];
    for (let j = i; j < Math.min(i + 2, capKeys.length); j++) {
      const k = capKeys[j];
      const on = caps.includes(k);
      row.push(Button.inline((on ? "✅ " : "⬜ ") + KEY_CAPS[k], Buffer.from("sb_kc2:" + k)));
    }
    rows.push(row);
  }
  rows.push([Button.inline("📝 Set Teks Respons", Buffer.from("sb_keytext")),
             Button.inline("📊 Preview", Buffer.from("sb_keyprev"))]);
  rows.push([Button.inline("💾 Simpan Perubahan", Buffer.from("sb_savekeyedit"))]);
  rows.push([Button.inline("« Kembali", Buffer.from("sb_editkey:" + projectId))]);
  await sbView(userId, peer, text, rows, event);
}

const TEMPLATE_VARS = {
  "{name}": "nama depan pengguna",
  "{fullname}": "nama lengkap pengguna",
  "{username}": "username pengguna (@)",
  "{id}": "ID pengguna",
  "{mention}": "mention/tag pengguna",
  "{group}": "nama grup",
  "{groupid}": "ID grup",
  "{count}": "jumlah member grup",
  "{date}": "tanggal hari ini (WIB)",
  "{time}": "jam sekarang (WIB)",
};

async function sandboxAIStart(userId, peer, projectId, event) {
  const project = sandbox.getProject(userId, projectId);
  if (!project) return;
  if (project.aiUsed) return sbView(userId, peer, `🤖 Build by AI sudah dipakai di project ini (cuma sekali).`, [[Button.inline("« Kembali", Buffer.from("sb_edit:" + projectId))]], event);
  const sandboxAI = require("./lib/sandboxAI");
  if (!sandboxAI.ready()) return sbView(userId, peer, `❌ Build by AI butuh <code>GROQ_API_KEY</code> di <code>gwajib.env</code>. Isi dulu ya.`, [[Button.inline("« Kembali", Buffer.from("sb_edit:" + projectId))]], event);
  sandboxState.set(userId, { step: "aibrief", projectId, peer, ai: { brief: "", qa: [] } });
  await sbPrompt(userId, peer,
    `🤖 <b>BUILD BY AI</b>\n⏣────────────────⏣\n\n` +
    `Deskripsikan ubot yang kamu mau — sedetail mungkin, AI yang rakit.\n\n` +
    `<i>Contoh:</i> <code>bot jualan pulsa: .start sambutan, .harga list harga, .order cara pesan, .admin kontak admin</code>\n\n` +
    `Kirim deskripsinya sekarang. (/cancel untuk batal)`,
    "sb_cancelnew", event);
}

async function showAIQuestion(userId, peer, event) {
  const st = sandboxState.get(userId);
  if (!st || !st.ai || !st.ai.questions || !st.ai.questions.length) return;
  const q = st.ai.questions[st.ai.qIndex];
  const total = st.ai.questions.length;
  const text =
    `🤖 <b>AI perlu tanya dulu</b> (${st.ai.qIndex + 1}/${total})\n⏣────────────────⏣\n\n` +
    `❓ <b>Q: ${esc(q.q)}</b>\n\n<i>Pilih jawaban:</i>`;
  const rows = q.options.map((o, i) => [Button.inline("A: " + o, Buffer.from("sb_aians:" + i))]);
  await sbView(userId, peer, text, rows, event);
}

async function sandboxAIRun(userId, peer, event) {
  const st = sandboxState.get(userId);
  if (!st || !st.ai) return;
  await sbView(userId, peer, `🤖 <i>AI lagi merancang ubot kamu… tunggu sebentar ⏳</i>`, []);
  const sandboxAI = require("./lib/sandboxAI");
  let res;
  try { res = await sandboxAI.plan(st.ai.brief, st.ai.qa); }
  catch (e) { return sbView(userId, peer, `❌ AI error: ${esc(e.message || String(e))}\nCoba lagi.`, [[Button.inline("« Kembali", Buffer.from("sb_edit:" + st.projectId))]], event); }
  if (res.build) return applyAIBuild(userId, peer, res.build, event);
  if (res.questions && res.questions.length) {
    st.ai.questions = res.questions; st.ai.qIndex = 0; st.step = "aiqa";
    return showAIQuestion(userId, peer, event);
  }
  return sbView(userId, peer, `❌ AI ga balikin hasil. Coba deskripsi lebih jelas.`, [[Button.inline("« Kembali", Buffer.from("sb_edit:" + st.projectId))]], event);
}

async function applyAIBuild(userId, peer, build, event) {
  const st = sandboxState.get(userId);
  const project = sandbox.getProject(userId, st.projectId);
  if (!project) return;
  project.prefix = build.prefix || project.prefix;
  project.keys = build.keys;
  project.aiUsed = true;
  sandbox.saveProject(userId, project);
  sandbox.setActive(userId, project.id);
  sandboxState.delete(userId);
  const list = build.keys.slice(0, 12).map((k) => `• <code>${esc(project.prefix + k.name)}</code> — ${esc((k.config && k.config.text || "").slice(0, 32))}`).join("\n");
  await sbView(userId, peer,
    `✅ <b>AI selesai bikin ubot kamu!</b>\n⏣────────────────⏣\n\n` +
    `<b>${build.keys.length} command</b> dibuat & project langsung di-<b>AKTIF</b>-kan:\n\n${list}${build.keys.length > 12 ? "\n…" : ""}\n\n` +
    `<i>Command-nya langsung jalan di ubot kamu. Mau ubah? Pakai menu Edit.</i>`,
    [[Button.inline("« Ke Edit Mode", Buffer.from("sb_edit:" + project.id))]], event);
}

async function handleSandboxStep(userId, text, peer) {
  const state = sandboxState.get(userId);
  if (!state) return false;

  if (text === "/cancel") {
    sandboxState.delete(userId);
    await sbView(userId, peer, `✕ Pembuatan dibatalkan.`, [[Button.inline("« Tutup", Buffer.from("sb_close"))]]);
    return true;
  }

  if (state.step === "aibrief") {
    state.ai.brief = text.trim().slice(0, 1500);
    if (!state.ai.brief) { await send(userId, `❌ Deskripsi kosong. Kirim lagi ya.`, peer); return true; }
    await sandboxAIRun(userId, peer);
    return true;
  }

  if (state.step === "name") {
    state.draft.name = text.trim().slice(0, 40);
    state.step = "prefix";
    await sbPrompt(userId, peer,
      `✅ Nama: <b>${esc(state.draft.name)}</b>\n\n` +
      `Langkah 2/3: Kirim <b>prefix</b> untuk ubot ini (contoh: <code>.</code> atau <code>!</code> atau <code>x</code>).`,
      "sb_cancelnew"
    );
    return true;
  }

  if (state.step === "prefix") {
    state.draft.prefix = text.trim().slice(0, 3);
    state.step = "features";
    await showFeatureToggles(userId, peer);
    return true;
  }

  if (state.step === "keyname") {
    const name = text.trim().toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20);
    if (!name) {
      await send(userId, `❌ Nama key tidak valid. Pakai huruf/angka saja (contoh: <code>spam</code>).`, peer);
      return true;
    }
    state.keyDraft.name = name;
    state.step = "keycaps";
    await showKeyCaps(userId, peer);
    return true;
  }

  if (state.step === "tabname") {
    const name = text.trim().toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20);
    if (!name) { await sbPrompt(userId, peer, `❌ Nama tab tidak valid (huruf/angka saja). Kirim ulang:`, "sb_canceltab"); return true; }
    state.tabDraft.name = name;
    state.step = "tabstyle";
    await showTabStyle(userId, peer);
    return true;
  }
  if (state.step === "tabtext") {
    state.tabDraft.text = text.slice(0, 1500);
    state.step = "tabstyle";
    await showTabStyle(userId, peer);
    return true;
  }
  if (state.step === "tabphoto") {
    if (text.trim().toLowerCase() === "hapus") state.tabDraft.photo = null;
    else state.tabDraft.photo = text.trim();
    state.step = "tabstyle";
    await showTabStyle(userId, peer);
    return true;
  }
  if (state.step === "btnname") {
    state.btnDraft.name = text.trim().slice(0, 30);
    const project = sandbox.getProject(userId, state.projectId);
    if (!project || !project.tabs.length) {
      sandboxState.delete(userId);
      await sbView(userId, peer, `❌ Tidak ada tab tujuan.`, [[Button.inline("« Tutup", Buffer.from("sb_close"))]]);
      return true;
    }
    const rows = project.tabs.map(t => [Button.inline("→ " + t.name, Buffer.from("sb_btntab:" + t.id))]);
    rows.push([Button.inline("✕ Batal", Buffer.from("sb_canceltab"))]);
    state.step = "btntab";
    await sbView(userId, peer, `🔘 Tombol "<b>${esc(state.btnDraft.name)}</b>" menuju ke tab mana?`, rows);
    return true;
  }
  if (state.step === "projphoto") {
    const project = sandbox.getProject(userId, state.projectId);
    if (project) {
      project.photo = text.trim();
      sandbox.saveProject(userId, project);
      await showEditMode(userId, peer, state.projectId);
    }
    return true;
  }

  if (state.step === "keytext") {
    if (state.keyDraft) {
      state.keyDraft.config = state.keyDraft.config || {};
      state.keyDraft.config.text = text.slice(0, 1500);
      state.step = "keyedit";
      await showKeyEditor(userId, peer, state.projectId, state.editKeyName);
    }
    return true;
  }

  return true;
}

async function showFeatureToggles(userId, peer, event) {
  const state = sandboxState.get(userId);
  const f = state.draft.features || {};
  const text =
    `⚙️ <b>Langkah 3/3: Pilih Fitur</b>\n\n` +
    `Centang fitur yang mau diaktifkan, lalu tekan <b>Konfirmasi</b>:\n\n` +
    `${f.noApi ? "✅" : "⬜"} <b>Connect tanpa API ID & Hash</b>\n` +
    `<i>(user cukup nomor + OTP saat connect)</i>`;
  const buttons = [
    [Button.inline((f.noApi ? "✅" : "⬜") + " Connect tanpa API", Buffer.from("sb_feat:noApi"))],
    [Button.inline("✓ Konfirmasi & Buat", Buffer.from("sb_confirm"))],
    [Button.inline("✕ Batal", Buffer.from("sb_cancelnew"))],
  ];
  await sbView(userId, peer, text, buttons, event);
}


const roleMenuState = new Map();
const pmReplyState = new Map();
const RM_EMOJI = { pemilik: "💎", ceo: "🌟", tk: "🔱", owner: "👑", admin: "🛡️", reseller: "💼", prem: "⭐", user: "👤" };

function rmFmtExp(expiresAt) {
  if (!expiresAt) return "Permanen";
  const ms = expiresAt - Date.now();
  if (ms <= 0) return "Expired";
  const days = Math.floor(ms / 86400000);
  const hrs = Math.floor((ms % 86400000) / 3600000);
  const d = new Date(expiresAt + 7 * 3600000);
  const p = (n) => String(n).padStart(2, "0");
  return `${days}h ${hrs}j lagi • ${p(d.getUTCDate())}/${p(d.getUTCMonth() + 1)}/${d.getUTCFullYear()}`;
}
function rmFmtShort(expiresAt) {
  if (!expiresAt) return "∞";
  const ms = expiresAt - Date.now();
  if (ms <= 0) return "exp";
  return Math.floor(ms / 86400000) + "h";
}
function rmGetManaged(actorId) {
  const role = db.getRole(actorId);
  if (db.ROLES[role] >= db.ROLES.ceo) return db.getAllManaged();
  if (db.ROLES[role] >= db.ROLES.reseller) return db.getUsersAddedBy(actorId);
  return [];
}
function rmCanManage(actorId, targetId) {
  const t = db.getUser(targetId);
  if (!t) return false;
  if (db.OWNER_IDS.includes(targetId.toString()) || t.role === "pemilik") return false;
  const aRole = db.getRole(actorId);
  if (db.ROLES[aRole] <= db.ROLES[t.role]) return false;
  if (db.ROLES[aRole] >= db.ROLES.ceo) return true;
  return t.addedBy === actorId.toString();
}

async function showRoleMenu(userId, event, page) {
  const role = db.getRole(userId);
  if (db.ROLES[role] < db.ROLES.reseller) {
    await event.answer({ message: "Menu ini cuma buat Reseller ke atas.", alert: true });
    return;
  }
  const users = rmGetManaged(userId);
  const PER = 8;
  const totalPages = Math.max(1, Math.ceil(users.length / PER));
  page = Math.max(0, Math.min(page || 0, totalPages - 1));
  const slice = users.slice(page * PER, page * PER + PER);

  const lbl = `${ROLE_LABEL[role] || "📋"} Menu`;
  let text = `<b>${lbl} — Kelola User</b>\n`;
  text += `📊 Total dikelola: <b>${users.length}</b> user  |  Halaman ${page + 1}/${totalPages}\n\n`;
  text += slice.length ? `Tap user untuk extend / stop:` : `<i>Belum ada user yang kamu tambahkan.</i>`;

  const buttons = [];
  for (const u of slice) {
    const nm = await getUserName(u.id);
    const em = RM_EMOJI[u.role] || "👤";
    buttons.push([Button.inline(`${em} ${nm} • ${u.role} • ${rmFmtShort(u.expiresAt)}`, Buffer.from(`ru_${u.id}`))]);
  }
  const nav = [];
  if (page > 0) nav.push(Button.inline("« Prev", Buffer.from(`rolemenu_p${page - 1}`)));
  if (page < totalPages - 1) nav.push(Button.inline("Next »", Buffer.from(`rolemenu_p${page + 1}`)));
  if (nav.length) buttons.push(nav);
  buttons.push([Button.inline("« Menu Utama", Buffer.from("tab_main")), Button.inline("✕ Tutup", Buffer.from("rolemenu_close"))]);

  await editView(event, text, buttons, false);
}

async function showUserDetail(actorId, targetId, event) {
  if (!rmCanManage(actorId, targetId)) {
    await event.answer({ message: "Kamu ga punya akses ke user ini.", alert: true });
    return;
  }
  const u = db.getUser(targetId);
  const nm = await getUserName(targetId);
  const em = RM_EMOJI[u.role] || "👤";
  const added = new Date(u.addedAt + 7 * 3600000);
  const p = (n) => String(n).padStart(2, "0");
  let text = `${em} <b>${esc(nm)}</b>\n`;
  text += `━━━━━━━━━━━━━━━\n`;
  text += `🆔 ID : <code>${u.id}</code>\n`;
  text += `🎭 Role : <b>${u.role}</b>\n`;
  text += `⏳ Expired : <b>${rmFmtExp(u.expiresAt)}</b>\n`;
  text += `📅 Ditambah : ${p(added.getUTCDate())}/${p(added.getUTCMonth() + 1)}/${added.getUTCFullYear()}\n`;
  text += `━━━━━━━━━━━━━━━\nPilih tindakan:`;
  const buttons = [
    [Button.inline("⏳ Extend (+ hari)", Buffer.from(`ruext_${targetId}`))],
    [Button.inline("🛑 Stop (jadikan User)", Buffer.from(`rustop_${targetId}`))],
    [Button.inline("« Daftar", Buffer.from("rolemenu")), Button.inline("✕ Tutup", Buffer.from("rolemenu_close"))],
  ];
  await editView(event, text, buttons, false);
}

async function startExtend(actorId, targetId, event) {
  if (!rmCanManage(actorId, targetId)) {
    await event.answer({ message: "Akses ditolak.", alert: true });
    return;
  }
  roleMenuState.set(actorId, { targetId: targetId.toString() });
  const nm = await getUserName(targetId);
  const text = `⏳ <b>Extend: ${esc(nm)}</b>\n\nKetik jumlah <b>hari</b> yang mau ditambahin (angka saja).\nContoh: <code>30</code>\n\nTekan ✕ untuk batal.`;
  const buttons = [[Button.inline("✕ Batal", Buffer.from(`ru_${targetId}`))]];
  await editView(event, text, buttons, false);
}

async function execExtend(actorId, targetId, days, event) {
  if (!rmCanManage(actorId, targetId)) {
    await event.answer({ message: "Akses ditolak.", alert: true });
    return;
  }
  const newExp = db.extendUser(targetId, days);
  await event.answer({ message: `✅ +${days} hari!` });
  const nm = await getUserName(targetId);
  const text = `✅ <b>Berhasil Extend!</b>\n\n<b>${esc(nm)}</b> +${days} hari.\n⏳ Expired baru: <b>${rmFmtExp(newExp)}</b>`;
  const buttons = [[Button.inline("« Daftar", Buffer.from("rolemenu")), Button.inline("✕ Tutup", Buffer.from("rolemenu_close"))]];
  await editView(event, text, buttons, false);
  try { await send(targetId, `🎉 Masa aktif kamu diperpanjang <b>+${days} hari</b>!\n⏳ Expired: ${rmFmtExp(newExp)}`); } catch {}
}

async function confirmStop(actorId, targetId, event) {
  if (!rmCanManage(actorId, targetId)) {
    await event.answer({ message: "Akses ditolak.", alert: true });
    return;
  }
  const nm = await getUserName(targetId);
  const text = `🛑 <b>Konfirmasi STOP</b>\n\nYakin stop <b>${esc(nm)}</b>?\n🆔 <code>${targetId}</code>\n\n⚠️ Dia bakal jadi <b>User</b> biasa & ubot-nya dimatikan.`;
  const buttons = [[
    Button.inline("🛑 YA, STOP", Buffer.from(`rustopok_${targetId}`)),
    Button.inline("✕ Batal", Buffer.from(`ru_${targetId}`)),
  ]];
  await editView(event, text, buttons, false);
}

async function execStop(actorId, targetId, event) {
  if (!rmCanManage(actorId, targetId)) {
    await event.answer({ message: "Akses ditolak.", alert: true });
    return;
  }
  const nm = await getUserName(targetId);
  try { await ubotMgr.stopUbot(targetId.toString()); } catch {}
  db.removeUser(targetId);
  await event.answer({ message: "🛑 User di-stop." });
  const text = `✅ <b>User di-stop.</b>\n\n<b>${esc(nm)}</b> sekarang jadi <b>User</b> biasa & ubot-nya dimatikan.`;
  const buttons = [[Button.inline("« Daftar", Buffer.from("rolemenu")), Button.inline("✕ Tutup", Buffer.from("rolemenu_close"))]];
  await editView(event, text, buttons, false);
  try { await send(targetId, `ℹ️ Akses ubot kamu dihentikan oleh pengelola. Hubungi owner untuk info lebih lanjut.`); } catch {}
}

async function notifyPemilik(fromId, text, fromPeer) {
  try {
    const name = await getUserName(fromId);
    const role = db.getRole(fromId);
    const jam = new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" });
    const preview = text.length > 200 ? text.slice(0, 200) + "…" : text;
    const card =
      `<blockquote><b>📩 ᴘᴇsᴀɴ ᴍᴀsᴜᴋ</b>\n` +
      `👤 <b>${esc(name)}</b>\n` +
      `🆔 <code>${fromId}</code>  •  ${ROLE_LABEL[role] || role}\n` +
      `🕐 ${jam} WIB\n\n` +
      `💬 ${esc(preview)}</b></blockquote>`;
    const buttons = [[
      Button.inline("👤 Dapatkan Profil", Buffer.from(`prof_${fromId}`)),
      Button.inline("💬 Jawab Pesan", Buffer.from(`ans_${fromId}`)),
    ]];
    for (const ownerId of db.OWNER_IDS) {
      if (ownerId === fromId.toString()) continue;
      try {
        const ie = await bot.getInputEntity(parseInt(ownerId));
        await bot.sendMessage(ie, { message: card, parseMode: "html", buttons });
      } catch {  }
    }
  } catch (e) { console.error("notifyPemilik:", e.message); }
}

async function buildProfile(id) {
  let name = await getUserName(id), uname = "—";
  try {
    const ent = await bot.getEntity(parseInt(id));
    const full = [ent.firstName, ent.lastName].filter(Boolean).join(" ");
    if (full) name = full;
    if (ent.username) uname = "@" + ent.username;
  } catch {}
  const role = db.getRole(id);
  const u = db.getUser(id);
  const ubot = ubotMgr.getUbotStatus(id) ? "🟢 Aktif" : "⚪ Tidak aktif";
  let exp = "—";
  if (role === "pemilik") exp = "Permanen";
  else if (u && u.expiresAt) exp = new Date(u.expiresAt).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta" });
  return (
    `<blockquote><b>👤 ᴘʀᴏꜰɪʟ ᴜsᴇʀ</b>\n` +
    `Nama: <b>${esc(name)}</b>\n` +
    `Username: ${esc(uname)}\n` +
    `ID: <code>${id}</code>\n` +
    `Role: <b>${ROLE_LABEL[role] || role}</b>\n` +
    `Ubot: ${ubot}\n` +
    `Expired: ${esc(exp)}</b></blockquote>`
  );
}

bot.addEventHandler(async (event) => {
  if (!__licensed()) return;
  try {
    const userId = event.senderId?.toString();
    const data = event.data?.toString();
    if (!userId || !data) return;

    if (event.query && event.query.className === "UpdateInlineBotCallbackQuery") return;

    const isPrivateCb = event.chatId?.toString() === userId;

    if (data.startsWith("prof_") || data.startsWith("ans_")) {
      if (!db.OWNER_IDS.includes(userId)) {
        try { await event.answer({ message: "Khusus Pemilik.", alert: true }); } catch {}
        return;
      }
      const targetId = data.slice(data.indexOf("_") + 1);
      if (data.startsWith("prof_")) {
        try { await event.answer({ message: "Mengambil profil…" }); } catch {}
        const info = await buildProfile(targetId);
        try {
          const ie = await bot.getInputEntity(parseInt(userId));
          await bot.sendMessage(ie, {
            message: info, parseMode: "html",
            buttons: [[Button.inline("💬 Jawab Pesan", Buffer.from(`ans_${targetId}`))]],
          });
        } catch {}
        return;
      }
      const nm = await getUserName(targetId);
      pmReplyState.set(userId, { targetId: targetId.toString(), targetName: nm });
      try { await event.answer({ message: "Ketik balasanmu sekarang." }); } catch {}
      try {
        const ie = await bot.getInputEntity(parseInt(userId));
        await bot.sendMessage(ie, {
          message: `✍️ <b>Mode Jawab</b> ke <b>${esc(nm)}</b> (<code>${targetId}</code>)\n\nKetik pesan balasan kamu sekarang — bakal langsung dikirim ke user itu lewat bot.\nKetik <code>/cancel</code> buat batal.`,
          parseMode: "html",
        });
      } catch {}
      return;
    }

    if ((data === "tab_connect" || data === "tab_sandbox") && !isPrivateCb) {
      const botUser = (process.env.BOT_USERNAME || "").replace("@", "");
      await event.answer({
        message: `Fitur ini cuma bisa di chat PRIVATE (DM). Chat bot${botUser ? " @" + botUser : ""} langsung ya 🙏`,
        alert: true,
      });
      return;
    }

    if (data === "tab_sandbox") {
      await event.answer();
      const peer = event.peer || (await event.getInputChat());
      sandboxPanel.delete(userId);
      await handleSandbox(userId, peer, event);
      return;
    }
    if (data === "buyupgrade") {
      const cur = db.getRole(userId);
      const to = harga.nextRole(cur);
      const up = harga.getUpgradePrice(cur);
      if (!to || !up) { try { await event.answer({ message: "Role kamu nggak bisa diupgrade / harga upgrade belum diset.", alert: true }); } catch {} return; }
      if (customStore.get().qrisSet) { try { await event.answer(); } catch {} const v = daysPickerView("upg", to, userId, 30); return editView(event, v.text, v.buttons, true); }
      if (!pakasirReady()) { try { await event.answer({ message: "Metode pembayaran manual aktif. Hubungi owner buat upgrade.", alert: true }); } catch {} return; }
      try { await event.answer({ message: "Membuat QRIS\u2026" }); } catch {}
      const orderId = "UP" + Date.now() + String(userId).slice(-4);
      try {
        const pay = await pakasir.createQris({ amount: up.amount, orderId });
        pendingOrders.set(orderId, { userId, role: to, amount: up.amount, kind: "upgrade", from: cur });
        const os = require("os"), fs = require("fs"), path = require("path");
        const tmp = path.join(os.tmpdir(), orderId + ".png");
        await QRCode.toFile(tmp, pay.qrString, { width: 512, margin: 2 });
        const ie = await bot.getInputEntity(parseInt(userId));
        await bot.sendFile(ie, {
          file: tmp,
          caption: quote(
            `\u2b06\ufe0f <b>UPGRADE ROLE</b>\n\n` +
            `Dari: <b>${harga.ROLE_LABEL[cur] || cur}</b>\n` +
            `Ke: <b>${harga.ROLE_LABEL[to] || to}</b>\n` +
            `Total: <b>${harga.fmtRupiah(pay.total || up.amount)}</b>\n` +
            `Order ID: <code>${orderId}</code>\n\n` +
            `Scan QR di atas pakai e-wallet / m-banking (QRIS).\n` +
            `Setelah bayar, tekan <b>\u2705 Cek Pembayaran</b>.`
          ),
          parseMode: "html",
          buttons: [
            [Button.inline("\u2705 Cek Pembayaran", Buffer.from("buychk_" + orderId))],
            [Button.inline("\u00ab Kembali", Buffer.from("tab_upgrade"))],
          ],
        });
        try { fs.unlinkSync(tmp); } catch {}
      } catch (e) {
        try { const ie = await bot.getInputEntity(parseInt(userId)); await bot.sendMessage(ie, { message: quote(`\u274c Gagal membuat QRIS: ${esc(e.message)}`), parseMode: "html" }); } catch {}
      }
      return;
    }
    if (data.startsWith("buyrole_")) {
      const r = data.slice(8);
      const price = harga.getRolePrice(r) || ({ prem: 1000, reseller: 3000, admin: 5000, owner: 8000, tk: 11000, ceo: 13000 })[r];
      if (!price) { try { await event.answer({ message: "Harga role ini belum diset di harga.env.", alert: true }); } catch {} return; }
      if (customStore.get().qrisSet) { try { await event.answer(); } catch {} const v = daysPickerView("beli", r, userId, 30); return editView(event, v.text, v.buttons, true); }
      if (!pakasirReady()) { try { await event.answer({ message: "Metode pembayaran manual aktif.", alert: true }); } catch {} return; }
      try { await event.answer({ message: "Membuat QRIS\u2026" }); } catch {}
      const orderId = "UB" + Date.now() + String(userId).slice(-4);
      try {
        const pay = await pakasir.createQris({ amount: price, orderId });
        pendingOrders.set(orderId, { userId, role: r, amount: price });
        const os = require("os"), fs = require("fs"), path = require("path");
        const tmp = path.join(os.tmpdir(), orderId + ".png");
        await QRCode.toFile(tmp, pay.qrString, { width: 512, margin: 2 });
        const ie = await bot.getInputEntity(parseInt(userId));
        await bot.sendFile(ie, {
          file: tmp,
          caption: quote(
            `\ud83d\udcb3 <b>QRIS PEMBAYARAN</b>\n\n` +
            `Role: <b>${harga.ROLE_LABEL[r] || r}</b>\n` +
            `Total: <b>${harga.fmtRupiah(pay.total || price)}</b>\n` +
            `Order ID: <code>${orderId}</code>\n\n` +
            `Scan QR di atas pakai e-wallet / m-banking (QRIS).\n` +
            `Setelah bayar, tekan <b>\u2705 Cek Pembayaran</b>.`
          ),
          parseMode: "html",
          buttons: [
            [Button.inline("\u2705 Cek Pembayaran", Buffer.from("buychk_" + orderId))],
            [Button.inline("\u00ab Kembali", Buffer.from("tab_beli"))],
          ],
        });
        try { fs.unlinkSync(tmp); } catch {}
      } catch (e) {
        try { const ie = await bot.getInputEntity(parseInt(userId)); await bot.sendMessage(ie, { message: quote(`\u274c Gagal membuat QRIS: ${esc(e.message)}`), parseMode: "html" }); } catch {}
      }
      return;
    }
    if (data.startsWith("buychk_")) {
      const orderId = data.slice(7);
      const ord = pendingOrders.get(orderId);
      if (!ord) { try { await event.answer({ message: "Order tidak ditemukan / kadaluarsa. Ulangi beli.", alert: true }); } catch {} return; }
      try { await event.answer({ message: "Mengecek pembayaran\u2026" }); } catch {}
      try {
        const st = await pakasir.checkStatus({ orderId, amount: ord.amount });
        const ie = await bot.getInputEntity(parseInt(userId));
        if (String(st.status).toLowerCase() === "completed") {
          db.addUser(ord.userId, ord.role, "pakasir", 30);
          pendingOrders.delete(orderId);
          await autoShareTrx({ buyerId: ord.userId, role: ord.role, amount: ord.amount, kind: ord.kind });
          await bot.sendMessage(ie, { message: quote(
            `\u2705 <b>PEMBAYARAN BERHASIL!</b>\n\n` +
            `${ord.kind === "upgrade" ? "Upgrade ke" : "Role"} <b>${harga.ROLE_LABEL[ord.role] || ord.role}</b> aktif 30 hari.\n` +
            `Ketik /connect untuk mulai pakai userbot.`
          ), parseMode: "html" });
        } else {
          await bot.sendMessage(ie, { message: quote(
            `\u23f3 <b>Belum terbayar</b> (status: ${esc(st.status)}).\n` +
            `Kalau sudah bayar, tunggu sebentar lalu tekan Cek lagi.`
          ), parseMode: "html" });
        }
      } catch (e) {
        try { const ie = await bot.getInputEntity(parseInt(userId)); await bot.sendMessage(ie, { message: quote(`\u274c Gagal cek pembayaran: ${esc(e.message)}`), parseMode: "html" }); } catch {}
      }
      return;
    }
    if (data.startsWith("settheme_")) {
      const id = data.slice(9);
      themeStore.setTheme(userId, id);
      try { await event.answer({ message: `Tema "${themes.get(id).name}" dipasang! ✅` }); } catch {}
      await showTab("theme", userId, event);
      return;
    }
    if (data.startsWith("addon_")) {
      const a = addonStore.getAddon(userId);
      const grup = (process.env.GRUP_UBOT || "").trim();
      let msg = "";
      if (data === "addon_pf") {
        const next = !a.hidePerfolder;
        addonStore.setAddon(userId, { hidePerfolder: next });
        msg = next ? "Tombol Open Perfolder disembunyikan 🗑" : "Tombol Open Perfolder ditampilkan ✅";
      } else if (data === "addon_jg") {
        const next = !a.hideJoinGrup;
        addonStore.setAddon(userId, { hideJoinGrup: next });
        msg = next ? "Tombol Join Grup disembunyikan 🗑" : "Tombol Join Grup ditampilkan ✅";
      } else if (data === "addon_clean") {
        const allHidden = a.hidePerfolder && (!grup || a.hideJoinGrup);
        const target = !allHidden;
        addonStore.setAddon(userId, { hidePerfolder: target, hideJoinGrup: target });
        msg = target ? "Tombol tidak diperlukan dihapus 🗑" : "Semua tombol ditampilkan ✅";
      } else if (data === "addon_ac") {
        const next = !a.autocorrect;
        addonStore.setAddon(userId, { autocorrect: next });
        msg = next ? "Autocorrect dinyalakan ✅" : "Autocorrect dimatikan ❌";
      } else if (data === "addon_ep") {
        const next = !a.emojiPrem;
        addonStore.setAddon(userId, { emojiPrem: next });
        msg = next ? "Emoji Premium dinyalakan ✨" : "Emoji Premium dimatikan ❌";
      }
      try { await event.answer({ message: msg }); } catch {}
      await showTab("addon", userId, event);
      return;
    }

    if (data.startsWith("bc_")) {
      const mode = data.slice(3);
      if (btnColorStore.VALID.includes(mode)) {
        btnColorStore.setStyle(userId, mode);
        try { await event.answer({ message: "Warna tombol: " + mode }); } catch {}
      }
      await showTab("btncolor", userId, event);
      return;
    }

    if (data.startsWith("cust_layout:")) {
      const parts = data.slice("cust_layout:".length).split(":");
      const c = Math.max(1, Math.min(4, parseInt(parts[0]) || 2));
      const b = Math.max(1, Math.min(4, parseInt(parts[1]) || 4));
      addonStore.setAddon(userId, { btnCols: c, btnRows: b });
      try { await event.answer({ message: `Layout ${c}:${b} dipasang ✅` }); } catch {}
      await showTab("custom", userId, event);
      return;
    }

    if (data.startsWith("upgto_")) {
      const to = data.slice(6);
      const { total } = computeOrderPrice("upg", to, userId, 30);
      if (!total) { try { await event.answer({ message: "Role ini nggak bisa diupgrade / harga belum diset.", alert: true }); } catch {} return; }
      if (customStore.get().qrisSet) {
        try { await event.answer(); } catch {}
        const v = daysPickerView("upg", to, userId, 30);
        return editView(event, v.text, v.buttons, true);
      }
      if (!pakasirReady()) { try { await event.answer({ message: "Metode pembayaran manual aktif. Hubungi owner buat upgrade.", alert: true }); } catch {} return; }
      try { await event.answer({ message: "Membuat QRIS…" }); } catch {}
      const orderId = "UP" + Date.now() + String(userId).slice(-4);
      try {
        const pay = await pakasir.createQris({ amount: total, orderId });
        pendingOrders.set(orderId, { userId, role: to, amount: total, kind: "upgrade", from: db.getRole(userId) });
        const os = require("os"), fs = require("fs"), path = require("path");
        const tmp = path.join(os.tmpdir(), orderId + ".png");
        await QRCode.toFile(tmp, pay.qrString, { width: 512, margin: 2 });
        const ie = await bot.getInputEntity(parseInt(userId));
        await bot.sendFile(ie, {
          file: tmp,
          caption: quote(
            `⬆️ <b>UPGRADE ROLE</b>\n\n` +
            `Ke: <b>${harga.ROLE_LABEL[to] || to}</b>\n` +
            `Total: <b>${harga.fmtRupiah(pay.total || total)}</b>\n` +
            `Order ID: <code>${orderId}</code>\n\n` +
            `Scan QR di atas pakai e-wallet / m-banking (QRIS).\nSetelah bayar, tekan <b>✅ Cek Pembayaran</b>.`
          ),
          parseMode: "html",
          buttons: [
            [Button.inline("✅ Cek Pembayaran", Buffer.from("buychk_" + orderId))],
            [Button.inline("« Kembali", Buffer.from("tab_upgrade"))],
          ],
        });
        try { fs.unlinkSync(tmp); } catch {}
      } catch (e) {
        try { const ie = await bot.getInputEntity(parseInt(userId)); await bot.sendMessage(ie, { message: quote(`❌ Gagal membuat QRIS: ${esc(e.message)}`), parseMode: "html" }); } catch {}
      }
      return;
    }

    if (data === "claim_trial") {
      const res = giveawayStore.claimTrial(userId);
      if (!res.ok) {
        if (res.already) { try { await event.answer({ message: "Kamu udah pernah klaim trial.", alert: true }); } catch {} }
        else { try { await event.answer({ message: "Trial lagi nggak aktif.", alert: true }); } catch {} }
        return;
      }
      db.addUser(userId, "prem", "trial", res.days);
      try { await event.answer({ message: `🎉 Trial Premium ${res.days} hari aktif!`, alert: true }); } catch {}
      await showMainEdit(event, userId);
      return;
    }

    if (data === "ga_redeem") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      gaWizard.set(userId, {});
      try { await event.answer(); } catch {}
      const v = gaRolePickView();
      return editView(event, v.text, v.buttons, true);
    }
    if (data.startsWith("garw:")) {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const rest = data.slice(5);
      const wiz = gaWizard.get(userId) || {};
      if (rest.startsWith("role:")) {
        wiz.role = rest.slice(5); gaWizard.set(userId, wiz);
        try { await event.answer(); } catch {}
        const v = gaExpTypeView(wiz); return editView(event, v.text, v.buttons, true);
      }
      if (rest === "exptype_back") {
        try { await event.answer(); } catch {}
        const v = gaExpTypeView(wiz); return editView(event, v.text, v.buttons, true);
      }
      if (rest.startsWith("exptype:")) {
        const t = rest.slice(8);
        wiz.expType = t;
        try { await event.answer(); } catch {}
        if (t === "time") { wiz.expVal = 60; gaWizard.set(userId, wiz); const v = gaExpValView(wiz); return editView(event, v.text, v.buttons, true); }
        if (t === "count") { wiz.expVal = 5; gaWizard.set(userId, wiz); const v = gaExpValView(wiz); return editView(event, v.text, v.buttons, true); }
        wiz.expVal = 0; gaWizard.set(userId, wiz);
        const v = gaNoneConfirmView(wiz); return editView(event, v.text, v.buttons, true);
      }
      if (rest.startsWith("expset:")) {
        wiz.expVal = Math.max(1, parseInt(rest.slice(7)) || 1); gaWizard.set(userId, wiz);
        try { await event.answer(); } catch {}
        const v = gaExpValView(wiz); return editView(event, v.text, v.buttons, true);
      }
      if (rest === "expdone" || rest === "nonecfm") {
        try { await event.answer(); } catch {}
        const v = gaCodeMethodView(wiz); return editView(event, v.text, v.buttons, true);
      }
      if (rest === "code:random") {
        if (!wiz.role) { try { await event.answer({ message: "Sesi habis, ulangi dari menu Giveaway.", alert: true }); } catch {} return; }
        let code; do { code = giveawayStore.randomCode(5); } while (giveawayStore.hasCode(code));
        const saved = { ...wiz };
        giveawayStore.createCode(code, wiz.role, wiz.expType, wiz.expVal);
        gaWizard.delete(userId);
        try { await event.answer({ message: "Kode dibuat!" }); } catch {}
        const r = gaCodeResult(saved, code);
        return editView(event, r.text, r.rows, true);
      }
      if (rest === "code:set") {
        if (!wiz.role) { try { await event.answer({ message: "Sesi habis, ulangi dari menu Giveaway.", alert: true }); } catch {} return; }
        custInputState.set(userId, { action: "gacode", wiz: { ...wiz } });
        try { await event.answer(); } catch {}
        await send(userId, `✍️ <b>SET KODE SENDIRI</b>\n\nKetik kode redeem yang kamu mau (huruf/angka, 2–20 karakter, tanpa spasi). Contoh: <code>MERDEKA77</code>\n\nKetik <code>/cancel</code> buat batal.`);
        return;
      }
      try { await event.answer(); } catch {}
      return;
    }

    if (data === "ga_trial") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      if (!giveawayStore.getTrial().enabled) gaWizard.set(userId, { mode: "trial", tdays: 7 });
      try { await event.answer(); } catch {}
      const v = gaTrialView(userId); return editView(event, v.text, v.buttons, true);
    }
    if (data.startsWith("gatw:")) {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const rest = data.slice(5);
      const wiz = gaWizard.get(userId) || { mode: "trial", tdays: 7 };
      if (rest.startsWith("set:")) {
        wiz.tdays = Math.max(1, parseInt(rest.slice(4)) || 1); gaWizard.set(userId, wiz);
        try { await event.answer(); } catch {}
        const v = gaTrialView(userId); return editView(event, v.text, v.buttons, true);
      }
      if (rest === "done") {
        giveawayStore.setTrial(wiz.tdays || 7); gaWizard.delete(userId);
        try { await event.answer({ message: `Trial ${wiz.tdays || 7} hari aktif!` }); } catch {}
        const v = gaTrialView(userId); return editView(event, v.text, v.buttons, true);
      }
      try { await event.answer(); } catch {}
      return;
    }
    if (data === "ga_trial_del") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      giveawayStore.clearTrial();
      try { await event.answer({ message: "Trial dihapus." }); } catch {}
      const v = gaTrialView(userId); return editView(event, v.text, v.buttons, true);
    }

    if (data === "ga_spin") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      try { await event.answer(); } catch {}
      const v = gaSpinView(); return editView(event, v.text, v.buttons, true);
    }
    if (data === "ga_spin_go") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const pool = Array.from(new Set([...giveawayStore.getSeen(), ...Object.keys(db.loadDB().users || {})])).filter((id) => !db.OWNER_IDS.includes(String(id)));
      if (!pool.length) { try { await event.answer({ message: "Belum ada peserta (user yang start bot).", alert: true }); } catch {} return; }
      const winnerId = pool[Math.floor(Math.random() * pool.length)];
      const rrole = GA_ROLES[Math.floor(Math.random() * GA_ROLES.length)];
      try { db.addUser(winnerId, rrole, "giveaway-spin", 5); } catch {}
      try { await send(winnerId, `🎉 <b>Selamat!</b> Kamu kespin di giveaway dan mendapatkan role <b>${harga.ROLE_LABEL[rrole] || rrole}</b> selama 5 hari! Ketik /start.`); } catch {}
      let wname = String(winnerId);
      try { const wu = await bot.getEntity(parseInt(winnerId)); wname = wu.username ? "@" + wu.username : ([wu.firstName, wu.lastName].filter(Boolean).join(" ") || String(winnerId)); } catch {}
      try { await event.answer({ message: "🎰 Spin selesai!" }); } catch {}
      const v = gaSpinView(`🎉 Pemenang: <b>${esc(wname)}</b>\n🎭 Role: <b>${harga.ROLE_LABEL[rrole] || rrole}</b> (5 hari)\n\nSpin lagi?`);
      return editView(event, v.text, v.buttons, true);
    }

    if (data === "jf_cek") {
      const ok = await isMemberOfAll(userId);
      if (ok) {
        try { await event.answer({ message: "✅ Verifikasi berhasil!" }); } catch {}
        await showMainEdit(event, userId);
      } else {
        try { await event.answer({ message: "❌ Kamu belum join SEMUA channel/grup. Join dulu ya!", alert: true }); } catch {}
      }
      return;
    }
    if (data === "cust_jf_toggle") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const cur = customStore.get().joinFirst.enabled;
      customStore.setJoinFirst({ enabled: !cur });
      try { await event.answer({ message: !cur ? "Join First aktif 🔒" : "Join First mati" }); } catch {}
      await showTab("custom", userId, event);
      return;
    }
    if (data.startsWith("cust_jf_del:")) {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const idx = parseInt(data.slice("cust_jf_del:".length));
      const chats = customStore.get().joinFirst.chats.slice();
      if (idx >= 0 && idx < chats.length) {
        const removed = chats.splice(idx, 1);
        customStore.setJoinFirst({ chats });
        try { await event.answer({ message: "Dihapus: " + (removed[0]?.title || "chat") }); } catch {}
      } else { try { await event.answer(); } catch {} }
      await showTab("custom", userId, event);
      return;
    }
    if (data === "cust_jf_set") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      if (customStore.get().joinFirst.chats.length >= 3) { try { await event.answer({ message: "Udah 3 channel/grup (maksimal). Hapus salah satu dulu.", alert: true }); } catch {} return; }
      custInputState.set(userId, { action: "jfchats" });
      try { await event.answer(); } catch {}
      await send(userId, `➕ <b>TAMBAH CHANNEL/GRUP WAJIB JOIN</b>\n\nKirim link/username channel atau grup (bot HARUS udah masuk di situ). Bisa 1 atau beberapa sekaligus (satu per baris), maksimal <b>3</b> total. Contoh:\n<code>@channelku</code>\n<code>https://t.me/grupku</code>\n\nKetik <code>/cancel</code> buat batal.`);
      return;
    }
    if (data === "cust_qris_set") {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      custInputState.set(userId, { action: "qris" });
      try { await event.answer(); } catch {}
      await send(userId, `💳 <b>SET QRIS</b>\n\nKirim <b>foto QRIS</b> kamu sekarang. QRIS ini yang muncul pas user mau upgrade/beli role.\n\nKetik <code>/cancel</code> buat batal.`);
      return;
    }
    if (data === "noop") { try { await event.answer(); } catch {} return; }
    if (data.startsWith("qd:")) {
      const p = data.slice(3).split(":");
      const kind = p[0], role = p[1], days = Math.max(30, Math.min(3650, parseInt(p[2]) || 30));
      try { await event.answer(); } catch {}
      const v = daysPickerView(kind, role, userId, days);
      return editView(event, v.text, v.buttons, true);
    }
    if (data.startsWith("qdok:")) {
      const p = data.slice(5).split(":");
      const kind = p[0], role = p[1], days = Math.max(30, Math.min(3650, parseInt(p[2]) || 30));
      const { total } = computeOrderPrice(kind, role, userId, days);
      if (!total) { try { await event.answer({ message: "Harga role ini belum diset di harga.env.", alert: true }); } catch {} return; }
      try { await event.answer(); } catch {}
      return showManualQris(userId, role, total, kind === "upg" ? "upgrade" : "beli", days);
    }
    if (data.startsWith("qapprove:")) {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const p = data.slice("qapprove:".length).split(":");
      const buyerId = p[0], role = p[1], days = parseInt(p[2]) || 30;
      const ownerTag = (OWNER_USERNAMES || "").split(",")[0].trim() || "Owner";
      try {
        db.addUser(buyerId, role, "qris", days);
        try { await event.answer({ message: "✅ Dikonfirmasi & role diberikan." }); } catch {}
        try { await autoShareTrx({ buyerId, role, amount: 0, kind: "manual" }); } catch {}
        await send(buyerId, `🎉 Owner ${ownerTag} <b>mengonfirmasi</b> pesanan role <b>${harga.ROLE_LABEL[role] || role}</b> ubot mu (${days} hari). Silahkan menggunakannya! Ketik /start.`);
      } catch (e) { try { await event.answer({ message: "Gagal: " + e.message, alert: true }); } catch {} }
      return;
    }
    if (data.startsWith("qreject:")) {
      if (!db.OWNER_IDS.includes(userId)) { try { await event.answer({ message: "Khusus pemilik." }); } catch {} return; }
      const rp = data.slice("qreject:".length).split(":");
      const buyerId = rp[0], rrole = rp[1] || "";
      rejectReasonState.set(userId, { buyerId, role: rrole });
      try { await event.answer(); } catch {}
      await send(userId, `📝 <b>ALASAN PEMBATALAN</b>\n\nKetik alasan kenapa pesanan user <code>${buyerId}</code> dibatalkan. Alasan ini dikirim ke user.\n\nKetik <code>/cancel</code> buat batal.`);
      return;
    }
    if (data.startsWith("payproof:")) {
      const p = data.slice("payproof:".length).split(":");
      const role = p[0], amount = parseInt(p[1]) || 0, days = Math.max(30, parseInt(p[2]) || 30);
      payProofState.set(userId, { role, amount, days });
      try { await event.answer(); } catch {}
      await send(userId, `📸 <b>KIRIM BUKTI</b>\n\nKirim <b>foto bukti transfer</b> kamu sekarang (screenshot pembayaran). Owner akan verifikasi & aktifkan role kamu.\n\nKetik <code>/cancel</code> buat batal.`);
      return;
    }

    if (data.startsWith("priv_")) {
      const key = data.slice(5);
      const valid = ["onlyMe", "hapusCmd", "antiPM", "logPM", "blokirAsing"];
      if (valid.includes(key)) {
        const cur = privacyStore.get(userId);
        const next = !cur[key];
        privacyStore.set(userId, { [key]: next });
        try { await event.answer({ message: `${key} ${next ? "aktif ✅" : "nonaktif ❌"}` }); } catch {}
      } else {
        try { await event.answer(); } catch {}
      }
      await showTab("privacy", userId, event);
      return;
    }

    if (data === "tab_main" || data.startsWith("tab_")) {
      await event.answer();
      if (data === "tab_main") {
        await showMainEdit(event, userId);
      } else {
        await showTab(data.slice(4), userId, event);
      }
      return;
    }

    if (data === "rolemenu" || data.startsWith("rolemenu_") || data === "rolemenu_close" ||
        data.startsWith("ru_") || data.startsWith("ruext_") || data.startsWith("ruextok_") ||
        data.startsWith("rustop_") || data.startsWith("rustopok_")) {
      if (!isPrivateCb) {
        const botUser = (process.env.BOT_USERNAME || "").replace("@", "");
        await event.answer({ message: `Kelola user cuma bisa di chat PRIVATE. Chat bot${botUser ? " @" + botUser : ""} ya 🙏`, alert: true });
        return;
      }
      if (data === "rolemenu_close") {
        await event.answer();
        roleMenuState.delete(userId);
        try { const c = await event.getInputChat(); await bot.deleteMessages(c, [event.messageId], { revoke: true }); }
        catch { try { await editView(event, "✕ Ditutup.", [], false); } catch {} }
        return;
      }
      if (data === "rolemenu" || data.startsWith("rolemenu_p")) {
        await event.answer();
        roleMenuState.delete(userId);
        const page = data.startsWith("rolemenu_p") ? parseInt(data.slice(10)) : 0;
        await showRoleMenu(userId, event, page || 0);
        return;
      }
      if (data.startsWith("ruextok_")) {
        await event.answer();
        const rest = data.slice(8);
        const idx = rest.lastIndexOf("_");
        await execExtend(userId, rest.slice(0, idx), parseInt(rest.slice(idx + 1)), event);
        return;
      }
      if (data.startsWith("ruext_")) {
        await event.answer();
        await startExtend(userId, data.slice(6), event);
        return;
      }
      if (data.startsWith("rustopok_")) {
        await event.answer();
        await execStop(userId, data.slice(9), event);
        return;
      }
      if (data.startsWith("rustop_")) {
        await event.answer();
        await confirmStop(userId, data.slice(7), event);
        return;
      }
      if (data.startsWith("ru_")) {
        await event.answer();
        roleMenuState.delete(userId);
        await showUserDetail(userId, data.slice(3), event);
        return;
      }
      return;
    }

    if (data === "conn_default" || data === "conn_own" || data === "conn_cancel") {
      await event.answer();
      const peer = event.peer || (await event.getInputChat());

      if (data === "conn_cancel") {
        loginState.delete(userId);
        await send(userId, `✕ Dibatalkan.`, peer);
        return;
      }

      if (data === "conn_default") {
        if (!API_ID || !API_HASH) {
          await send(userId, `❌ API bawaan belum diset di server. Pakai opsi Manual.`, peer);
          return;
        }
        loginState.set(userId, { step: "phone", apiId: API_ID, apiHash: API_HASH, peer });
        await send(userId,
          `⚡ <b>MODE CEPAT</b>\n\n` +
          `⚠️ <i>Mode ini pakai API bawaan (sharing dengan user lain). Kalau API kena limit, CFD & command bisa error. Mau paling stabil? Batalkan & pilih 🔧 Manual.</i>\n\n` +
          `Kirim <b>nomor HP</b> kamu (format +62...).\n\n` +
          `Ketik /cancel untuk batal.`,
          peer
        );
        return;
      }

      if (data === "conn_own") {
        loginState.set(userId, { step: "apiId", peer });
        await send(userId,
          `🔧 <b>MODE MANUAL</b>\n\n` +
          `Langkah 1/4: Kirim <b>API ID</b> kamu.\n\n` +
          `<i>Dapatkan di my.telegram.org/apps</i>\n` +
          `Ketik /cancel untuk batal.`,
          peer
        );
        return;
      }
    }

    if (data === "bc_confirm") {
      await event.answer();
      await executeBroadcast(userId, event.peer || (await event.getInputChat()));
      return;
    }
    if (data === "bc_cancel") {
      await event.answer();
      broadcastState.delete(userId);
      await send(userId, `✕ Broadcast dibatalkan.`, event.peer || (await event.getInputChat()));
      return;
    }

    if (data.startsWith("sb_")) {
      await event.answer();
      const peer = event.peer || (await event.getInputChat());

      if (data === "sb_new") {
        await sandboxStartNew(userId, peer, event);
        return;
      }
      if (data === "sb_cancelnew") {
        sandboxState.delete(userId);
        await handleSandbox(userId, peer, event);
        return;
      }
      if (data.startsWith("sb_feat:")) {
        const feat = data.slice(8);
        const state = sandboxState.get(userId);
        if (state?.draft) {
          state.draft.features[feat] = !state.draft.features[feat];
          await showFeatureToggles(userId, peer, event);
        }
        return;
      }
      if (data === "sb_confirm") {
        const state = sandboxState.get(userId);
        if (!state?.draft?.name) {
          await send(userId, `❌ Data project tidak lengkap. Ulangi /sandbox.`, peer);
          return;
        }
        const project = sandbox.createProject(userId, state.draft);
        await showEditMode(userId, peer, project.id, event);
        return;
      }
      if (data.startsWith("sb_edit:")) {
        await showEditMode(userId, peer, data.slice(8), event);
        return;
      }
      if (data.startsWith("sb_ai:")) {
        await sandboxAIStart(userId, peer, data.slice(6), event);
        return;
      }
      if (data.startsWith("sb_aians:")) {
        const st = sandboxState.get(userId);
        if (!st || !st.ai || !st.ai.questions || !st.ai.questions.length) { await handleSandbox(userId, peer, event); return; }
        const idx = parseInt(data.slice(9));
        const q = st.ai.questions[st.ai.qIndex];
        st.ai.qa.push(`Q: ${q.q} | A: ${q.options[idx] || "?"}`);
        st.ai.qIndex++;
        if (st.ai.qIndex < st.ai.questions.length) await showAIQuestion(userId, peer, event);
        else { st.ai.questions = []; await sandboxAIRun(userId, peer, event); }
        return;
      }
      if (data.startsWith("sb_activate:")) {
        const pid = data.slice(12);
        sandbox.setActive(userId, pid);
        await showEditMode(userId, peer, pid, event);
        return;
      }
      if (data === "sb_close") {
        sandboxState.delete(userId);
        sandboxPanel.delete(userId);
        try { const chat = await event.getInputChat(); await bot.deleteMessages(chat, [event.messageId], { revoke: true }); } catch {}
        return;
      }
      if (data.startsWith("sb_save:")) {
        sandboxState.delete(userId);
        await sbView(userId, peer, `💾 <b>Project disimpan!</b>\n\nBuka menu /start → tombol Sandbox untuk lihat project kamu.`, [[Button.inline("« Tutup", Buffer.from("sb_close"))]], event);
        sandboxPanel.delete(userId);
        return;
      }
      if (data.startsWith("sb_cancel:")) {
        sandboxState.delete(userId);
        await sbView(userId, peer, `✕ Keluar dari Edit Mode.`, [[Button.inline("« Tutup", Buffer.from("sb_close"))]], event);
        sandboxPanel.delete(userId);
        return;
      }

      if (data.startsWith("sb_del:")) {
        const pid = data.slice(7);
        const project = sandbox.getProject(userId, pid);
        if (!project) { await send(userId, `❌ Project tidak ditemukan.`, peer); return; }
        await sbView(userId, peer,
          `🗑️ <b>Hapus Project "${esc(project.name)}"?</b>\n\nTindakan ini permanen dan tidak bisa dibatalkan.`,
          [[Button.inline("✅ Ya, Hapus", Buffer.from("sb_delyes:" + pid)),
            Button.inline("✕ Batal", Buffer.from("sb_delno:" + pid))]],
          event
        );
        return;
      }
      if (data.startsWith("sb_delyes:")) {
        const pid = data.slice(10);
        const project = sandbox.getProject(userId, pid);
        sandbox.deleteProject(userId, pid);
        sandboxState.delete(userId);
        await handleSandbox(userId, peer, event);
        return;
      }
      if (data.startsWith("sb_delno:")) {
        const pid = data.slice(9);
        await showEditMode(userId, peer, pid, event);
        return;
      }

      if (data.startsWith("sb_addkey:")) {
        const pid = data.slice(10);
        sandboxState.set(userId, { step: "keyname", projectId: pid, peer, keyDraft: { capabilities: [] } });
        await sbPrompt(userId, peer,
          `🔑 <b>ADD KEY</b>\n\n` +
          `Kirim <b>nama key</b> (contoh: <code>spam</code>, <code>promo</code>, <code>kick</code>).\n\n` +
          `<i>Nama ini jadi command tanpa prefix di tab. Ketik /cancel untuk batal.</i>`,
          "sb_cancelkey", event
        );
        return;
      }
      if (data.startsWith("sb_keycap:")) {
        const cap = data.slice(10);
        const st = sandboxState.get(userId);
        if (st?.keyDraft) {
          const caps = st.keyDraft.capabilities;
          const idx = caps.indexOf(cap);
          if (idx === -1) caps.push(cap); else caps.splice(idx, 1);
          await showKeyCaps(userId, peer, event);
        }
        return;
      }
      if (data === "sb_savekey") {
        const st = sandboxState.get(userId);
        if (!st?.keyDraft?.name || !st.projectId) {
          await send(userId, `❌ Data key tidak lengkap.`, peer);
          return;
        }
        const project = sandbox.getProject(userId, st.projectId);
        if (!project) { await send(userId, `❌ Project tidak ditemukan.`, peer); return; }
        if (project.keys.some(k => k.name === st.keyDraft.name)) {
          await send(userId, `⚠️ Key "<b>${esc(st.keyDraft.name)}</b>" sudah ada di project ini.`, peer);
          return;
        }
        project.keys.push({ name: st.keyDraft.name, capabilities: st.keyDraft.capabilities });
        sandbox.saveProject(userId, project);
        await showEditMode(userId, peer, st.projectId, event);
        return;
      }
      if (data === "sb_cancelkey") {
        const st = sandboxState.get(userId);
        const pid = st?.projectId;
        if (pid) await showEditMode(userId, peer, pid, event);
        else { sandboxState.delete(userId); await handleSandbox(userId, peer, event); }
        return;
      }

      if (data.startsWith("sb_view:")) {
        await showProjectContent(userId, peer, data.slice(8), event);
        return;
      }

      if (data.startsWith("sb_editmenu:")) {
        await showEditMenu(userId, peer, data.slice(12), event);
        return;
      }
      if (data.startsWith("sb_editkey:")) {
        await showEditKeyList(userId, peer, data.slice(11), event);
        return;
      }
      if (data.startsWith("sb_pickkey:")) {
        const rest = data.slice(11);
        const sep = rest.indexOf(":");
        const pid = rest.slice(0, sep);
        const keyName = rest.slice(sep + 1);
        const cur = sandboxState.get(userId);
        if (cur && cur.editKeyName !== keyName) sandboxState.delete(userId);
        await showKeyEditor(userId, peer, pid, keyName, event);
        return;
      }
      if (data.startsWith("sb_kc2:")) {
        const cap = data.slice(7);
        const st = sandboxState.get(userId);
        if (st?.keyDraft) {
          const caps = st.keyDraft.capabilities;
          const idx = caps.indexOf(cap);
          if (idx === -1) caps.push(cap); else caps.splice(idx, 1);
          await showKeyEditor(userId, peer, st.projectId, st.editKeyName, event);
        }
        return;
      }
      if (data === "sb_keytext") {
        const st = sandboxState.get(userId);
        if (st?.keyDraft) {
          st.step = "keytext";
          const varList = Object.entries(TEMPLATE_VARS)
            .map(([v, d]) => `<code>${v}</code> — ${d}`).join("\n");
          await sbView(userId, peer,
            `📝 <b>SET TEKS RESPONS</b>\n` +
            `⏣────────────────⏣\n\n` +
            `Kirim teks untuk key <code>${esc(st.keyDraft.name)}</code>.\n` +
            `Teks ini dikirim ubot saat key dipakai.\n\n` +
            `<b>Variable yang bisa dipakai:</b>\n${varList}\n\n` +
            `<i>Contoh: <code>Halo {name}, selamat datang di {group}!</code></i>`,
            [[Button.inline("« Batal", Buffer.from("sb_pickkey:" + st.projectId + ":" + st.editKeyName))]],
            event
          );
        }
        return;
      }
      if (data === "sb_keyprev") {
        const st = sandboxState.get(userId);
        if (!st?.keyDraft) return;
        const d = st.keyDraft;
        const project = sandbox.getProject(userId, st.projectId);
        const prefix = project?.prefix || ".";
        const actions = (d.capabilities || []).map(c => `  • ${KEY_CAPS[c] || c}`).join("\n") || "  <i>(belum ada aksi)</i>";
        await sbView(userId, peer,
          `📊 <b>PREVIEW KEY: ${esc(d.name)}</b>\n` +
          `⏣────────────────⏣\n\n` +
          `Saat user ketik <code>${esc(prefix + d.name)}</code>, ubot akan:\n\n` +
          `${actions}\n\n` +
          `<b>Dengan teks:</b>\n${d.config?.text ? esc(d.config.text) : "<i>(belum diatur)</i>"}`,
          [[Button.inline("« Kembali", Buffer.from("sb_pickkey:" + st.projectId + ":" + st.editKeyName))]],
          event
        );
        return;
      }
      if (data === "sb_savekeyedit") {
        const st = sandboxState.get(userId);
        if (!st?.keyDraft || !st.projectId || !st.editKeyName) { await send(userId, `❌ Data tidak lengkap.`, peer); return; }
        const project = sandbox.getProject(userId, st.projectId);
        const key = project?.keys.find(k => k.name === st.editKeyName);
        if (!key) { await send(userId, `❌ Key tidak ditemukan.`, peer); return; }
        key.capabilities = st.keyDraft.capabilities;
        key.config = st.keyDraft.config || {};
        sandbox.saveProject(userId, project);
        await sbView(userId, peer,
          `✅ <b>Key "${esc(key.name)}" diperbarui!</b>\n\n` +
          `Aksi: ${key.capabilities.length} | Teks respons: ${key.config.text ? "✅" : "⬜"}`,
          [[Button.inline("« Kembali ke Daftar Key", Buffer.from("sb_editkey:" + st.projectId))]],
          event
        );
        return;
      }
      if (data.startsWith("sb_edittab:")) {
        const pid = data.slice(11);
        const project = sandbox.getProject(userId, pid);
        if (!project?.tabs.length) {
          await sbView(userId, peer, `📑 <b>EDIT TAB</b>\n⏣────────────────⏣\n\nKamu belum punya tab.\nBuat dulu lewat <b>Add Tab</b>.`,
            [[Button.inline("« Kembali", Buffer.from("sb_editmenu:" + pid))]], event);
          return;
        }
        const text = `📑 <b>EDIT TAB</b>\n⏣────────────────⏣\n\nDaftar tab kamu:`;
        const rows = project.tabs.map(t => [Button.inline(`📑 ${t.name}`, Buffer.from("sb_picktab:" + pid + ":" + t.id))]);
        rows.push([Button.inline("« Kembali", Buffer.from("sb_editmenu:" + pid))]);
        await sbView(userId, peer, text, rows, event);
        return;
      }
      if (data.startsWith("sb_picktab:")) {
        const rest = data.slice(11);
        const sep = rest.indexOf(":");
        const pid = rest.slice(0, sep);
        const tabId = rest.slice(sep + 1);
        const project = sandbox.getProject(userId, pid);
        const tab = project?.tabs.find(t => t.id === tabId);
        if (!tab) { await send(userId, `❌ Tab tidak ditemukan.`, peer); return; }
        const sty = [tab.quote && "kutip", tab.bold && "tebal", tab.smallcaps && "kecil"].filter(Boolean).join("+") || "polos";
        await sbView(userId, peer,
          `📑 <b>TAB: ${esc(tab.name)}</b>\n⏣────────────────⏣\n\n` +
          `<b>Teks:</b> ${tab.text ? esc(tab.text.slice(0, 80)) : "(kosong)"}\n` +
          `<b>Foto:</b> ${tab.photo ? "✅" : "⬜"}\n` +
          `<b>Gaya:</b> ${sty}\n` +
          `<b>Tombol:</b> ${tab.buttons.length}`,
          [[Button.inline("🗑️ Hapus Tab", Buffer.from("sb_deltab:" + pid + ":" + tabId))],
           [Button.inline("« Kembali", Buffer.from("sb_edittab:" + pid))]],
          event
        );
        return;
      }
      if (data.startsWith("sb_deltab:")) {
        const rest = data.slice(10);
        const sep = rest.indexOf(":");
        const pid = rest.slice(0, sep);
        const tabId = rest.slice(sep + 1);
        const project = sandbox.getProject(userId, pid);
        if (project) {
          project.tabs = project.tabs.filter(t => t.id !== tabId);
          sandbox.saveProject(userId, project);
        }
        await sbView(userId, peer, `🗑️ <b>Tab dihapus.</b>`,
          [[Button.inline("« Kembali", Buffer.from("sb_edittab:" + pid))]], event);
        return;
      }
      if (data.startsWith("sb_editbtn:")) {
        const pid = data.slice(11);
        const project = sandbox.getProject(userId, pid);
        const btns = project?.buttons || [];
        if (!btns.length) {
          await sbView(userId, peer, `🔘 <b>EDIT BUTTON</b>\n⏣────────────────⏣\n\nKamu belum punya button.\nBuat dulu lewat <b>Add Button</b>.`,
            [[Button.inline("« Kembali", Buffer.from("sb_editmenu:" + pid))]], event);
          return;
        }
        const text = `🔘 <b>EDIT BUTTON</b>\n⏣────────────────⏣\n\nDaftar button kamu:`;
        const rows = btns.map((b, i) => [Button.inline(`🔘 ${b.name}`, Buffer.from("sb_delbtn:" + pid + ":" + i))]);
        rows.push([Button.inline("« Kembali", Buffer.from("sb_editmenu:" + pid))]);
        await sbView(userId, peer, text, rows, event);
        return;
      }
      if (data.startsWith("sb_delbtn:")) {
        const rest = data.slice(10);
        const sep = rest.indexOf(":");
        const pid = rest.slice(0, sep);
        const idx = parseInt(rest.slice(sep + 1));
        const project = sandbox.getProject(userId, pid);
        if (project?.buttons) {
          project.buttons.splice(idx, 1);
          sandbox.saveProject(userId, project);
        }
        await sbView(userId, peer, `🗑️ <b>Button dihapus.</b>`,
          [[Button.inline("« Kembali", Buffer.from("sb_editbtn:" + pid))]], event);
        return;
      }

      if (data.startsWith("sb_addtab:")) {
        const pid = data.slice(10);
        sandboxState.set(userId, { step: "tabname", projectId: pid, peer, tabDraft: { buttons: [], quote: true, bold: true, smallcaps: true } });
        await sbPrompt(userId, peer,
          `📑 <b>ADD TAB</b>\n\n` +
          `Kirim <b>nama tab</b> (contoh: <code>menu</code>, <code>info</code>, <code>rules</code>).\n\n` +
          `<i>Ketik /cancel untuk batal.</i>`,
          "sb_canceltab", event
        );
        return;
      }
      if (data.startsWith("sb_tabsty:")) {
        const sty = data.slice(10);
        const st = sandboxState.get(userId);
        if (st?.tabDraft) {
          st.tabDraft[sty] = !st.tabDraft[sty];
          await showTabStyle(userId, peer, event);
        }
        return;
      }
      if (data === "sb_tabtext") {
        const st = sandboxState.get(userId);
        if (st?.tabDraft) {
          st.step = "tabtext";
          await sbPrompt(userId, peer, `📝 Kirim <b>teks isi tab</b> sekarang.\n\n<i>Bisa pakai {name} & {group} sebagai placeholder.</i>`, "sb_canceltab", event);
        }
        return;
      }
      if (data === "sb_tabphoto") {
        const st = sandboxState.get(userId);
        if (st?.tabDraft) {
          st.step = "tabphoto";
          await sbPrompt(userId, peer, `🖼️ Kirim <b>link foto</b> (URL gambar) untuk tab ini, atau ketik <code>hapus</code> untuk hapus foto.`, "sb_canceltab", event);
        }
        return;
      }
      if (data === "sb_savetab") {
        const st = sandboxState.get(userId);
        if (!st?.tabDraft?.name || !st.projectId) { await send(userId, `❌ Data tab tidak lengkap.`, peer); return; }
        const project = sandbox.getProject(userId, st.projectId);
        if (!project) { await send(userId, `❌ Project tidak ditemukan.`, peer); return; }
        if (project.tabs.some(t => t.name === st.tabDraft.name)) {
          await sbView(userId, peer, `⚠️ Tab "<b>${esc(st.tabDraft.name)}</b>" sudah ada. Pakai nama lain.`, [[Button.inline("« Kembali", Buffer.from("sb_edit:" + st.projectId))]], event);
          return;
        }
        project.tabs.push({
          id: "tab_" + Date.now(),
          name: st.tabDraft.name,
          text: st.tabDraft.text || "",
          photo: st.tabDraft.photo || null,
          quote: !!st.tabDraft.quote,
          bold: !!st.tabDraft.bold,
          smallcaps: !!st.tabDraft.smallcaps,
          buttons: [],
        });
        sandbox.saveProject(userId, project);
        await showEditMode(userId, peer, st.projectId, event);
        return;
      }
      if (data === "sb_canceltab") {
        const st = sandboxState.get(userId);
        const pid = st?.projectId;
        if (pid) await showEditMode(userId, peer, pid, event);
        else { sandboxState.delete(userId); await handleSandbox(userId, peer, event); }
        return;
      }

      if (data.startsWith("sb_addbtn:")) {
        const pid = data.slice(10);
        const project = sandbox.getProject(userId, pid);
        if (!project) { await send(userId, `❌ Project tidak ditemukan.`, peer); return; }
        if (project.tabs.length === 0) {
          await sbView(userId, peer, `⚠️ Buat <b>tab</b> dulu sebelum menambah tombol (tombol harus menuju ke sebuah tab).`, [[Button.inline("« Kembali", Buffer.from("sb_edit:" + pid))]], event);
          return;
        }
        sandboxState.set(userId, { step: "btnname", projectId: pid, peer, btnDraft: {} });
        await sbPrompt(userId, peer,
          `🔘 <b>ADD BUTTON</b>\n\n` +
          `Kirim <b>nama tombol</b> (yang tampil ke user, contoh: <code>Menu Utama</code>).\n\n` +
          `<i>Ketik /cancel untuk batal.</i>`,
          "sb_canceltab", event
        );
        return;
      }
      if (data.startsWith("sb_btntab:")) {
        const tabId = data.slice(10);
        const st = sandboxState.get(userId);
        if (!st?.btnDraft || !st.projectId) return;
        const project = sandbox.getProject(userId, st.projectId);
        const tab = project?.tabs.find(t => t.id === tabId);
        if (!tab) { await send(userId, `❌ Tab tidak ditemukan.`, peer); return; }
        if (!project.buttons) project.buttons = [];
        project.buttons.push({ name: st.btnDraft.name, targetTab: tabId });
        sandbox.saveProject(userId, project);
        await showEditMode(userId, peer, st.projectId, event);
        return;
      }

      if (data.startsWith("sb_addphoto:")) {
        const pid = data.slice(12);
        sandboxState.set(userId, { step: "projphoto", projectId: pid, peer });
        await sbPrompt(userId, peer,
          `🖼️ <b>ADD PHOTO</b>\n\n` +
          `Kirim <b>link foto</b> (URL gambar) untuk foto utama project ini.\n\n` +
          `<i>Foto ini tampil di menu utama ubot. Ketik /cancel untuk batal.</i>`,
          "sb_canceltab", event
        );
        return;
      }
      return;
    }
  } catch (e) {
    console.error("callback error:", e.message);
  }
}, new CallbackQuery({}));

const lastMainMsg = new Map();
let _botSelfId = null;

bot.addEventHandler(async (event) => {
  if (!__licensed()) return;
  try {
    const msg = event.message;
    if (!msg) return;
    if (msg.out) return;
    if (_botSelfId === null) { try { _botSelfId = (await bot.getMe()).id?.toString(); } catch {} }
    if (_botSelfId && msg.senderId?.toString() === _botSelfId) return;
    if (!msg.isPrivate && !isAllowedGroup(msg)) return;
    const userId = msg.senderId?.toString();
    if (!userId) return;
    const peer = msg.peerId;
    const text = (msg.text || "").trim();
    const hasPhoto = !!(msg.photo || (msg.media && msg.media.photo));
    if (!text && !hasPhoto) return;

    if (msg.isPrivate && custInputState.has(userId)) {
      const st = custInputState.get(userId);
      if (text === "/cancel") { custInputState.delete(userId); return send(userId, "✕ Dibatalkan.", peer); }
      if (st.action === "jfchats") {
        if (!text) return;
        const cur = customStore.get().joinFirst.chats.slice();
        const lines = text.split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
        const added = [];
        for (const ln of lines) {
          if (cur.length >= 3) break;
          if (cur.some((c) => c.ref === ln)) continue;
          try {
            const ent = await bot.getInputEntity(ln);
            let title = ln, link = ln.startsWith("http") ? ln : (ln.startsWith("@") ? "https://t.me/" + ln.slice(1) : ln);
            try { const full = await bot.getEntity(ent); title = full.title || full.username || ln; if (full.username) link = "https://t.me/" + full.username; } catch {}
            const item = { ref: ln, link, title };
            cur.push(item); added.push(item);
          } catch (e) {}
        }
        custInputState.delete(userId);
        if (!added.length) return send(userId, "❌ Nggak ada channel/grup valid ditambah (mungkin udah penuh 3, duplikat, atau bot belum masuk situ). Pastikan bot udah join channel/grupnya.", peer);
        customStore.setJoinFirst({ chats: cur });
        const listStr = cur.map((c, i) => `${i + 1}. ${esc(c.title)}`).join("\n");
        const rows = added.map((c) => [Button.url("🔗 Buka " + (c.title || "Chat"), c.link)]);
        rows.push([Button.inline("« Ke Custom", Buffer.from("tab_custom"))]);
        return sendView(peer,
          `✅ <b>DITAMBAHKAN!</b>\n⏣────────────────⏣\n\nChannel/grup wajib-join sekarang (${cur.length}/3):\n${listStr}\n\n⚠️ <b>PENTING:</b> add bot ini jadi <b>admin</b> di tiap channel/grup itu, biar bot bisa cek member. Tap tombol di bawah buat buka & tambahin botnya.`,
          rows, false);
      }
      if (st.action === "qris") {
        if (!hasPhoto) return send(userId, "❌ Kirim FOTO QRIS ya (bukan teks). Atau /cancel.", peer);
        try {
          await msg.downloadMedia({ outputFile: QRIS_FILE });
          customStore.save({ qrisSet: true });
          custInputState.delete(userId);
          return send(userId, "✅ QRIS tersimpan! Sekarang muncul pas user mau upgrade/beli role.", peer);
        } catch (e) { custInputState.delete(userId); return send(userId, "❌ Gagal simpan QRIS: " + e.message, peer); }
      }
      if (st.action === "gacode") {
        if (!text) return send(userId, "❌ Ketik kode redeem (teks). Atau /cancel.", peer);
        const code = text.replace(/\s+/g, "").toUpperCase();
        if (!/^[A-Z0-9]{2,20}$/.test(code)) return send(userId, "❌ Kode cuma huruf/angka (2–20 karakter), tanpa spasi. Coba lagi. Atau /cancel.", peer);
        if (giveawayStore.hasCode(code)) return send(userId, "❌ Kode itu udah kepakai. Coba kode lain. Atau /cancel.", peer);
        const wiz = st.wiz || {};
        giveawayStore.createCode(code, wiz.role, wiz.expType, wiz.expVal);
        custInputState.delete(userId);
        const r = gaCodeResult(wiz, code);
        return sendView(peer, r.text, r.rows, false);
      }
      return;
    }

    if (msg.isPrivate && payProofState.has(userId)) {
      const pp = payProofState.get(userId);
      if (text === "/cancel") { payProofState.delete(userId); return send(userId, "✕ Dibatalkan.", peer); }
      if (!hasPhoto) return send(userId, "❌ Kirim FOTO bukti transfer ya. Atau /cancel.", peer);
      payProofState.delete(userId);
      let buyerTag = `<code>${userId}</code>`;
      try { const bu = await bot.getEntity(parseInt(userId)); buyerTag = bu.username ? "@" + bu.username : ([bu.firstName, bu.lastName].filter(Boolean).join(" ") || buyerTag); } catch {}
      const ppDays = pp.days || 30;
      for (const oid of db.OWNER_IDS) {
        try {
          const ie = await bot.getInputEntity(parseInt(oid));
          try { await bot.forwardMessages(ie, { messages: [msg.id], fromPeer: peer }); } catch {}
          await bot.sendMessage(ie, {
            message: quote(`💳 <b>PESANAN MASUK</b>\n\nUser: ${buyerTag}\nID: <code>${userId}</code>\nMembeli role: <b>${harga.ROLE_LABEL[pp.role] || pp.role}</b>\nDurasi: <b>${ppDays} hari</b>\nNominal: <b>${harga.fmtRupiah(pp.amount)}</b>\n\nApprove?`),
            parseMode: "html",
            buttons: [[Button.inline("✅ Konfirmasi", Buffer.from(`qapprove:${userId}:${pp.role}:${ppDays}`)), Button.inline("❌ Batalkan", Buffer.from(`qreject:${userId}:${pp.role}`))]],
          });
        } catch {}
      }
      return send(userId, "✅ Bukti terkirim ke owner. Tunggu konfirmasi ya 🙏", peer);
    }

    if (msg.isPrivate && db.OWNER_IDS.includes(userId) && rejectReasonState.has(userId)) {
      const rr = rejectReasonState.get(userId);
      if (text === "/cancel") { rejectReasonState.delete(userId); return send(userId, "✕ Dibatalkan.", peer); }
      if (!text) return send(userId, "❌ Ketik alasan pembatalan (teks). Atau /cancel.", peer);
      rejectReasonState.delete(userId);
      const ownerTag = (OWNER_USERNAMES || "").split(",")[0].trim() || "Owner";
      try { await send(rr.buyerId, `❌ Owner ${ownerTag} <b>membatalkan</b> pesananmu${rr.role ? ` role <b>${harga.ROLE_LABEL[rr.role] || rr.role}</b>` : ""} dengan alasan: <i>${esc(text)}</i>`); } catch {}
      return send(userId, "✅ Alasan terkirim ke user.", peer);
    }

    if (msg.isPrivate && db.OWNER_IDS.includes(userId) && pmReplyState.has(userId)) {
      if (text === "/cancel") { pmReplyState.delete(userId); return send(userId, "✕ Mode jawab dibatalkan.", peer); }
      if (!text.startsWith("/")) {
        const tgt = pmReplyState.get(userId);
        pmReplyState.delete(userId);
        try {
          const ie = await bot.getInputEntity(parseInt(tgt.targetId));
          await bot.sendMessage(ie, { message: msg.text });
          return send(userId, `✅ Balasan terkirim ke <b>${esc(tgt.targetName)}</b> (<code>${tgt.targetId}</code>).`, peer);
        } catch (e) {
          return send(userId, `❌ Gagal kirim ke user: ${esc(e.message)}`, peer);
        }
      }
      pmReplyState.delete(userId);
    }
    if (msg.isPrivate && roleMenuState.has(userId) && (!text.startsWith("/") || text === "/cancel")) {
      const st = roleMenuState.get(userId);
      if (text === "/cancel") { roleMenuState.delete(userId); return send(userId, "✕ Dibatalkan.", peer); }
      const days = parseInt(text.trim());
      if (isNaN(days) || days <= 0 || days > 3650) {
        return send(userId, "❌ Masukin angka hari yang valid (1–3650), atau ketik /cancel.", peer);
      }
      roleMenuState.delete(userId);
      const nm = await getUserName(st.targetId);
      const confirmText = `❓ <b>Konfirmasi Extend</b>\n\nTambah <b>${days} hari</b> untuk <b>${esc(nm)}</b>\n🆔 <code>${st.targetId}</code>?`;
      const buttons = [[
        Button.inline("✅ Ya, Extend", Buffer.from(`ruextok_${st.targetId}_${days}`)),
        Button.inline("✕ Batal", Buffer.from(`ru_${st.targetId}`)),
      ]];
      try {
        const ie = await bot.getInputEntity(peer || parseInt(userId));
        await bot.sendMessage(ie, { message: confirmText, parseMode: "html", buttons });
      } catch (e) { console.error("extend confirm:", e.message); }
      return;
    }

    if (msg.isPrivate && loginState.has(userId) && (!text.startsWith("/") || text === "/cancel")) {
      await handleLoginStep(userId, text, peer);
      return;
    }

    if (msg.isPrivate && sandboxState.has(userId)) {
      const st = sandboxState.get(userId);
      const textSteps = ["name", "prefix", "keyname", "tabname", "tabtext", "tabphoto", "btnname", "projphoto", "keytext"];
      if (textSteps.includes(st.step) && (!text.startsWith("/") || text === "/cancel")) {
        await handleSandboxStep(userId, text, peer);
        return;
      }
    }

    if (msg.isPrivate && !db.OWNER_IDS.includes(userId) && !loginState.has(userId) && !sandboxState.has(userId)) {
      notifyPemilik(userId, text, peer).catch(() => {});
    }

    if (text === "/sandbox") return handleSandbox(userId, peer);
    const limitMatch = text.match(/^\/addlimit\s+(.+)$/);
    if (limitMatch) return handleAddLimit(userId, limitMatch[1].split(/\s+/), peer);

    if (text === "/stats") return handleStats(userId, peer);
    const broadcastMatch = text.match(/^\/broadcast\s+([\s\S]+)$/);
    if (broadcastMatch) return handleBroadcast(userId, [broadcastMatch[1].trim()], peer);
    const extendMatch = text.match(/^\/extend\s+(.+)$/);
    if (extendMatch) return handleExtend(userId, extendMatch[1].split(/\s+/), peer);

    if (text === "/start" || text.startsWith("/start ")) {
      if (msg.isPrivate) { try { giveawayStore.addSeen(userId); } catch {} }
      const payload = text.includes(" ") ? text.split(" ").slice(1).join(" ").trim() : "";
      if (payload === "connect" && msg.isPrivate) {
        return handleConnect(userId, peer);
      }

      if (msg.isPrivate && !db.OWNER_IDS.includes(userId) && !(await isMemberOfAll(userId))) {
        const uname = await getUserName(userId);
        const gv = joinGateView(uname);
        return sendView(peer, gv.text, gv.buttons, false);
      }

      const chatKey = (msg.chatId ?? userId).toString();
      const prevMsgId = lastMainMsg.get(chatKey);
      if (prevMsgId) {
        try {
          const p = await bot.getInputEntity(peer);
          await bot.deleteMessages(p, [prevMsgId], { revoke: true });
        } catch {}
      }
      const sent = await sendMainNew(userId, peer);
      if (sent && sent.id) lastMainMsg.set(chatKey, sent.id);
      if (validMiniAppUrl(MINIAPP_URL) && msg.isPrivate) {
        try {
          const iu = await bot.getInputEntity(parseInt(userId));
          await bot.invoke(new Api.bots.SetBotMenuButton({
            userId: iu,
            button: new Api.BotMenuButton({ text: "Open", url: buildMiniAppUrl(userId) }),
          }));
        } catch (e) { console.error("set menu button:", e.message); }
      }
      return;
    }

    if (text === "/connect") {
      if (!msg.isPrivate) {
        const botUser = (process.env.BOT_USERNAME || "").replace("@", "");
        return send(userId,
          `⚠️ <b>Connect ubot harus lewat chat PRIVATE (DM)!</b>\n\n` +
          `Login butuh OTP/password yang ga aman kalau diketik di grup. ` +
          `Chat bot ini langsung${botUser ? ` → @${botUser}` : ""}, lalu ketik /connect di situ.`,
          peer);
      }
      return handleConnect(userId, peer);
    }
    if (text === "/myubot") return handleMyUbot(userId, peer);
    if (text === "/disconnect") return handleDisconnect(userId, peer);

    const redeemMatch = text.match(/^\/redeem(?:\s+(.+))?$/i);
    if (redeemMatch) {
      const code = (redeemMatch[1] || "").trim();
      if (!code) return send(userId, `❌ Format: <code>/redeem KODE</code>`, peer);
      const res = giveawayStore.redeem(code, userId);
      if (!res.ok) {
        const m = res.reason === "already" ? "Kamu udah pernah pakai kode ini." :
                  res.reason === "expired" ? "Kode ini udah kadaluarsa." :
                  res.reason === "full" ? "Kuota kode ini udah habis." :
                  "Kode nggak valid / nggak ada.";
        return send(userId, `❌ ${m}`, peer);
      }
      db.addUser(userId, res.role, "redeem", 30);
      return send(userId, `🎉 <b>Redeem berhasil!</b> Kamu dapat role <b>${harga.ROLE_LABEL[res.role] || res.role}</b> selama 30 hari. Ketik /start.`, peer);
    }

    const addMatch = text.match(/^\/add(\w+)(?:\s+(.+))?$/);
    if (addMatch) {
      const role = addMatch[1].toLowerCase();
      const args = (addMatch[2] || "").split(/\s+/).filter(Boolean);
      if (db.ROLES[role] !== undefined) return handleAddRole(userId, role, args, peer);
    }
    const listMatch = text.match(/^\/list(\w+)$/);
    if (listMatch) {
      const role = listMatch[1].toLowerCase();
      if (db.ROLES[role] !== undefined) return handleListRole(userId, role, peer);
    }
    const removeMatch = text.match(/^\/remove\s+(.+)$/);
    if (removeMatch) return handleRemove(userId, removeMatch[1].split(/\s+/), peer);
  } catch (err) {
    console.error("Bot handler error:", err.message);
  }
}, new NewMessage({ incoming: true }));

async function sendMainNew(userId, peer) {
  const role = db.getRole(userId);
  const me = await getUserName(userId);
  const caption = buildWelcome(me, role, userId);
  const buttons = mainKeyboard(role, userId);
  return await sendView(peer, caption, buttons, true);
}

const { Raw } = require("telegram/events/Raw");
const { HTMLParser } = require("telegram/extensions/html");

function getHelpCategories() {
  const fs = require("fs");
  const path = require("path");
  const dir = path.join(__dirname, "ubot-plugins");
  const categories = {};
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith(".js"))) {
    try {
      const mod = require(path.join(dir, file));
      if (mod.commands) {
        for (const c of mod.commands) {
          const cat = c.category || "Umum";
          if (!categories[cat]) categories[cat] = [];
          categories[cat].push({ name: c.name, description: c.description || "-", game: c.game || null });
        }
      }
    } catch {}
  }
  return categories;
}

const PREFIX = process.env.UBOT_PREFIX || ".";

const CAT_ORDER = ["Umum", "AI", "Utilitas", "Islami", "Tools", "Fun", "Fonts", "Encode", "Text", "TextFun", "Math", "Convert", "Konversi", "Konversi Mega", "Generator", "InfoX", "Grup", "Filter", "Auto Reply", "Blacklist", "Promosi", "Transaksi", "Keuangan", "Todo", "Pengingat", "Alias", "Teks Cepat", "Bookmark", "Counter", "Gudang", "Ultah", "Habit", "Stopwatch", "Kesehatan", "Sekolah", "Acara", "Kalkulator", "Finansial", "Geometri", "Warna", "Warna CSS", "Random", "Ramalan", "Gaya Teks", "Waktu", "Jam Dunia", "Privasi", "Note", "Role", "Persen", "Angka", "Fisika", "Simbol", "Emoji", "Kaomoji", "Kutipan", "Downloader"];

function buildCategoryButtons(cats, currentCat, page = 0, themeId) {
  const catNames = CAT_ORDER.filter(c => cats[c]);

  if (currentCat) {
    const cmds = cats[currentCat] || [];
    const totalPages = Math.max(1, Math.ceil(cmds.length / CAT_PER_PAGE));
    const rows = [];
    if (totalPages > 1) {
      rows.push([
        Button.inline("◀", Buffer.from("help_catp:" + currentCat + ":" + ((page - 1 + totalPages) % totalPages))),
        Button.inline(`${page + 1}/${totalPages}`, Buffer.from("help_info")),
        Button.inline("▶", Buffer.from("help_catp:" + currentCat + ":" + ((page + 1) % totalPages))),
      ]);
    }
    rows.push([Button.inline(themeFont(themeId, "« Kembali ke Menu"), Buffer.from("help_menu"))]);
    return rows;
  }

  const rows = [];
  for (let i = 0; i < catNames.length; i += 2) {
    const row = [];
    for (let j = i; j < Math.min(i + 2, catNames.length); j++) {
      const cat = catNames[j];
      row.push(Button.inline(themeBtnLabel(themeId, cat), Buffer.from("help_cat:" + cat)));
    }
    rows.push(row);
  }
  rows.push([Button.inline(themeFont(themeId, "🎮 Games"), Buffer.from("help_games"))]);
  rows.push([Button.inline(themeFont(themeId, "📦 All Modules"), Buffer.from("help_all:0"))]);
  rows.push([
    Button.inline("◀", Buffer.from("help_prev")),
    Button.inline("⚙️", Buffer.from("help_info")),
    Button.inline("▶", Buffer.from("help_next")),
  ]);
  return rows;
}

const _fmt = require("./ubot-plugins/_format");

const CAT_PER_PAGE = 10;
function buildCategoryText(cats, cat, page = 0, themeId) {
  const cmds = (cats[cat] || []).slice().sort((a, b) => a.name.localeCompare(b.name));
  const totalPages = Math.max(1, Math.ceil(cmds.length / CAT_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const slice = cmds.slice(page * CAT_PER_PAGE, (page + 1) * CAT_PER_PAGE);
  const lines = [
    `🤖 <b>Userbot — ${cat}</b>`,
    `Total: <b>${cmds.length}</b> perintah | Hal ${page + 1}/${totalPages}\n`,
  ];
  for (const c of slice) lines.push(`  • <code>${PREFIX}${c.name}</code> — ${c.description}`);
  lines.push(`\n<i>« Kembali untuk menu utama</i>`);
  return `<blockquote><b>${styleThemed(themeId, lines.join("\n"))}</b></blockquote>`;
}

function buildGamesMenuText(cats, themeId) {
  const g = cats["Game"] || [];
  const ind = g.filter(c => c.game !== "party").length;
  const par = g.filter(c => c.game === "party").length;
  const lines = [
    `🎮 <b>GAMES</b>`,
    `Total: <b>${g.length}</b> game\n`,
    `🙋 <b>Individu</b> — ${ind} game (main sendiri)`,
    `👥 <b>Party</b> — ${par} game (rame-rame di grup)\n`,
    `<i>Pilih jenis di bawah 👇</i>`,
  ];
  return `<blockquote><b>${styleThemed(themeId, lines.join("\n"))}</b></blockquote>`;
}
function buildGamesMenuButtons() {
  return [
    [Button.inline("🙋 Individu", Buffer.from("help_gamecat:individu:0")), Button.inline("👥 Party", Buffer.from("help_gamecat:party:0"))],
    [Button.inline("« Kembali ke Menu", Buffer.from("help_menu"))],
  ];
}
function gameSubList(cats, sub) {
  return (cats["Game"] || []).filter(c => sub === "party" ? c.game === "party" : c.game !== "party").slice().sort((a, b) => a.name.localeCompare(b.name));
}
function buildGameCatText(cats, sub, page = 0, themeId) {
  const g = gameSubList(cats, sub);
  const totalPages = Math.max(1, Math.ceil(g.length / CAT_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const slice = g.slice(page * CAT_PER_PAGE, (page + 1) * CAT_PER_PAGE);
  const title = sub === "party" ? "Games — Party 👥" : "Games — Individu 🙋";
  const lines = [`🎮 <b>${title}</b>`, `Total: <b>${g.length}</b> game | Hal ${page + 1}/${totalPages}\n`];
  for (const c of slice) lines.push(`  • <code>${PREFIX}${c.name}</code> — ${c.description}`);
  if (sub === "party") lines.push(`\n<i>Cara: buka game, peserta ketik "Bergabung", host ${PREFIX}mulai.</i>`);
  lines.push(`\n<i>« Kembali</i>`);
  return `<blockquote><b>${styleThemed(themeId, lines.join("\n"))}</b></blockquote>`;
}
function buildGameCatButtons(cats, sub, page = 0) {
  const g = gameSubList(cats, sub);
  const totalPages = Math.max(1, Math.ceil(g.length / CAT_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const rows = [];
  if (totalPages > 1) rows.push([
    Button.inline("◀", Buffer.from("help_gamecat:" + sub + ":" + ((page - 1 + totalPages) % totalPages))),
    Button.inline(`${page + 1}/${totalPages}`, Buffer.from("help_info")),
    Button.inline("▶", Buffer.from("help_gamecat:" + sub + ":" + ((page + 1) % totalPages))),
  ]);
  rows.push([Button.inline("« Jenis Game", Buffer.from("help_games")), Button.inline("« Menu", Buffer.from("help_menu"))]);
  return rows;
}

const fontsLib = require("./ubot-plugins/fonts");
function styleThemed(themeId, html) {
  const fname = themes.font(themeId);
  if (fname === "smallcaps") return _fmt.styleHtml(html);
  const f = fontsLib.FONTS[fname];
  if (!f) return _fmt.styleHtml(html);
  return _fmt.styleHtmlWith(html, (s) => fontsLib.convert(s, f.map));
}
function themeFont(themeId, label) {
  const fname = themes.font(themeId);
  const f = fname !== "smallcaps" ? fontsLib.FONTS[fname] : null;
  return f ? fontsLib.convert(label, f.map) : label;
}
function themeBtnLabel(themeId, label) {
  const pfx = themes.deco(themeId);
  const txt = themeFont(themeId, label);
  return pfx ? `${pfx} ${txt}` : txt;
}

function buildMainMenuText(cats, ubotName, themeId) {
  const total = Object.values(cats).flat().length;
  const lines = [
    `✦ <b>MENU INLINE ⚙️🛡️ UBOT 🛡️⚙️</b> 🚌`,
    ``,
    `<b>TOTAL MODULES:</b> ${total}`,
    `<b>PREFIX:</b> <code>${PREFIX}</code>`,
    `<b>MY UBOT:</b> <b>${ubotName || "Userbot"}</b>`,
  ];
  return `<blockquote><b>${styleThemed(themeId, lines.join("\n"))}</b></blockquote>`;
}

function buildMainButtons(cats, themeId) {
  return buildCategoryButtons(cats, null, 0, themeId);
}

const ALL_PER_PAGE = 24;
function buildAllModulesText(cats, page, themeId) {
  const all = Object.values(cats).flat();
  const totalPages = Math.max(1, Math.ceil(all.length / ALL_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const lines = [
    `📦 <b>DAFTAR SEMUA MODUL</b>`,
    `Total: <b>${all.length}</b> modul terpasang | Hal ${page + 1}/${totalPages}\n`,
    `<i>Tap perintah di bawah untuk lihat panduannya 👇</i>`,
  ];
  return `<blockquote><b>${styleThemed(themeId, lines.join("\n"))}</b></blockquote>`;
}

function buildAllModulesButtons(cats, page, themeId) {
  const all = Object.values(cats).flat().sort((a, b) => a.name.localeCompare(b.name));
  const totalPages = Math.max(1, Math.ceil(all.length / ALL_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const slice = all.slice(page * ALL_PER_PAGE, (page + 1) * ALL_PER_PAGE);

  const rows = [];
  for (let i = 0; i < slice.length; i += 3) {
    const row = [];
    for (let j = i; j < Math.min(i + 3, slice.length); j++) {
      row.push(Button.inline(themeFont(themeId, slice[j].name), Buffer.from("help_cmd:" + slice[j].name + ":" + page)));
    }
    rows.push(row);
  }
  rows.push([
    Button.inline(themeFont(themeId, "◀ Prev"), Buffer.from("help_all:" + (page - 1 < 0 ? totalPages - 1 : page - 1))),
    Button.inline(`${page + 1}/${totalPages}`, Buffer.from("help_info")),
    Button.inline(themeFont(themeId, "Next ▶"), Buffer.from("help_all:" + (page + 1 >= totalPages ? 0 : page + 1))),
  ]);
  rows.push([Button.inline(themeFont(themeId, "« Menu Utama"), Buffer.from("help_menu"))]);
  return rows;
}

function buildCmdDetailText(cats, cmdName, themeId) {
  const all = Object.values(cats).flat();
  const cmd = all.find(c => c.name === cmdName);
  if (!cmd) return `<blockquote><b>${styleThemed(themeId, "❌ Perintah tidak ditemukan.")}</b></blockquote>`;
  const lines = [
    `📦 <b>MODULE: ${cmd.name}</b>`,
    `⏣────────────────⏣\n`,
    `<b>Perintah:</b> <code>${PREFIX}${cmd.name}</code>\n`,
    `<b>Panduan:</b>`,
    cmd.description || "-",
  ];
  return `<blockquote><b>${styleThemed(themeId, lines.join("\n"))}</b></blockquote>`;
}

function buildCmdDetailButtons(back, themeId) {
  return [[Button.inline(themeFont(themeId, "« Kembali"), Buffer.from(back))]];
}

const PREMIUM_PER_PAGE = 8;

function premCatList(cats) {
  const known = CAT_ORDER.filter(c => cats[c]);
  const extra = Object.keys(cats).filter(c => !CAT_ORDER.includes(c));
  return known.concat(extra);
}
function premHeader(ubotName, sub, themeId) {
  const nm = esc(ubotName || "Userbot");
  const body = `╭━━━━━━━━━━━━━━━━━━━━╮\n┃ 📚 <b>${nm}</b>\n┣━━━━━━━━━━━━━━━━━━━━┫\n┃ ${esc(sub)}\n┃ Prefix : <code>${PREFIX}</code>\n╰━━━━━━━━━━━━━━━━━━━━╯`;
  return `<blockquote>${_fmt.styleHtml(body)}</blockquote>`;
}
function helpMainHeader(ubotName) {
  const nm = esc(ubotName || "Userbot");
  const body =
    `📚 <b>HELP MENU</b>\n\n` +
    `Halo, <b>${nm}</b>! 👋\n\n` +
    `Selamat datang di pusat bantuan.\n` +
    `Pilih salah satu modul di bawah untuk melihat seluruh commandnya.\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `👤 <b>Informasi</b>\n` +
    `• 🤖 Bot : <b>${nm}</b>\n` +
    `• 📦 Modul : <b>${DISPLAY_MODULE_TOTAL}</b>\n` +
    `• 🔖 Versi : <b>Userbot Forgot Gen 2</b>\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `💡 Pilih modul untuk melihat command.\n` +
    `⚠️ Beberapa modul memerlukan role atau izin tertentu.`;
  return `<blockquote>${_fmt.styleHtml(body)}</blockquote>`;
}
function premNav(prefix, page, totalPages) {
  return [
    Button.inline("◄ ρяєν", Buffer.from(prefix + (page - 1 < 0 ? totalPages - 1 : page - 1))),
    Button.inline("〄", Buffer.from("help_info")),
    Button.inline("ηєχт ►", Buffer.from(prefix + (page + 1 >= totalPages ? 0 : page + 1))),
  ];
}
function joinGrupRows(userId) {
  const grup = (process.env.GRUP_UBOT || "").trim();
  if (!grup) return [];
  if (userId && addonStore.getAddon(userId).hideJoinGrup) return [];
  return [[Button.url("👥 Join Grup", grup)]];
}

function buildPremCmd(cats, page, ubotName, themeId, userId) {
  const all = Object.values(cats).flat().sort((a, b) => a.name.localeCompare(b.name));
  const la = userId ? addonStore.getAddon(userId) : { btnCols: 2, btnRows: 4 };
  const cols = Math.max(1, Math.min(4, la.btnCols || 2));
  const perPage = cols * Math.max(1, Math.min(4, la.btnRows || 4));
  const totalPages = Math.max(1, Math.ceil(all.length / perPage));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const slice = all.slice(page * perPage, (page + 1) * perPage);
  const rows = [];
  for (let i = 0; i < slice.length; i += cols) {
    const r = [];
    for (let j = i; j < Math.min(i + cols, slice.length); j++)
      r.push(Button.inline(themeFont(themeId, slice[j].name.toUpperCase()), Buffer.from("help_cmd:" + slice[j].name + ":a" + page)));
    rows.push(r);
  }
  if (!(userId && addonStore.getAddon(userId).hidePerfolder)) {
    rows.push([Button.inline(themeFont(themeId, "📂 Open Perfolder"), Buffer.from("help_pf:0"))]);
  }
  for (const r of joinGrupRows(userId)) rows.push(r);
  rows.push(premNav("help_pm:", page, totalPages));
  return { html: helpMainHeader(ubotName), rows };
}

function buildPremFolder(cats, page, ubotName, themeId) {
  const catList = premCatList(cats);
  const totalPages = Math.max(1, Math.ceil(catList.length / PREMIUM_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const slice = catList.slice(page * PREMIUM_PER_PAGE, (page + 1) * PREMIUM_PER_PAGE);
  const rows = [];
  for (let i = 0; i < slice.length; i += 2) {
    const r = [];
    for (let j = i; j < Math.min(i + 2, slice.length); j++) {
      const idx = catList.indexOf(slice[j]);
      r.push(Button.inline(themeFont(themeId, "🗂 " + slice[j].toUpperCase()), Buffer.from("help_fc:" + idx + ":0")));
    }
    rows.push(r);
  }
  rows.push([Button.inline(themeFont(themeId, "📋 Open Percommand"), Buffer.from("help_pm:0"))]);
  rows.push(premNav("help_pf:", page, totalPages));
  return { html: premHeader(ubotName, "Total folder : " + catList.length, themeId), rows };
}

function buildPremInCat(cats, catIdx, page, ubotName, themeId) {
  const catList = premCatList(cats);
  const cat = catList[catIdx] || catList[0];
  const cmds = (cats[cat] || []).slice().sort((a, b) => a.name.localeCompare(b.name));
  const totalPages = Math.max(1, Math.ceil(cmds.length / PREMIUM_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const slice = cmds.slice(page * PREMIUM_PER_PAGE, (page + 1) * PREMIUM_PER_PAGE);
  const rows = [];
  for (let i = 0; i < slice.length; i += 2) {
    const r = [];
    for (let j = i; j < Math.min(i + 2, slice.length); j++)
      r.push(Button.inline(themeFont(themeId, slice[j].name.toUpperCase()), Buffer.from("help_cmd:" + slice[j].name + ":c" + catIdx + "_" + page)));
    rows.push(r);
  }
  rows.push([Button.inline(themeFont(themeId, "« Back"), Buffer.from("help_pf:0"))]);
  rows.push(premNav("help_fc:" + catIdx + ":", page, totalPages));
  return { html: premHeader(ubotName, "Folder " + cat + " : " + cmds.length + " module", themeId), rows };
}

function buildHelpMain(cats, ubotName, themeId, page = 0, userId) {
  if (themes.style(themeId) === "premium") return buildPremCmd(cats, page, ubotName, themeId, userId);
  return { html: buildMainMenuText(cats, ubotName, themeId), rows: buildMainButtons(cats, themeId) };
}

function buildThemeMenuText(userId) {
  const th = themeStore.getTheme(userId);
  const list = themes.THEMES.map((t) => `${t.id === th ? "✅" : "▫️"} ${t.name} — ${t.desc}`).join("\n");
  const body = `⚙️ Settings — Custom Theme\n\nPilih tema buat tampilan menu kamu. Kesimpen otomatis & kepakai juga pas buka /start.\n\n${list}`;
  return `<blockquote><b>${_fmt.styleHtml(body)}</b></blockquote>`;
}
function buildThemeMenuButtons(userId) {
  const th = themeStore.getTheme(userId);
  const rows = [];
  for (let i = 0; i < themes.THEMES.length; i += 2) {
    rows.push(
      themes.THEMES.slice(i, i + 2).map((t) =>
        Button.inline(`${t.id === th ? "✅ " : ""}${t.name}`, Buffer.from("htheme_" + t.id))
      )
    );
  }
  rows.push([Button.inline("« Kembali ke Menu", Buffer.from("help_menu"))]);
  return rows;
}

const helpPageState = new Map();
const ubotNameByOwner = new Map();

function buildSearchListText(query, results) {
  const lines = [
    `🦆 <b>Hasil Pencarian</b>`,
    `<b>${esc(query)}</b>\n`,
    results.length
      ? `Ditemukan ${results.length} hasil. Tap salah satu untuk buka isinya 👇`
      : `Tidak ada hasil. Coba kata kunci lain.`,
  ];
  return `<blockquote><b>${_fmt.styleHtml(lines.join("\n"))}</b></blockquote>`;
}

function buildSearchListButtons(sid, results) {
  const rows = results.slice(0, 8).map((r, i) =>
    [Button.inline(`${i + 1}. ${r.title.slice(0, 50)}`, Buffer.from(`web:${sid}:${i}`))]
  );
  rows.push([Button.inline("✕ Tutup", Buffer.from("webclose"))]);
  return rows;
}

function buildPageText(query, item, content) {
  const head = `📄 <b>${esc(content.title || item.title)}</b>\n⏣────────────────⏣\n\n`;
  const body = content.text ? esc(content.text) : "";
  const styled = `<blockquote><b>${_fmt.styleHtml(head + body)}</b></blockquote>`;
  const safeUrl = esc(item.url);
  const link = `\n\n🔗 <a href="${safeUrl}">${safeUrl}</a>`;
  return styled + link;
}

function buildPageButtons(sid) {
  return [[Button.inline("« Kembali ke Hasil", Buffer.from(`webback:${sid}`))]];
}

const SHOP_PER_PAGE = 5;
function buildShopListText(query, results, page) {
  const totalPages = Math.max(1, Math.ceil(results.length / SHOP_PER_PAGE));
  const lines = [
    `🛒 <b>Hasil Belanja</b>`,
    `<b>${esc(query)}</b>\n`,
    results.length
      ? `Ditemukan ${results.length} produk. Halaman ${page + 1}/${totalPages}. Tap produk buat buka 👇`
      : `Tidak ada produk. Coba kata kunci lain.`,
  ];
  return `<blockquote><b>${_fmt.styleHtml(lines.join("\n"))}</b></blockquote>`;
}
function buildShopListButtons(sid, results, page) {
  const totalPages = Math.max(1, Math.ceil(results.length / SHOP_PER_PAGE));
  page = Math.max(0, Math.min(page, totalPages - 1));
  const start = page * SHOP_PER_PAGE;
  const slice = results.slice(start, start + SHOP_PER_PAGE);
  const rows = slice.map((r, i) => {
    const idx = start + i;
    const priceTag = r.price ? ` — ${r.price}` : "";
    let label = `${idx + 1}. ${r.title}${priceTag}`;
    if (label.length > 60) label = label.slice(0, 57) + "...";
    return [Button.inline(label, Buffer.from(`shop:${sid}:${idx}`))];
  });
  if (totalPages > 1) {
    const nav = [];
    if (page > 0) nav.push(Button.inline("◀ Prev", Buffer.from(`shopnav:${sid}:${page - 1}`)));
    nav.push(Button.inline(`${page + 1}/${totalPages}`, Buffer.from("shopnop")));
    if (page < totalPages - 1) nav.push(Button.inline("Next ▶", Buffer.from(`shopnav:${sid}:${page + 1}`)));
    rows.push(nav);
  }
  rows.push([Button.inline("✕ Tutup", Buffer.from("shopclose"))]);
  return rows;
}
function buildShopDetailText(item) {
  const parts = [`🛍️ <b>${esc(item.title)}</b>\n⏣────────────────⏣\n`];
  if (item.price) parts.push(`💰 Harga : <b>${esc(item.price)}</b>`);
  if (item.source) parts.push(`🏬 Toko : ${esc(item.source)}`);
  if (item.rating) parts.push(`⭐ Rating : ${esc(String(item.rating))}${item.ratingCount ? ` (${esc(String(item.ratingCount))} ulasan)` : ""}`);
  const styled = `<blockquote><b>${_fmt.styleHtml(parts.join("\n"))}</b></blockquote>`;
  const safeUrl = esc(item.link);
  const link = `\n\n🔗 <a href="${safeUrl}">Buka Produk</a>`;
  return styled + link;
}
function buildShopDetailButtons(sid, page) {
  return [[Button.inline("« Kembali ke Hasil", Buffer.from(`shopback:${sid}:${page}`))]];
}

bot.addEventHandler(async (update) => {
  if (!__licensed()) return;
  try {
    if (update.className !== "UpdateBotInlineQuery") return;
    const queryText = update.query?.trim() || "";

    if (queryText.startsWith("websearch ")) {
      const q = queryText.slice(10).trim();
      if (!q) return;
      let results = [];
      try { results = await websearch.ddgSearch(q); } catch (e) { console.error("ddg inline:", e.message); }

      let listText, listButtons, sid;
      if (!results.length && !websearch.isConfigured()) {
        sid = "noconf";
        listText = `<blockquote><b>${_fmt.styleHtml(
          `🔍 <b>Search belum diatur</b>\n⏣────────────────⏣\n\n` +
          `Owner perlu daftar gratis di <b>serper.dev</b> (2500 query gratis, tanpa kartu) lalu tambah di <code>.env</code>:\n\n` +
          `<code>SERPER_API_KEY=...</code>\n\n` +
          `Sementara itu, pakai <code>.wiki &lt;kata&gt;</code> untuk cari di Wikipedia.`
        )}</b></blockquote>`;
        listButtons = [[Button.inline("✕ Tutup", Buffer.from("webclose"))]];
      } else {
        cleanupSearch();
        sid = Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36);
        searchResults.set(sid, { query: q, results, ts: Date.now() });
        listText = buildSearchListText(q, results);
        listButtons = buildSearchListButtons(sid, results);
      }

      const [wText, wEnt] = HTMLParser.parse(listText);
      const wMarkup = new Api.ReplyInlineMarkup({
        rows: listButtons.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })),
      });

      const wResult = new Api.InputBotInlineResult({
        id: "websearch_res",
        type: "article",
        title: `🔍 ${q}`,
        description: results.length ? `${results.length} hasil ditemukan` : "Belum dikonfigurasi",
        sendMessage: new Api.InputBotInlineMessageText({
          message: wText, entities: wEnt, replyMarkup: wMarkup, noWebpage: true,
        }),
      });

      await bot.invoke(new Api.messages.SetInlineBotResults({
        queryId: update.queryId, results: [wResult], cacheTime: 0,
      }));
      return;
    }

    if (queryText.startsWith("canimasiai ")) {
      const sid = queryText.slice(11).trim();
      const canim = require("./ubot-plugins/canimasiai");
      let sess = null, ownerKey = null;
      for (const [k, v] of canim.__ai.aiSessions) { if (v.sid === sid) { sess = v; ownerKey = k; break; } }
      let qText, qButtons;
      if (!sess) {
        qText = `<blockquote><b>⚠️ Sesi Q&A sudah kedaluwarsa. Ketik ulang .canimasiai</b></blockquote>`;
        qButtons = [[Button.inline("✕ Tutup", Buffer.from("caiclose"))]];
      } else {
        const cur = sess.questions[sess.qIdx];
        const total = sess.questions.length;
        qText = `<blockquote><b>🤖 AI perlu info (${sess.qIdx + 1}/${total})\n\n${_fmt.esc(cur.q)}</b></blockquote>`;
        qButtons = cur.options.map((opt, i) =>
          [Button.inline(opt.length > 60 ? opt.slice(0, 57) + "..." : opt, Buffer.from(`cai:${sid}:${sess.qIdx}:${i}`))]);
      }
      const [t, e] = HTMLParser.parse(qText);
      const mk = new Api.ReplyInlineMarkup({ rows: qButtons.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      const r = new Api.InputBotInlineResult({
        id: "canimasiai_res", type: "article", title: "🤖 Pertanyaan AI",
        description: sess ? sess.questions[sess.qIdx].q.slice(0, 60) : "kedaluwarsa",
        sendMessage: new Api.InputBotInlineMessageText({ message: t, entities: e, replyMarkup: mk, noWebpage: true }),
      });
      await bot.invoke(new Api.messages.SetInlineBotResults({ queryId: update.queryId, results: [r], cacheTime: 0 }));
      return;
    }

    if (queryText.startsWith("shop ")) {
      const q = queryText.slice(5).trim();
      if (!q) return;
      let shopResp = { results: [] };
      try { shopResp = await websearch.serperShopping(q); } catch (e) { console.error("shop inline:", e.message); }
      const results = shopResp.results || [];

      let listText, listButtons, sid;
      if (!results.length && shopResp.error === "no_key") {
        sid = "noconf";
        listText = `<blockquote><b>${_fmt.styleHtml(
          `🛒 <b>Shop belum diatur</b>\n⏣────────────────⏣\n\n` +
          `Owner perlu daftar gratis di <b>serper.dev</b> lalu tambah di <code>.env</code>:\n\n` +
          `<code>SERPER_API_KEY=...</code>`
        )}</b></blockquote>`;
        listButtons = [[Button.inline("✕ Tutup", Buffer.from("shopclose"))]];
      } else {
        cleanupShop();
        sid = Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36);
        shopResults.set(sid, { query: q, results, ts: Date.now() });
        listText = buildShopListText(q, results, 0);
        listButtons = buildShopListButtons(sid, results, 0);
      }

      const [sText, sEnt] = HTMLParser.parse(listText);
      const sMarkup = new Api.ReplyInlineMarkup({
        rows: listButtons.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })),
      });
      const sResult = new Api.InputBotInlineResult({
        id: "shop_res",
        type: "article",
        title: `🛒 ${q}`,
        description: results.length ? `${results.length} produk ditemukan` : "Belum dikonfigurasi",
        sendMessage: new Api.InputBotInlineMessageText({
          message: sText, entities: sEnt, replyMarkup: sMarkup, noWebpage: true,
        }),
      });
      await bot.invoke(new Api.messages.SetInlineBotResults({
        queryId: update.queryId, results: [sResult], cacheTime: 0,
      }));
      return;
    }

    if (!queryText.startsWith("help")) return;

    const ubotName = queryText.slice(4).trim() || "Userbot";
    if (update.userId) ubotNameByOwner.set(update.userId.toString(), ubotName);

    const cats = getHelpCategories();

    const themeId = themeStore.getTheme(update.userId);
    let mainView;
    try {
      mainView = buildHelpMain(cats, ubotName, themeId, 0, update.userId?.toString());
      if (!mainView || !mainView.html || !Array.isArray(mainView.rows) || mainView.rows.length === 0) {
        throw new Error("mainView kosong");
      }
    } catch (eBuild) {
      console.error("buildHelpMain gagal, fallback classic:", eBuild.message);
      try {
        mainView = { html: buildMainMenuText(cats, ubotName, "old"), rows: buildMainButtons(cats, "old") };
      } catch (eBuild2) {
        const total = Object.values(cats).flat().length;
        mainView = {
          html: `<blockquote><b>🤖 Menu Userbot\nTotal modul: ${total}\nPrefix: <code>${PREFIX}</code></b></blockquote>`,
          rows: [[Button.inline("📦 All Modules", Buffer.from("help_all:0"))]],
        };
      }
    }
    const [parsedText, parsedEntities] = HTMLParser.parse(mainView.html);

    const markup = new Api.ReplyInlineMarkup({
      rows: mainView.rows.map(row =>
        new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })
      ),
    });
    if (update.userId) tagInlineOwner(markup, update.userId.toString());
    if (update.userId) colorHelpMarkup(markup, update.userId.toString());
    if (update.userId) lastInlineHelp.set(update.userId.toString(), { text: parsedText, entities: parsedEntities, markup });

    const textResult = new Api.InputBotInlineResult({
      id: "help_text",
      type: "article",
      title: "🤖 Menu Userbot",
      description: `Total ${DISPLAY_MODULE_TOTAL} modules`,
      sendMessage: new Api.InputBotInlineMessageText({
        message: parsedText,
        replyMarkup: markup,
        entities: parsedEntities,
      }),
    });

    const results = [];
    if (HEADER_PHOTO) {
      results.push(new Api.InputBotInlineResult({
        id: "help_main",
        type: "photo",
        title: "🤖 Menu Userbot",
        description: `Total ${DISPLAY_MODULE_TOTAL} modules`,
        url: HEADER_PHOTO,
        thumb: new Api.InputWebDocument({ url: HEADER_PHOTO, size: 0, mimeType: "image/jpeg", attributes: [] }),
        content: new Api.InputWebDocument({ url: HEADER_PHOTO, size: 0, mimeType: "image/jpeg", attributes: [] }),
        sendMessage: new Api.InputBotInlineMessageMediaAuto({
          message: parsedText,
          entities: parsedEntities,
          replyMarkup: markup,
        }),
      }));
    }
    results.push(textResult);

    await bot.invoke(new Api.messages.SetInlineBotResults({
      queryId: update.queryId,
      results,
      cacheTime: 0,
    }));
  } catch (e) {
    console.error("Inline query error:", e.message);
  }
}, new Raw({}));

bot.addEventHandler(async (update) => {
  if (!__licensed()) return;
  try {
    if (!(update instanceof Api.UpdateBotInlineSend) || !update.msgId) return;
    const uid = update.userId != null ? update.userId.toString() : null;
    if (!uid) return;
    const cached = lastInlineHelp.get(uid);
    if (!cached) return;
    startDisko(update.msgId, cached.text, cached.entities, cached.markup, uid);
  } catch {}
}, new Raw({}));

const OWNER_SEP = "\x1f";
let inlineOwnerTag = null;
function tagInlineOwner(markup, ownerId) {
  if (!markup || !ownerId) return markup;
  try {
    for (const row of (markup.rows || [])) {
      for (const btn of (row.buttons || [])) {
        if (btn && btn.className === "KeyboardButtonCallback" && btn.data != null) {
          const cur = Buffer.isBuffer(btn.data) ? btn.data.toString() : String(btn.data);
          if (!cur.includes(OWNER_SEP)) btn.data = Buffer.from(cur + OWNER_SEP + ownerId);
        }
      }
    }
  } catch {}
  return markup;
}

async function safeEditInline(msgId, text, entities, markup, showPreview) {
  if (!msgId) { console.error("[inline edit] msgId kosong"); return; }
  if (markup && inlineOwnerTag) tagInlineOwner(markup, inlineOwnerTag);
  if (markup && inlineOwnerTag) colorHelpMarkup(markup, inlineOwnerTag);
  try {
    await bot.invoke(new Api.messages.EditInlineBotMessage({
      id: msgId, message: text, entities, replyMarkup: markup,
      noWebpage: showPreview ? false : true,
    }));
    if (inlineOwnerTag) startDisko(msgId, text, entities, markup, inlineOwnerTag);
    else stopDisko(msgId);
  } catch (e) {
    console.error(`[inline edit] GAGAL (msgIdType=${msgId.className}):`, e.message);
  }
}

bot.addEventHandler(async (update) => {
  if (!__licensed()) return;
  try {
    if (update.className !== "UpdateInlineBotCallbackQuery" && update.className !== "UpdateBotCallbackQuery") return;
    inlineOwnerTag = null;
    let data = update.data?.toString();
    let dataOwner = null;
    if (data) {
      const si = data.indexOf(OWNER_SEP);
      if (si !== -1) { dataOwner = data.slice(si + 1); data = data.slice(0, si); }
    }

    if (data?.startsWith("cai:") || data === "caiclose") {
      try { await bot.invoke(new Api.messages.SetBotCallbackAnswer({ queryId: update.queryId, message: "", cacheTime: 0 })); } catch {}
      const canim = require("./ubot-plugins/canimasiai");
      if (data === "caiclose") {
        await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>✕ Dibatalkan.</b></blockquote>`), undefined);
        return;
      }
      const parts = data.split(":");
      const sid = parts[1]; const qIdx = parseInt(parts[2]); const optIdx = parseInt(parts[3]);
      let sess = null, ownerKey = null;
      for (const [k, v] of canim.__ai.aiSessions) { if (v.sid === sid) { sess = v; ownerKey = k; break; } }
      if (!sess) { await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>⚠️ Sesi kedaluwarsa. Ketik ulang .canimasiai</b></blockquote>`), undefined); return; }
      if (qIdx === sess.qIdx) {
        const cur = sess.questions[qIdx];
        const answer = cur.options[optIdx] || "";
        sess.answers.push({ q: cur.q, a: answer });
        sess.qIdx++;
        canim.__ai.setSess(ownerKey, sess);
      }
      if (sess.qIdx < sess.questions.length) {
        const cur = sess.questions[sess.qIdx];
        const total = sess.questions.length;
        const qText = `<blockquote><b>🤖 AI perlu info (${sess.qIdx + 1}/${total})\n\n${_fmt.esc(cur.q)}</b></blockquote>`;
        const qButtons = cur.options.map((opt, i) => [Button.inline(opt.length > 60 ? opt.slice(0, 57) + "..." : opt, Buffer.from(`cai:${sid}:${sess.qIdx}:${i}`))]);
        const mk = new Api.ReplyInlineMarkup({ rows: qButtons.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
        await safeEditInline(update.msgId, ...HTMLParser.parse(qText), mk);
        return;
      }
      await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>✅ Terima kasih! AI sedang membuat animasinya...</b></blockquote>`), undefined);
      try {
        const answerText = sess.answers.map(a => `- ${a.q} → ${a.a}`).join("\n");
        const msgs = sess.messages.concat([
          { role: "assistant", content: JSON.stringify({ action: "ask", questions: sess.questions }) },
          { role: "user", content: "Jawaban saya:\n" + answerText + "\n\nSekarang buat animasinya (action: done)." },
        ]);
        const r = await canim.__ai.callAI(msgs);
        const parsed = canim.__ai.parseAIJson(r.content);
        canim.__ai.clearSess(ownerKey);
        if (!parsed) { await canim.__ai.editStatus(sess.statusMsg, canim.__ai.stepView([`❌ AI kasih respons tidak valid. Coba lagi.`])); return; }
        const saved = await canim.__ai.saveAnimation(ownerKey, parsed);
        const prefix = (sess.ctx && sess.ctx.prefix) || ".";
        const animasi = require("./lib/animasiStore");
        if (!saved.ok) { await canim.__ai.editStatus(sess.statusMsg, canim.__ai.stepView([`❌ Gagal simpan: ${_fmt.esc(saved.error)}`])); return; }
        await canim.__ai.editStatus(sess.statusMsg,
          `<blockquote><b>✅ SUDAH SIAP, GUNAKAN COMMAND <code>${prefix}animasi ${_fmt.esc(animasi.label(saved.name))}</code> UNTUK MEMULAI!\n\n` +
          `Judul: ${_fmt.esc(saved.name)}\n` +
          `Deskripsi: ${_fmt.esc(saved.desc)}\n` +
          `Via ai: ${_fmt.esc(r.provider)}</b></blockquote>`);
        await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>✅ Animasi selesai dibuat! Cek chat kamu.</b></blockquote>`), undefined);
      } catch (e) {
        canim.__ai.clearSess(ownerKey);
        try { await canim.__ai.editStatus(sess.statusMsg, canim.__ai.stepView([`❌ Gagal: ${_fmt.esc(e.message)}`])); } catch {}
      }
      return;
    }

    if (data?.startsWith("shop:") || data?.startsWith("shopnav:") || data?.startsWith("shopback:") || data === "shopclose" || data === "shopnop") {
      try { await bot.invoke(new Api.messages.SetBotCallbackAnswer({ queryId: update.queryId, message: "", cacheTime: 0 })); } catch {}

      if (data === "shopnop") return;
      if (data === "shopclose") {
        await safeEditInline(update.msgId,
          ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("✕ Pencarian belanja ditutup.")}</b></blockquote>`),
          undefined);
        return;
      }
      if (data.startsWith("shopnav:")) {
        const parts = data.split(":");
        const sid = parts[1]; const page = parseInt(parts[2]) || 0;
        const s = shopResults.get(sid);
        if (!s) { await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("⚠️ Hasil sudah kedaluwarsa. Cari lagi.")}</b></blockquote>`), undefined); return; }
        const [t, e] = HTMLParser.parse(buildShopListText(s.query, s.results, page));
        const m = new Api.ReplyInlineMarkup({ rows: buildShopListButtons(sid, s.results, page).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
        await safeEditInline(update.msgId, t, e, m);
        return;
      }
      if (data.startsWith("shopback:")) {
        const parts = data.split(":");
        const sid = parts[1]; const page = parseInt(parts[2]) || 0;
        const s = shopResults.get(sid);
        if (!s) { await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("⚠️ Hasil sudah kedaluwarsa. Cari lagi.")}</b></blockquote>`), undefined); return; }
        const [t, e] = HTMLParser.parse(buildShopListText(s.query, s.results, page));
        const m = new Api.ReplyInlineMarkup({ rows: buildShopListButtons(sid, s.results, page).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
        await safeEditInline(update.msgId, t, e, m);
        return;
      }
      if (data.startsWith("shop:")) {
        const parts = data.split(":");
        const sid = parts[1]; const idx = parseInt(parts[2]);
        const s = shopResults.get(sid);
        if (!s || !s.results[idx]) { await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("⚠️ Hasil sudah kedaluwarsa. Cari lagi.")}</b></blockquote>`), undefined); return; }
        const item = s.results[idx];
        const page = Math.floor(idx / SHOP_PER_PAGE);
        const [pT, pE] = HTMLParser.parse(buildShopDetailText(item));
        const pM = new Api.ReplyInlineMarkup({ rows: buildShopDetailButtons(sid, page).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
        await safeEditInline(update.msgId, pT, pE, pM, true);
        return;
      }
      return;
    }

    if (data?.startsWith("web:") || data?.startsWith("webback:") || data === "webclose") {
      try { await bot.invoke(new Api.messages.SetBotCallbackAnswer({ queryId: update.queryId, message: "", cacheTime: 0 })); } catch {}

      if (data === "webclose") {
        await safeEditInline(update.msgId,
          ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("✕ Pencarian ditutup.")}</b></blockquote>`),
          undefined);
        return;
      }

      if (data.startsWith("webback:")) {
        const sid = data.slice(8);
        const s = searchResults.get(sid);
        if (!s) {
          await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("⚠️ Hasil pencarian sudah kedaluwarsa. Cari lagi.")}</b></blockquote>`), undefined);
          return;
        }
        const [t, e] = HTMLParser.parse(buildSearchListText(s.query, s.results));
        const m = new Api.ReplyInlineMarkup({
          rows: buildSearchListButtons(sid, s.results).map(row =>
            new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })),
        });
        await safeEditInline(update.msgId, t, e, m);
        return;
      }

      if (data.startsWith("web:")) {
        const parts = data.split(":");
        const sid = parts[1];
        const idx = parseInt(parts[2]);
        const s = searchResults.get(sid);
        if (!s || !s.results[idx]) {
          await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("⚠️ Hasil sudah kedaluwarsa. Cari lagi.")}</b></blockquote>`), undefined);
          return;
        }
        const item = s.results[idx];
        const loadMarkup = new Api.ReplyInlineMarkup({ rows: buildPageButtons(sid).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
        await safeEditInline(update.msgId, ...HTMLParser.parse(`<blockquote><b>${_fmt.styleHtml("⏳ Membuka halaman...")}</b></blockquote>`), loadMarkup);

        let content;
        try { content = await websearch.fetchPageContent(item.url); }
        catch (e) { content = { title: item.title, text: "", image: "" }; }
        if (!content.text || content.text.startsWith("(tidak ada teks")) {
          content.text = item.snippet
            ? item.snippet + "\n\n(Isi lengkap tidak bisa diambil — buka link di bawah untuk baca selengkapnya)"
            : "(Isi halaman tidak bisa diambil. Buka link di bawah untuk membaca.)";
        }

        const [pT, pE] = HTMLParser.parse(buildPageText(s.query, item, content));
        const pM = new Api.ReplyInlineMarkup({
          rows: buildPageButtons(sid).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })),
        });
        await safeEditInline(update.msgId, pT, pE, pM, true);
        return;
      }
      return;
    }

    if (!data?.startsWith("help_")) return;

    console.log(`[help callback] ${update.className} data=${data} user=${update.userId} msgIdType=${update.msgId?.className}`);

    if (dataOwner && String(update.userId) !== dataOwner) {
      try {
        if (privacyStore.get(dataOwner).onlyMe) {
          await bot.invoke(new Api.messages.SetBotCallbackAnswer({
            queryId: update.queryId, message: "Maaf, tapi elu sp? 🗿", alert: true, cacheTime: 0,
          }));
          return;
        }
      } catch {}
    }
    inlineOwnerTag = dataOwner || (update.userId != null ? String(update.userId) : null);

    const cats = getHelpCategories();
    try {
      await bot.invoke(new Api.messages.SetBotCallbackAnswer({
        queryId: update.queryId,
        message: data === "help_info"
          ? `🤖 UBot Manager | ${Object.values(cats).flat().length} command | Prefix: ${PREFIX}`
          : "",
        alert: data === "help_info",
        cacheTime: 0,
      }));
    } catch (ansErr) {
      console.error("[help callback] gagal answer:", ansErr.message);
    }

    const catNames = CAT_ORDER.filter(c => cats[c]);
    const userId = update.userId?.toString();
    const themeId = themeStore.getTheme(update.userId);
    const uname = ubotNameByOwner.get(userId) || "Userbot";

    if (data === "help_info") return;

    if (data === "help_settings") {
      try { await bot.invoke(new Api.messages.SetBotCallbackAnswer({ queryId: update.queryId, message: "", cacheTime: 0 })); } catch {}
      const [t, e] = HTMLParser.parse(buildThemeMenuText(update.userId));
      const m = new Api.ReplyInlineMarkup({ rows: buildThemeMenuButtons(update.userId).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }
    if (data.startsWith("htheme_")) {
      const id = data.slice(7);
      themeStore.setTheme(update.userId, id);
      try { await bot.invoke(new Api.messages.SetBotCallbackAnswer({ queryId: update.queryId, message: `Tema "${themes.get(id).name}" dipasang! ✅`, cacheTime: 0 })); } catch {}
      const [t, e] = HTMLParser.parse(buildThemeMenuText(update.userId));
      const m = new Api.ReplyInlineMarkup({ rows: buildThemeMenuButtons(update.userId).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }

    if (data.startsWith("help_pm:")) {
      const page = parseInt(data.slice(8)) || 0;
      const pv = buildHelpMain(cats, uname, themeId, page, userId);
      const [pText, pEnt] = HTMLParser.parse(pv.html);
      const pMarkup = new Api.ReplyInlineMarkup({
        rows: pv.rows.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })),
      });
      await safeEditInline(update.msgId, pText, pEnt, pMarkup);
      return;
    }

    if (data.startsWith("help_pf:")) {
      const page = parseInt(data.slice(8)) || 0;
      const pv = buildPremFolder(cats, page, uname, themeId);
      const [t, e] = HTMLParser.parse(pv.html);
      const m = new Api.ReplyInlineMarkup({ rows: pv.rows.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }
    if (data.startsWith("help_fc:")) {
      const rest = data.slice(8);
      const ci = rest.indexOf(":");
      const catIdx = parseInt(rest.slice(0, ci)) || 0;
      const page = parseInt(rest.slice(ci + 1)) || 0;
      const pv = buildPremInCat(cats, catIdx, page, uname, themeId);
      const [t, e] = HTMLParser.parse(pv.html);
      const m = new Api.ReplyInlineMarkup({ rows: pv.rows.map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }

    if (data.startsWith("help_all:")) {
      const page = parseInt(data.slice(9)) || 0;
      const [aText, aEnt] = HTMLParser.parse(buildAllModulesText(cats, page, themeId));
      const aMarkup = new Api.ReplyInlineMarkup({
        rows: buildAllModulesButtons(cats, page, themeId).map(row =>
          new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })
        ),
      });
      await safeEditInline(update.msgId, aText, aEnt, aMarkup);
      return;
    }

    if (data.startsWith("help_cmd:")) {
      const rest = data.slice(9);
      const lastColon = rest.lastIndexOf(":");
      const cmdName = rest.slice(0, lastColon);
      const ctx = rest.slice(lastColon + 1);
      let back;
      if (ctx[0] === "a") back = "help_pm:" + (parseInt(ctx.slice(1)) || 0);
      else if (ctx[0] === "c") { const pp = ctx.slice(1).split("_"); back = "help_fc:" + (parseInt(pp[0]) || 0) + ":" + (parseInt(pp[1]) || 0); }
      else back = "help_all:" + (parseInt(ctx) || 0);
      const [cText, cEnt] = HTMLParser.parse(buildCmdDetailText(cats, cmdName, themeId));
      const cMarkup = new Api.ReplyInlineMarkup({
        rows: buildCmdDetailButtons(back, themeId).map(row =>
          new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })
        ),
      });
      await safeEditInline(update.msgId, cText, cEnt, cMarkup);
      return;
    }

    let newHtml;
    if (data === "help_menu") {
      const mainView = buildHelpMain(cats, uname, themeId, 0, userId);
      const [mText, mEnt] = HTMLParser.parse(mainView.html);
      const mMarkup = new Api.ReplyInlineMarkup({
        rows: mainView.rows.map(row =>
          new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })
        ),
      });
      await safeEditInline(update.msgId, mText, mEnt, mMarkup);
      return;
    }

    if (data === "help_games") {
      const [t, e] = HTMLParser.parse(buildGamesMenuText(cats, themeId));
      const m = new Api.ReplyInlineMarkup({ rows: buildGamesMenuButtons().map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }
    if (data.startsWith("help_gamecat:")) {
      const rest = data.slice(13); const lc = rest.lastIndexOf(":");
      const sub = rest.slice(0, lc); const pg = parseInt(rest.slice(lc + 1)) || 0;
      const [t, e] = HTMLParser.parse(buildGameCatText(cats, sub, pg, themeId));
      const m = new Api.ReplyInlineMarkup({ rows: buildGameCatButtons(cats, sub, pg).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }
    if (data.startsWith("help_catp:")) {
      const rest = data.slice(10); const lc = rest.lastIndexOf(":");
      const ct = rest.slice(0, lc); const pg = parseInt(rest.slice(lc + 1)) || 0;
      const [t, e] = HTMLParser.parse(buildCategoryText(cats, ct, pg, themeId));
      const m = new Api.ReplyInlineMarkup({ rows: buildCategoryButtons(cats, ct, pg, themeId).map(row => new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })) });
      await safeEditInline(update.msgId, t, e, m);
      return;
    }

    let cat;
    if (data.startsWith("help_cat:")) {
      cat = data.slice(9);
      helpPageState.set(userId, catNames.indexOf(cat));
    } else if (data === "help_prev" || data === "help_next") {
      const cur = helpPageState.get(userId) || 0;
      const next = data === "help_next"
        ? (cur + 1) % catNames.length
        : (cur - 1 + catNames.length) % catNames.length;
      helpPageState.set(userId, next);
      cat = catNames[next];
    } else return;

    const [newText, newEntities] = HTMLParser.parse(buildCategoryText(cats, cat, 0, themeId));
    const newMarkup = new Api.ReplyInlineMarkup({
      rows: buildCategoryButtons(cats, cat, 0, themeId).map(row =>
        new Api.KeyboardButtonRow({ buttons: row.map(b => b.button || b) })
      ),
    });

    await safeEditInline(update.msgId, newText, newEntities, newMarkup);
  } catch (e) {
    console.error("help button error:", e.message);
  }
}, new Raw({}));


async function handleStats(userId, peer) {
  if (!db.OWNER_IDS.includes(userId)) {
    return send(userId, `❌ Hanya owner yang bisa lihat stats.`, peer);
  }
  const allUsers = db.loadDB().users || {};
  const now = Date.now();

  const roleCounts = { owner: 0, admin: 0, reseller: 0, prem: 0, user: 0 };
  let expired = 0;
  for (const u of Object.values(allUsers)) {
    if (u.role !== "owner" && u.role !== "pemilik" && u.expiresAt && now > u.expiresAt) { expired++; continue; }
    roleCounts[u.role] = (roleCounts[u.role] || 0) + 1;
  }

  const activeUbots = ubotMgr.activeUbots.size;
  const totalSessions = Object.keys(db.loadDB().sessions || {}).length;

  const fs = require("fs");
  let dbSize = "?", sbSize = "?";
  try { dbSize = (fs.statSync("data.json").size / 1024).toFixed(1) + " KB"; } catch {}
  try { sbSize = (fs.statSync("sandbox.json").size / 1024).toFixed(1) + " KB"; } catch {}

  const projects = (() => {
    try { const s = JSON.parse(fs.readFileSync("sandbox.json","utf8")); return Object.values(s).flat().length; } catch { return 0; }
  })();

  await send(userId,
    `📊 <b>Statistik Bot Manager</b>\n` +
    `⏣────────────────⏣\n\n` +
    `<b>👥 User:</b>\n` +
    `  👑 Owner: ${roleCounts.owner}\n` +
    `  🛡️ Admin: ${roleCounts.admin}\n` +
    `  💼 Reseller: ${roleCounts.reseller}\n` +
    `  ⭐ Prem: ${roleCounts.prem}\n` +
    `  ⏰ Expired: ${expired}\n\n` +
    `<b>🤖 Ubot:</b>\n` +
    `  Aktif sekarang: <b>${activeUbots}</b>\n` +
    `  Total session tersimpan: <b>${totalSessions}</b>\n\n` +
    `<b>🛠️ Sandbox:</b>\n` +
    `  Total project: <b>${projects}</b>\n\n` +
    `<b>💾 Storage:</b>\n` +
    `  data.json: <code>${dbSize}</code>\n` +
    `  sandbox.json: <code>${sbSize}</code>`,
    peer
  );
}

// ========================================================
// HANDLER: AUTO REACTION (incoming message)
// ========================================================
bot.addEventHandler(async (event) => {
  if (!__licensed()) return;
  try {
    const msg = event.message;
    if (!msg || msg.out) return;
    const senderId = msg.senderId?.toString();
    if (!senderId) return;

    // Skip kalo pesan dari bot sendiri
    if (_botSelfId && senderId === _botSelfId) return;

    const cfg = getAR(senderId);
    if (!cfg.enabled) return;

    // Filter scope
    const isGroup = !!msg.isGroup;
    const isChannel = !!msg.isChannel;
    const isPrivate = msg.isPrivate;

    if (isGroup && !cfg.includeGroups) return;
    if (isChannel && !cfg.includeChannels) return;
    if (isPrivate && !cfg.includePrivate) return;

    // Filter keyword
    if (cfg.keywordOnly) {
      const txt = (msg.text || "").toLowerCase();
      if (!txt || !cfg.keywords.some((k) => txt.includes(String(k).toLowerCase()))) return;
    }

    // Cooldown
    const now = Date.now();
    const last = arCooldown.get(senderId) || 0;
    if (now - last < (cfg.cooldownMs || 1500)) return;
    arCooldown.set(senderId, now);

    // Pilih emoji
    const emojiList = (cfg.emoji && cfg.emoji.length) ? cfg.emoji : ["👍"];
    const pick = cfg.random
      ? emojiList[Math.floor(Math.random() * emojiList.length)]
      : emojiList[0];

    // Kirim reaction
    try {
      await bot.invoke(new Api.messages.SendReaction({
        peer: msg.peerId,
        msgId: msg.id,
        big: false,
        reaction: [new Api.ReactionEmoji({ emoticon: pick })],
      }));
    } catch (e) {
      // Skip kalo message udah ilang / ga bisa di-react
    }
  } catch (e) {
    console.error("autoreaction error:", e.message);
  }
}, new NewMessage({ incoming: true }));

// ========================================================
// HANDLER: COMMAND AUTO REACTION & PAP AYANG
// ========================================================
bot.addEventHandler(async (event) => {
  if (!__licensed()) return;
  try {
    const msg = event.message;
    if (!msg || !msg.out) return;
    const text = (msg.text || "").trim();
    if (!text) return;
    const userId = msg.senderId?.toString();
    if (!userId) return;
    const peer = msg.peerId;

    // ============ /autoreact (COMMAND) ============
    if (text.startsWith("/autoreact")) {
      const args = text.slice("/autoreact".length).trim().split(/\s+/);
      const sub = (args[0] || "status").toLowerCase();
      const cfg = getAR(userId);

      if (sub === "on") {
        setAR(userId, { enabled: true });
        return send(userId, `✅ <b>AUTO REACTION AKTIF</b>\n\nEmoji: ${cfg.emoji.join(" ")}\nRandom: ${cfg.random ? "✅" : "❌"}\nGrup: ${cfg.includeGroups ? "✅" : "❌"}\nChannel: ${cfg.includeChannels ? "✅" : "❌"}`, peer);
      }
      if (sub === "off") {
        setAR(userId, { enabled: false });
        return send(userId, `❌ <b>AUTO REACTION MATI</b>`, peer);
      }
      if (sub === "emoji" && args[1]) {
        const list = args[1].split(",").map((s) => s.trim()).filter(Boolean);
        if (!list.length) return send(userId, `❌ Contoh: <code>/autoreact emoji 👍,❤️,🔥</code>`, peer);
        setAR(userId, { emoji: list });
        return send(userId, `✅ Emoji di-set: ${list.join(" ")}`, peer);
      }
      if (sub === "random") {
        const val = (args[1] || "").toLowerCase() === "on";
        setAR(userId, { random: val });
        return send(userId, `🎲 Random: ${val ? "✅ ON" : "❌ OFF"}`, peer);
      }
      if (sub === "groups") {
        const val = (args[1] || "").toLowerCase() === "on";
        setAR(userId, { includeGroups: val });
        return send(userId, `📢 Groups: ${val ? "✅ ON" : "❌ OFF"}`, peer);
      }
      if (sub === "channels") {
        const val = (args[1] || "").toLowerCase() === "on";
        setAR(userId, { includeChannels: val });
        return send(userId, `📡 Channels: ${val ? "✅ ON" : "❌ OFF"}`, peer);
      }
      if (sub === "private") {
        const val = (args[1] || "").toLowerCase() === "on";
        setAR(userId, { includePrivate: val });
        return send(userId, `💬 Private: ${val ? "✅ ON" : "❌ OFF"}`, peer);
      }
      if (sub === "keyword") {
        const mode = (args[1] || "").toLowerCase();
        if (mode === "add" && args[2]) {
          const kw = args.slice(2).join(" ").trim().toLowerCase();
          const nxt = [...cfg.keywords, kw];
          setAR(userId, { keywords: nxt, keywordOnly: true });
          return send(userId, `✅ Keyword: <code>${kw}</code>\nTotal: ${nxt.length}\nMode keyword: ✅ ON`, peer);
        }
        if (mode === "del" && args[2]) {
          const kw = args.slice(2).join(" ").trim().toLowerCase();
          const nxt = cfg.keywords.filter((k) => k !== kw);
          setAR(userId, { keywords: nxt, keywordOnly: nxt.length > 0 });
          return send(userId, `🗑️ Keyword dihapus: <code>${kw}</code>`, peer);
        }
        if (mode === "clear") {
          setAR(userId, { keywords: [], keywordOnly: false });
          return send(userId, `🗑️ Semua keyword dihapus`, peer);
        }
        if (mode === "on") { setAR(userId, { keywordOnly: true }); return send(userId, `✅ Mode keyword ON`, peer); }
        if (mode === "off") { setAR(userId, { keywordOnly: false }); return send(userId, `❌ Mode keyword OFF`, peer); }
        return send(userId, `📝 Keywords: ${cfg.keywords.length ? cfg.keywords.join(", ") : "(kosong)"}`, peer);
      }
      if (sub === "cooldown" && args[1]) {
        const ms = parseInt(args[1]);
        if (isNaN(ms) || ms < 0) return send(userId, `❌ Contoh: <code>/autoreact cooldown 2000</code> (ms)`, peer);
        setAR(userId, { cooldownMs: ms });
        return send(userId, `⏱️ Cooldown: ${ms}ms`, peer);
      }

      // default: status
      const st = getAR(userId);
      return send(userId,
        `⚡ <b>AUTO REACTION STATUS</b>\n` +
        `⏣────────────────⏣\n` +
        `🔘 Enabled: ${st.enabled ? "✅" : "❌"}\n` +
        `😀 Emoji: ${st.emoji.join(" ")}\n` +
        `🎲 Random: ${st.random ? "✅" : "❌"}\n` +
        `📢 Groups: ${st.includeGroups ? "✅" : "❌"}\n` +
        `📡 Channels: ${st.includeChannels ? "✅" : "❌"}\n` +
        `💬 Private: ${st.includePrivate ? "✅" : "❌"}\n` +
        `🔍 Keyword Only: ${st.keywordOnly ? "✅" : "❌"}\n` +
        `📝 Keywords: ${st.keywords.length ? st.keywords.join(", ") : "-"}\n` +
        `⏱️ Cooldown: ${st.cooldownMs}ms\n\n` +
        `<b>COMMAND:</b>\n` +
        `<code>/autoreact on/off</code>\n` +
        `<code>/autoreact emoji 👍,❤️,🔥</code>\n` +
        `<code>/autoreact random on/off</code>\n` +
        `<code>/autoreact groups on/off</code>\n` +
        `<code>/autoreact channels on/off</code>\n` +
        `<code>/autoreact private on/off</code>\n` +
        `<code>/autoreact keyword add/del/clear/on/off</code>\n` +
        `<code>/autoreact cooldown &lt;ms&gt;</code>`, peer);
    }

    // ============ /papayang ============
    if (text === "/papayang" || text.startsWith("/papayang ")) {
      const args = text.slice("/papayang".length).trim().split(/\s+/);
      const amount = Math.max(1, Math.min(5, parseInt(args[0]) || 1));

      await send(userId, `⏳ <i>Mengambil ${amount} foto ayang...</i>`, peer);

      let okCount = 0, failCount = 0;
      for (let i = 0; i < amount; i++) {
        const url = await fetchPapAyang();
        if (!url) { failCount++; continue; }
        try {
          await bot.sendFile(peer, {
            file: url,
            caption: `🌸 <b>Pap Ayang #${i + 1}</b>\n<i>cewe cantik indonesia~</i> 😹🖕🏿`,
            parseMode: "html",
          });
          okCount++;
        } catch (e) {
          failCount++;
        }
        await new Promise((r) => setTimeout(r, 800));
      }

      if (okCount === 0) {
        return send(userId, `❌ <b>Gagal ambil foto.</b>\nSemua API lagi down / limit. Coba lagi nanti, jing!`, peer);
      }
      return send(userId, `✅ <b>Pap ayang selesai!</b>\n\nSukses: ${okCount}\nGagal: ${failCount}`, peer);
    }

    // ============ /papayangoff ============
    if (text === "/stopayang" || text === "/papayangstop") {
      return send(userId, `ℹ️ Pap ayang cuma on-demand, gak ada mode auto. Ketik <code>/papayang [jumlah]</code> buat pakai.`, peer);
    }

  } catch (e) {
    console.error("command autoreact/papayang error:", e.message);
  }
}, new NewMessage({}));

const broadcastState = new Map();

async function handleBroadcast(userId, args, peer) {
  if (!db.OWNER_IDS.includes(userId)) {
    return send(userId, `❌ Hanya owner yang bisa broadcast.`, peer);
  }
  const text = args.join(" ");
  if (!text) {
    return send(userId, `❌ Format: <code>/broadcast &lt;pesan&gt;</code>`, peer);
  }

  const allUsers = db.loadDB().users || {};
  const targets = Object.keys(allUsers).filter(id => id !== userId);

  broadcastState.set(userId, { text });

  try {
    const target = await bot.getInputEntity(parseInt(userId));
    await bot.sendMessage(target, {
      message:
        `<blockquote><b>📢 <b>Konfirmasi Broadcast</b>\n\n` +
        `<b>Pesan:</b>\n${esc(text)}\n\n` +
        `<b>Target:</b> ${targets.length} user\n\n` +
        `<i>Yakin mau kirim?</i></b></blockquote>`,
      parseMode: "html",
      buttons: [
        [Button.inline("✅ Ya, Kirim", Buffer.from("bc_confirm")),
         Button.inline("✕ Batal", Buffer.from("bc_cancel"))],
      ],
    });
  } catch (e) {
    console.error("broadcast confirm error:", e.message);
  }
}

async function executeBroadcast(userId, peer) {
  const state = broadcastState.get(userId);
  if (!state) return;
  broadcastState.delete(userId);

  const allUsers = db.loadDB().users || {};
  const targets = Object.keys(allUsers).filter(id => id !== userId);

  await send(userId, `📤 Broadcast dimulai ke ${targets.length} user...`, peer);

  let ok = 0, fail = 0;
  for (const targetId of targets) {
    try {
      const t = await bot.getInputEntity(parseInt(targetId));
      await bot.sendMessage(t, {
        message: `<blockquote><b>📢 <b>Pesan dari Owner</b>\n\n${esc(state.text)}</b></blockquote>`,
        parseMode: "html",
      });
      ok++;
    } catch { fail++; }
    await new Promise(r => setTimeout(r, 500));
  }

  await send(userId, `✅ <b>Broadcast selesai!</b>\n\nTerkirim: ${ok}\nGagal: ${fail}`, peer);
}

async function handleExtend(userId, args, peer) {
  const role = db.getRole(userId);
  if (db.ROLES[role] < db.ROLES.reseller) {
    return send(userId, `❌ Role kamu tidak bisa memperpanjang user.`, peer);
  }
  const targetId = args[0];
  const days = parseInt(args[1]);
  if (!targetId || isNaN(days) || days < 1) {
    return send(userId, `❌ Format: <code>/extend &lt;user_id&gt; &lt;hari&gt;</code>`, peer);
  }

  const targetRole = db.getRole(targetId);
  if (db.ROLES[targetRole] >= db.ROLES[role]) {
    return send(userId, `❌ Tidak bisa extend user dengan role setara/lebih tinggi.`, peer);
  }
  if (targetRole === "user") {
    return send(userId, `❌ User tersebut tidak punya role aktif. Gunakan <code>/add${db.CAN_ADD[role]?.[0] || "prem"}</code> untuk kasih role dulu.`, peer);
  }

  const dbData = db.loadDB();
  const u = dbData.users[targetId];
  if (!u) return send(userId, `❌ User tidak ditemukan.`, peer);

  const now = Date.now();
  const base = (u.expiresAt && u.expiresAt > now) ? u.expiresAt : now;
  u.expiresAt = base + days * 24 * 60 * 60 * 1000;
  db.saveDB(dbData);

  const expDate = new Date(u.expiresAt).toLocaleDateString("id-ID", {
    day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta",
  });

  await send(userId,
    `✅ <b>Masa Aktif Diperpanjang</b>\n\n` +
    `User ID: <code>${targetId}</code>\n` +
    `Role: <b>${targetRole}</b>\n` +
    `Tambah: <b>${days} hari</b>\n` +
    `Berlaku sampai: <b>${expDate}</b>`,
    peer
  );

  try {
    const t = await bot.getInputEntity(parseInt(targetId));
    await bot.sendMessage(t, {
      message: `<blockquote><b>🎉 <b>Masa Aktif Diperpanjang!</b>\n\nRole <b>${targetRole}</b> kamu diperpanjang <b>${days} hari</b>.\nBerlaku sampai: ${expDate}</b></blockquote>`,
      parseMode: "html",
    });
  } catch {}
}

async function checkExpiryNotifs() {
  const dbData = db.loadDB();
  const now = Date.now();
  const H1 = 1 * 24 * 60 * 60 * 1000;
  const H3 = 3 * 24 * 60 * 60 * 1000;

  if (!dbData.notifSent) dbData.notifSent = {};

  for (const [uid, u] of Object.entries(dbData.users || {})) {
    if (u.role === "owner" || u.role === "pemilik" || !u.expiresAt) continue;
    const timeLeft = u.expiresAt - now;
    if (timeLeft <= 0) continue;

    let level = null;
    if (timeLeft <= H1 && timeLeft > 0) level = "H1";
    else if (timeLeft <= H3 && timeLeft > H1) level = "H3";

    if (!level) continue;

    const notifKey = `${uid}_${level}`;
    if (dbData.notifSent[notifKey]) continue;

    const expDate = new Date(u.expiresAt).toLocaleDateString("id-ID", {
      day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta",
    });
    const jamLagi = Math.ceil(timeLeft / 3600000);
    const msg = level === "H1"
      ? `⚠️ <b>Role kamu akan habis dalam ~${jamLagi} jam!</b>\n\nRole <b>${u.role}</b> kamu kedaluwarsa pada <b>${expDate}</b>.\nHubungi reseller/owner untuk perpanjang.`
      : `📅 <b>Pengingat: Role hampir habis</b>\n\nRole <b>${u.role}</b> kamu akan habis dalam <b>3 hari</b> (${expDate}).\nHubungi reseller/owner untuk perpanjang.`;

    try {
      const target = await bot.getInputEntity(parseInt(uid));
      await bot.sendMessage(target, {
        message: `<blockquote><b>${msg}</b></blockquote>`,
        parseMode: "html",
      });
      dbData.notifSent[notifKey] = now;
      console.log(`[Notif] Sent ${level} expiry warning to ${uid}`);
    } catch (e) {
      console.error(`[Notif] Failed to notify ${uid}:`, e.message);
    }
  }

  for (const key of Object.keys(dbData.notifSent)) {
    if (now - dbData.notifSent[key] > 7 * 24 * 60 * 60 * 1000) {
      delete dbData.notifSent[key];
    }
  }

  db.saveDB(dbData);
}

(async () => {
  const INSTANCE_ID = Math.random().toString(36).slice(2, 8);
  console.log("═══════════════════════════════════════");
  console.log(`🤖 INSTANCE ${INSTANCE_ID} | PID ${process.pid}`);
  console.log(`   ${new Date().toISOString()}`);
  console.log(`   ⚠️ Kalau baris "INSTANCE" ini muncul >1x di log = ADA BANYAK PROSES`);
  console.log(`   = itu sumber bug "jawab dobel"! Matikan proses/panel yang lain.`);
  console.log("═══════════════════════════════════════");
  global.__INSTANCE_ID = INSTANCE_ID;

  let __licOk = false;
  try { __licOk = await require("./lib/core").bootLicense(); }
  catch (e) { console.error("[core] boot lisensi gagal:", e.message); __licOk = false; }
  if (!__licOk) {
    console.log("═══════════════════════════════════════");
    console.log("⛔ BOT MANAGER TIDAK DIJALANKAN.");
    console.log("   Lisensi tidak valid / file inti (lib/gate.js, lib/core.js) hilang atau diubah.");
    console.log("   Masukkan Key Akses yang benar, atau kembalikan file aslinya.");
    console.log("═══════════════════════════════════════");
    return;
  }

  console.log("🚀 Memulai Bot Manager...");
  await bot.start({ botAuthToken: BOT_TOKEN });
  const me = await bot.getMe();

  if (me.username) {
    process.env.BOT_USERNAME = "@" + me.username;
    console.log(`✅ Bot Manager aktif: @${me.username} (BOT_USERNAME auto-set)`);
  } else {
    console.log(`⚠️ Bot tidak punya username! Inline .help tidak akan jalan.`);
  }

  if (validMiniAppUrl(MINIAPP_URL)) {
    try {
      await bot.invoke(new Api.bots.SetBotMenuButton({
        userId: new Api.InputUserEmpty(),
        button: new Api.BotMenuButton({ text: "Open", url: MINIAPP_URL }),
      }));
      console.log(`✅ Tombol "Open" (Mini App) di-set: ${MINIAPP_URL}`);
    } catch (e) { console.error("set global menu button:", e.message); }
  } else if (MINIAPP_URL) {
    console.warn(`⚠️ MINIAPP_URL tidak valid untuk menu button: ${MINIAPP_URL}`);
  }

  await db.initStore();
  try { await require("./ubot-plugins/blacklist").initBlacklist(); } catch (e) { console.error("init bl:", e.message); }
  try { await require("./lib/trxStore").initTrx(); } catch (e) { console.error("init trx:", e.message); }
  try { await require("./lib/trxStore").initReceipts(); } catch (e) { console.error("init receipts:", e.message); }
  try { await require("./lib/trxStore").initTesti(); } catch (e) { console.error("init testi:", e.message); }
  try { await require("./lib/noteStore").initNotes(); } catch (e) { console.error("init notes:", e.message); }
  try { await require("./lib/themeStore").initThemes(); } catch (e) { console.error("init themes:", e.message); }
  try { await require("./lib/addonStore").initAddons(); } catch (e) { console.error("init addons:", e.message); }
  try { await customStore.init(); } catch (e) { console.error("init customcfg:", e.message); }
  try { await giveawayStore.init(); } catch (e) { console.error("init giveawaycfg:", e.message); }
  try { await btnColorStore.initBtnColor(); } catch (e) { console.error("init btncolor:", e.message); }
  try { await require("./lib/autoreadStore").initAutoread(); } catch (e) { console.error("init autoread:", e.message); }
  try {
    const sandboxStore = require("./lib/sandbox");
    if (sandboxStore && typeof sandboxStore.initSandbox === "function") await sandboxStore.initSandbox();
  } catch (e) { console.error("init sandbox:", e.message); }
  try { await require("./lib/privacyStore").initPrivacy(); } catch (e) { console.error("init privacy:", e.message); }
  try { await require("./ubot-plugins/chatauto").initChatauto(); } catch (e) { console.error("init chatauto:", e.message); }
  try { await require("./ubot-plugins/keuangan").initKeuangan(); } catch (e) { console.error("init keuangan:", e.message); }
  try { await require("./ubot-plugins/todo").initTodo(); } catch (e) { console.error("init todo:", e.message); }
  try { await require("./ubot-plugins/filter").initFilter(); } catch (e) { console.error("init filter:", e.message); }
  try { await require("./ubot-plugins/reminder").initReminder(); } catch (e) { console.error("init reminder:", e.message); }
  try { await require("./ubot-plugins/alias").initAlias(); } catch (e) { console.error("init alias:", e.message); }
  try { await require("./ubot-plugins/teks").initTeks(); } catch (e) { console.error("init teks:", e.message); }
  try { await require("./ubot-plugins/bookmark").initBookmark(); } catch (e) { console.error("init bookmark:", e.message); }
  try { await require("./ubot-plugins/hitung").initHitung(); } catch (e) { console.error("init hitung:", e.message); }
  try { await require("./ubot-plugins/gudang").initGudang(); } catch (e) { console.error("init gudang:", e.message); }
  try { await require("./ubot-plugins/ultah").initUltah(); } catch (e) { console.error("init ultah:", e.message); }
  try { await require("./ubot-plugins/habit").initHabit(); } catch (e) { console.error("init habit:", e.message); }
  try { await require("./ubot-plugins/stopwatch").initStopwatch(); } catch (e) { console.error("init stopwatch:", e.message); }
  try { await require("./ubot-plugins/sehat").initSehat(); } catch (e) { console.error("init sehat:", e.message); }
  try { await require("./ubot-plugins/sekolah").initSekolah(); } catch (e) { console.error("init sekolah:", e.message); }
  try { await require("./ubot-plugins/acara").initAcara(); } catch (e) { console.error("init acara:", e.message); }
  try { await require("./lib/usnHistory").init(); } catch (e) { console.error("init usn history:", e.message); }
  db.initDB();

  await ubotMgr.autoStartAll();
  console.log(`💡 Owner: ${db.OWNER_IDS.join(", ")}`);

  setTimeout(() => {
    checkExpiryNotifs();
    setInterval(checkExpiryNotifs, 6 * 60 * 60 * 1000);
  }, 60 * 1000);
  console.log(`⏰ Expiry notif checker aktif (tiap 6 jam)`);

  try {
    const mongo = require("./lib/store");
    if (mongo.isReady()) {
      const ID = global.__INSTANCE_ID;
      const heartbeat = async () => {
        try {
          const cur = await mongo.getOne("meta", "instance_lock");
          if (cur && cur.id && cur.id !== ID && (Date.now() - (cur.ts || 0)) < 50000) {
            console.log(`\n🔴🔴🔴 PERINGATAN: ADA INSTANCE LAIN AKTIF (id=${cur.id})!`);
            console.log(`   Bot kamu jalan LEBIH DARI 1x → ini penyebab pesan DOBEL.`);
            console.log(`   ➜ MATIKAN salah satu panel/proses, sisakan 1 aja!\n`);
          }
          await mongo.upsert("meta", "instance_lock", { id: ID, ts: Date.now() });
          await db.refreshFromFirebase();
          await require("./ubot-plugins/blacklist").refreshBlacklist();
        } catch {}
      };
      await heartbeat();
      setInterval(heartbeat, 20000);
      console.log(`🔄 Sinkron MongoDB + deteksi instance ganda tiap 20 detik`);
    }
  } catch {}
})();
