const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const config = require("../config");

function fromSession(entry) {
    return new TelegramClient(
        new StringSession(entry.session),
        entry.apiId || config.API_ID,
        entry.apiHash || config.API_HASH,
        { connectionRetries: 3, useWSS: false }
    );
}
function createEmpty() {
    return new TelegramClient(
        new StringSession(""),
        config.API_ID, config.API_HASH,
        { connectionRetries: 3, useWSS: false }
    );
}
module.exports = { fromSession, createEmpty };