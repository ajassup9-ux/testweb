const logger = require("../utils/logger");
const { isValidUsername } = require("../utils/validator");

async function resolveTarget(client, usernameRaw) {
    const username = usernameRaw.replace(/^@/, "").trim();
    if (!isValidUsername(username)) throw new Error("Username tidak valid.");
    try {
        logger.info(`Resolving @${username}...`);
        const entity = await client.getInputEntity(username);
        logger.success(`Resolved: @${username}`);
        return entity;
    } catch (e) {
        logger.error(`Gagal resolve @${username}: ${e.message}`);
        throw new Error("Username tidak ditemukan.");
    }
}
module.exports = { resolveTarget };