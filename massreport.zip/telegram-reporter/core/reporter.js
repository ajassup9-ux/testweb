const { Api } = require("telegram");
const config = require("../config");
const logger = require("../utils/logger");
const { sleep } = require("../utils/delay");
const { jitter } = require("../utils/random");
const { retryWithBackoff } = require("../utils/backoff");
const { pickReason } = require("../constants/reasons");
const { logReport } = require("../utils/statsTracker");
const { variate } = require("../utils/textVariator");
const RateLimiter = require("../utils/rateLimiter");

const limiter = new RateLimiter(config.DELAY_BETWEEN_REPORTS);

async function sendOnce(client, targetEntity, reasonObj, message) {
    await retryWithBackoff(async () => {
        await client.invoke(new Api.messages.Report({
            peer: targetEntity, reason: reasonObj, message: message
        }));
    }, { label: "report", maxRetries: 2 });
}

async function reportFromAccount(client, phone, targetEntity, reasonText, message) {
    const { obj, name } = pickReason(reasonText);
    let ok = 0;
    for (let i = 1; i <= config.MAX_REPORTS_PER_ACCOUNT; i++) {
        try {
            await limiter.acquire(phone);
            const variedMsg = variate(message);
            await sendOnce(client, targetEntity, obj, variedMsg);
            ok++;
            logger.success(`[${phone}] Report ${i}/${config.MAX_REPORTS_PER_ACCOUNT} OK (${name})`);
            logReport(phone, "target", name, "OK");
        } catch (e) {
            if (e.message.includes("FLOOD_WAIT")) {
                logger.error(`[${phone}] FLOOD_WAIT, stop.`);
                logReport(phone, "target", name, "FLOOD_WAIT");
                break;
            }
            logger.warn(`[${phone}] Report ${i} gagal: ${e.message}`);
            logReport(phone, "target", name, "FAIL: " + e.message);
        }
        if (i < config.MAX_REPORTS_PER_ACCOUNT) await sleep(jitter(2000, 0.3));
    }
    return ok;
}
module.exports = { reportFromAccount };