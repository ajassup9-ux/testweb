const logger = require("../utils/logger");
const { fromSession } = require("./clientFactory");
const { getSessions } = require("../storage/store");

const pool = new Map();

async function add(entry) {
    if (pool.has(entry.phone)) return pool.get(entry.phone);
    try {
        const client = fromSession(entry);
        await client.connect();
        pool.set(entry.phone, client);
        logger.success(`[POOL] Connected: ${entry.phone}`);
        return client;
    } catch (e) {
        logger.error(`[POOL] Failed ${entry.phone}: ${e.message}`);
        return null;
    }
}
async function loadFromDisk() {
    const sessions = getSessions();
    if (!sessions.length) { logger.warn("Belum ada sesi tersimpan."); return; }
    logger.info(`Memuat ${sessions.length} akun...`);
    for (const s of sessions) await add(s);
    logger.success(`Pool aktif: ${pool.size} akun.`);
}
function getPrimary() {
    const first = pool.values().next().value;
    if (!first) throw new Error("Pool kosong.");
    return first;
}
function getAll() { return Array.from(pool.entries()); }
function size() { return pool.size; }
module.exports = { add, loadFromDisk, getPrimary, getAll, size };