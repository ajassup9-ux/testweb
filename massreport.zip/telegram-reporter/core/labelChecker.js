const { Api } = require("telegram");
const logger = require("../utils/logger");
const { getPrimary } = require("./clientPool");

async function checkLabel(username) {
    const client = getPrimary();
    const clean = username.replace(/^@/, "").trim();
    try {
        const entity = await client.getInputEntity(clean);
        const result = await client.invoke(new Api.users.GetFullUser({ id: entity }));
        const user = result.users && result.users[0];
        if (!user) throw new Error("User tidak ditemukan.");
        return {
            scam: !!user.scam, fake: !!user.fake, restricted: !!user.restricted,
            verified: !!user.verified, premium: !!user.premium,
            id: user.id ? user.id.toString() : null,
            username: user.username || clean,
            firstName: user.firstName || "", lastName: user.lastName || ""
        };
    } catch (e) {
        logger.error(`[LABEL] Gagal cek @${clean}: ${e.message}`);
        throw e;
    }
}
function formatLabel(s) {
    const badges = [];
    if (s.scam) badges.push("🚨 *SCAM* (label resmi Telegram)");
    if (s.fake) badges.push("🎭 *FAKE* (akun palsu)");
    if (s.restricted) badges.push("⛔ *RESTRICTED* (dibatasi)");
    if (s.verified) badges.push("✅ *VERIFIED*");
    if (s.premium) badges.push("💎 *PREMIUM*");
    if (!badges.length) badges.push("🟢 *NORMAL* (belum ada label)");
    return [
        "🔍 *STATUS LABEL TELEGRAM*", "",
        `Target: @${s.username}`, `ID: \`${s.id}\``,
        `Nama: ${s.firstName} ${s.lastName}`.trim(), "",
        "Label:", ...badges.map(b => `  ${b}`), "",
        s.scam || s.fake ? "✅ Target sudah dilabeli Telegram." : "⏳ Belum ada label."
    ].join("\n");
}
module.exports = { checkLabel, formatLabel };