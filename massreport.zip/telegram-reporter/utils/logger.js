const config = require("../config");
const L = { debug: 10, info: 20, warn: 30, error: 40 };
const MIN = L[config.LOG_LEVEL] || L.info;
const ts = () => new Date().toISOString().replace("T", " ").substring(0, 19);
const C = { r: "\x1b[0m", red: "\x1b[31m", grn: "\x1b[32m", ylw: "\x1b[33m", cyn: "\x1b[36m", mag: "\x1b[35m" };
function out(lvl, color, tag, msg) {
    if (L[lvl] < MIN) return;
    const line = `${color}[${ts()}] [${tag}]${C.r} - ${msg}`;
    if (lvl === "error" || lvl === "warn") console.error(line); else console.log(line);
}
module.exports = {
    debug:   (m) => out("debug", C.mag, "DEBUG", m),
    info:    (m) => out("info", C.cyn, "INFO", m),
    warn:    (m) => out("warn", C.ylw, "WARN", m),
    error:   (m) => out("error", C.red, "ERROR", m),
    success: (m) => out("info", C.grn, "OK", m)
};