const fs = require("fs");
const path = require("path");
const logger = require("./logger");

const LOG_FILE = path.resolve("./storage/report-history.log");

function logReport(phone, target, reason, status) {
    const line = `[${new Date().toISOString()}] ${phone} → @${target} | ${reason} | ${status}\n`;
    try { fs.appendFileSync(LOG_FILE, line); }
    catch (e) { logger.error(`Log gagal: ${e.message}`); }
}
function getHistory(limit = 20) {
    try {
        if (!fs.existsSync(LOG_FILE)) return [];
        const lines = fs.readFileSync(LOG_FILE, "utf-8").trim().split("\n");
        return lines.slice(-limit);
    } catch (e) { return []; }
}
module.exports = { logReport, getHistory };