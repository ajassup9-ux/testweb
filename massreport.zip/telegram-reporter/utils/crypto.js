const crypto = require("crypto");
const ALGO = "aes-256-cbc";
const SECRET = process.env.CRYPTO_SECRET || "default-secret-change-me";

function encrypt(text) {
    const iv = crypto.randomBytes(16);
    const key = crypto.scryptSync(SECRET, "salt", 32);
    const c = crypto.createCipheriv(ALGO, key, iv);
    let enc = c.update(text, "utf8", "hex");
    enc += c.final("hex");
    return `${iv.toString("hex")}:${enc}`;
}
function decrypt(payload) {
    try {
        const [ivHex, enc] = payload.split(":");
        const key = crypto.scryptSync(SECRET, "salt", 32);
        const d = crypto.createDecipheriv(ALGO, key, Buffer.from(ivHex, "hex"));
        let dec = d.update(enc, "hex", "utf8");
        dec += d.final("utf8");
        return dec;
    } catch (e) { return null; }
}
module.exports = { encrypt, decrypt };