const { sleep } = require("./delay");
const logger = require("./logger");

async function retryWithBackoff(fn, opts = {}) {
    const maxRetries = opts.maxRetries ?? 3;
    const baseDelay = opts.baseDelay ?? 2000;
    const label = opts.label ?? "task";
    let lastErr;
    for (let i = 0; i <= maxRetries; i++) {
        try { return await fn(); }
        catch (e) {
            lastErr = e;
            if (e.message && e.message.includes("FLOOD_WAIT")) {
                const m = e.message.match(/FLOOD_WAIT_(\d+)/);
                const waitSec = m ? parseInt(m[1], 10) : 60;
                logger.warn(`[${label}] FloodWait ${waitSec}s, tunggu...`);
                await sleep(waitSec * 1000);
            } else if (i < maxRetries) {
                const wait = baseDelay * Math.pow(2, i);
                logger.warn(`[${label}] Gagal attempt ${i + 1}, retry ${wait}ms`);
                await sleep(wait);
            } else { throw e; }
        }
    }
    throw lastErr;
}
module.exports = { retryWithBackoff };