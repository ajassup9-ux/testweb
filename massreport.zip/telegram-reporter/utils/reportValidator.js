const { isValidUsername } = require("./validator");
const { size } = require("../core/clientPool");

function validateReportRequest(reason, message, target) {
    const errors = [];
    if (!reason || reason.trim().length < 3) errors.push("Alasan terlalu pendek");
    if (!message || message.trim().length < 5) errors.push("Keterangan minimal 5 karakter");
    if (!isValidUsername(target)) errors.push("Username target tidak valid");
    if (size() === 0) errors.push("Tidak ada akun di pool");
    return { valid: errors.length === 0, errors };
}
module.exports = { validateReportRequest };