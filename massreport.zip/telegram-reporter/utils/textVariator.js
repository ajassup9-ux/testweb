const { pickRandom } = require("./random");

const PREFIXES = [
    "Laporan:", "Mohon ditindak,", "Saya melaporkan,", "Tolong review,",
    "Melaporkan akun ini karena", "Akun ini patut ditinjau:",
    "Saya menemukan pelanggaran:", "Mohon perhatiannya,",
    "Ini sangat mengganggu,", "Saya korban dari:"
];
const SUFFIXES = [
    "Mohon segera ditindak.", "Terima kasih.", "Semoga ditindaklanjuti.",
    "Sudah banyak korban.", "Mohon dicek.",
    "Ini merugikan banyak orang.", "Tolong ditinjau.",
    "Harap ditindak tegas.", "Saya berharap ada tindakan.",
    "Ini pelanggaran serius."
];

function variate(baseMessage) {
    const prefix = pickRandom(PREFIXES);
    const suffix = pickRandom(SUFFIXES);
    const base = (baseMessage || "").trim().replace(/\.$/, "");
    return `${prefix} ${base}. ${suffix}`;
}
function variateMany(baseMessage, count = 5) {
    const out = new Set();
    let tries = 0;
    while (out.size < count && tries < count * 10) { out.add(variate(baseMessage)); tries++; }
    return Array.from(out);
}
module.exports = { variate, variateMany };