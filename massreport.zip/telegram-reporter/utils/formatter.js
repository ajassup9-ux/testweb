function accountList(sessions) {
    if (!sessions.length) return "_Belum ada akun._";
    return sessions.map((s, i) => `${i + 1}. ${s.phone}`).join("\n");
}
function progressBar(done, total) {
    const pct = Math.round((done / total) * 100);
    const filled = Math.round((done / total) * 15);
    return `[${"█".repeat(filled)}${"░".repeat(15 - filled)}] ${pct}%`;
}
module.exports = { accountList, progressBar };