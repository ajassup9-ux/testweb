function isValidSession(entry) {
    if (!entry) return false;
    if (!entry.phone) return false;
    if (!entry.session || entry.session.length < 20) return false;
    if (!entry.apiId || !entry.apiHash) return false;
    return true;
}
function filterValidSessions(sessions) { return sessions.filter(isValidSession); }
module.exports = { isValidSession, filterValidSessions };