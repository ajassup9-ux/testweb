const fs = require("fs");
const path = require("path");
const config = require("../config");
const logger = require("./logger");

function checkAll() {
    const issues = [];
    if (!config.API_ID || config.API_ID === 123456) issues.push("API_ID belum diisi");
    if (!config.API_HASH || config.API_HASH.includes("MASUKKAN")) issues.push("API_HASH belum diisi");
    if (config.MAX_REPORTS_PER_ACCOUNT < 1 || config.MAX_REPORTS_PER_ACCOUNT > 10) issues.push("MAX_REPORTS harus 1-10");
    if (config.DELAY_BETWEEN_REPORTS < 15000) issues.push("DELAY_BETWEEN_REPORTS terlalu kecil");
    if (!config.COMMAND_PREFIX) issues.push("COMMAND_PREFIX kosong");

    const storageDir = path.resolve("./storage");
    if (!fs.existsSync(storageDir)) {
        fs.mkdirSync(storageDir, { recursive: true });
        logger.info("[CHECK] Folder storage dibuat.");
    }
    if (issues.length) {
        logger.warn("[CHECK] Masalah:");
        issues.forEach(i => logger.warn(`  - ${i}`));
        return false;
    }
    logger.success("[CHECK] Konfigurasi OK.");
    return true;
}
module.exports = { checkAll };