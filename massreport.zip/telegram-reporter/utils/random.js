function pickRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function jitter(baseMs, percent = 0.2) {
    const d = baseMs * percent;
    return Math.floor(Math.random() * (d * 2 + 1)) + (baseMs - d);
}
module.exports = { pickRandom, jitter };