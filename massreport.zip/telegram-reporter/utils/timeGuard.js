const logger = require("./logger");
function isReasonableHour() {
    const h = new Date().getHours();
    if (h >= 1 && h <= 5) { logger.warn(`[TIME] Jam ${h}:00 tidak wajar.`); return false; }
    return true;
}
module.exports = { isReasonableHour };