const { sleep } = require("./delay");

class RateLimiter {
    constructor(minIntervalMs) {
        this.minInterval = minIntervalMs;
        this.lastCall = new Map();
    }
    async acquire(key) {
        const now = Date.now();
        const last = this.lastCall.get(key) || 0;
        const wait = this.minInterval - (now - last);
        if (wait > 0) await sleep(wait);
        this.lastCall.set(key, Date.now());
    }
    reset(key) { this.lastCall.delete(key); }
    resetAll() { this.lastCall.clear(); }
}
module.exports = RateLimiter;