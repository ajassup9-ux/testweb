const config = require("../config");
const logger = require("./logger");

function validateConfig() {
    if (!config.API_ID || config.API_ID === 123456) { logger.error("API_ID belum diisi"); return false; }
    if (!config.API_HASH || config.API_HASH.includes("MASUKKAN")) { logger.error("API_HASH belum diisi"); return false; }
    logger.success("Konfigurasi valid.");
    return true;
}
function isValidPhone(p) { return p ? /^\+?\d{8,15}$/.test(p.replace(/\s|-/g, "")) : false; }
function isValidUsername(u) { return u ? /^[a-zA-Z0-9_]{4,32}$/.test(u.replace(/^@/, "")) : false; }
module.exports = { validateConfig, isValidPhone, isValidUsername };