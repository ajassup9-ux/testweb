const logger = require("./logger");

async function isClientAlive(client, phone) {
    try { await client.getMe(); return true; }
    catch (e) { logger.warn(`[HEALTH] ${phone} tidak responsif: ${e.message}`); return false; }
}
async function filterAliveClients(clients) {
    const alive = [];
    for (const [phone, client] of clients) {
        if (await isClientAlive(client, phone)) alive.push([phone, client]);
        else logger.warn(`[HEALTH] Skip ${phone} (mati)`);
    }
    return alive;
}
module.exports = { isClientAlive, filterAliveClients };