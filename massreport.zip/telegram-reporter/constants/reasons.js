const { Api } = require("telegram");

const REASONS = Object.freeze({
    "child abuse":    new Api.InputReportReasonChildAbuse(),
    "violence":       new Api.InputReportReasonViolence(),
    "scam or fraud":  new Api.InputReportReasonScam(),
    "scam":           new Api.InputReportReasonScam(),
    "fraud":          new Api.InputReportReasonScam(),
    "spam":           new Api.InputReportReasonSpam(),
    "personal data":  new Api.InputReportReasonPersonalDetails(),
    "copyright":      new Api.InputReportReasonCopyright(),
    "illegal":        new Api.InputReportReasonIllegalDrugs(),
    "porn":           new Api.InputReportReasonPornography(),
    "other":          new Api.InputReportReasonOther()
});

const VALID = Object.freeze(Object.keys(REASONS));

function pickReason(text) {
    const n = (text || "").toLowerCase().trim();
    if (REASONS[n]) return { obj: REASONS[n], name: n };
    for (const [k, v] of Object.entries(REASONS)) {
        if (n.includes(k) || k.includes(n)) return { obj: v, name: k };
    }
    return { obj: REASONS["spam"], name: "spam" };
}
function isValid(text) {
    const n = (text || "").toLowerCase().trim();
    return VALID.some(k => n.includes(k) || k.includes(n));
}
module.exports = { REASONS, VALID, pickReason, isValid };