const P = require("../config").COMMAND_PREFIX;
module.exports = Object.freeze({
    REPORT:        `${P}report`,
    ADD_SENDER:    `${P}addsender`,
    LIST_SENDER:   `${P}listsender`,
    REMOVE_SENDER: `${P}removesender`,
    CHECK_LABEL:   `${P}checklabel`,
    HISTORY:       `${P}history`,
    STATS:         `${P}stats`,
    HELP:          `${P}help`,
    FAQ:           `${P}faq`,
    USAGE:         `${P}cara`,
    CANCEL:        `${P}cancel`
});