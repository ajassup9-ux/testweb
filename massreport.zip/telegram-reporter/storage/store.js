const fs = require("fs");
const path = require("path");
const config = require("../config");
const logger = require("../utils/logger");
const { filterValidSessions } = require("../utils/sessionValidator");
const { encrypt, decrypt } = require("../utils/crypto");

const ENCRYPT = process.env.ENCRYPT_SESSION === "true";

function ensureFile(fp, def = "[]") {
    const abs = path.resolve(fp);
    if (!fs.existsSync(abs)) fs.writeFileSync(abs, def);
    return abs;
}
function read(fp, fallback) {
    try {
        const abs = ensureFile(fp);
        return JSON.parse(fs.readFileSync(abs, "utf-8") || "null") || fallback;
    } catch (e) { logger.error(`read error: ${e.message}`); return fallback; }
}
function write(fp, data) { fs.writeFileSync(path.resolve(fp), JSON.stringify(data, null, 2)); }
function getSessions() {
    const list = read(config.SESSIONS_FILE, []);
    return filterValidSessions(list).map(s => {
        if (ENCRYPT && s.session && s.session.includes(":")) {
            const dec = decrypt(s.session);
            if (dec) s.session = dec;
        }
        return s;
    });
}
function saveSessions(s) { write(config.SESSIONS_FILE, s); }
function addSession(entry) {
    const list = read(config.SESSIONS_FILE, []);
    const stored = ENCRYPT ? { ...entry, session: encrypt(entry.session) } : entry;
    const i = list.findIndex(x => x.phone === entry.phone);
    if (i >= 0) list[i] = stored; else list.push(stored);
    saveSessions(list);
    return list.length;
}
function removeSession(phone) {
    const list = read(config.SESSIONS_FILE, []);
    const f = list.filter(x => x.phone !== phone);
    if (f.length === list.length) return -1;
    saveSessions(f);
    return f.length;
}
module.exports = { getSessions, saveSessions, addSession, removeSession };