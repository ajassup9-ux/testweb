const { CallbackQuery } = require("telegram/events");
const logger = require("../utils/logger");
const { buildStatsMessage } = require("../services/statsService");

function initializeCallbackRouter(client) {
    logger.info("Callback router aktif.");
    client.addEventHandler(async (event) => {
        const q = event.query;
        if (!q || !q.data) return;
        const action = q.data.toString();
        logger.debug(`[CALLBACK] ${action}`);

        try {
            if (action === "menu") {
                await q.answer({ message: "Membuka menu..." });
                await client.sendMessage(q.peer, {
                    message: "⚙️ *MAIN MENU*\n\nKetik /help untuk daftar perintah.",
                    parseMode: "markdown"
                });
            } else if (action === "stats") {
                await q.answer({ message: "Membuka statistik..." });
                await client.sendMessage(q.peer, { message: buildStatsMessage(), parseMode: "markdown" });
            } else if (action === "dev") {
                await q.answer({ message: "Ketik /help" });
            } else if (action === "buy") {
                await q.answer({ message: "Ketik /help" });
            } else {
                await q.answer({ message: "Aksi tidak dikenal." });
            }
        } catch (e) {
            logger.error(`Callback error: ${e.message}`);
        }
    }, new CallbackQuery({}));
}
module.exports = { initializeCallbackRouter };