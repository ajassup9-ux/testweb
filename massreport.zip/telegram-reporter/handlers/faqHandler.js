async function handleFaq(client, message) {
    const faq = [
        "❓ *FREQUENTLY ASKED QUESTIONS*", "",
        "🔹 *1. Apakah report dijamin banned target?*",
        "   ❌ Tidak. Telegram yang memutuskan, bukan bot.", "",
        "🔹 *2. Berapa lama sampai label SCAM muncul?*",
        "   ⏳ Tidak pasti. Bisa 1 hari, 1 minggu, atau tidak sama sekali.", "",
        "🔹 *3. Akun saya bisa kena banned?*",
        "   ⚠️ Ya. Brigading = pelanggaran ToS.", "",
        "🔹 *4. Kenapa report hanya 10x per akun?*",
        "   📌 Telegram hanya hitung 1 laporan unik per akun per target.", "",
        "🔹 *5. Berapa akun minimal untuk efektif?*",
        "   👥 Minimal 10-20 akun dengan IP berbeda.", "",
        "🔹 *6. Perlu proxy?*",
        "   ✅ Sangat disarankan. IP sama = auto-ignored.", "",
        "🔹 *7. Bagaimana cara cek label?*",
        "   🔍 Ketik `/checklabel <username>`", "",
        "📖 _Baca README.md untuk penjelasan lengkap._"
    ].join("\n");
    return client.sendMessage(message.peerId, { message: faq, parseMode: "markdown" });
}
module.exports = { handleFaq };