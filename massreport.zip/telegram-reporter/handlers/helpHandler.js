const { buildHistoryMessage } = require("../services/historyService");

async function handleHelp(client, message) {
    const help = [
        "📖 *DAFTAR PERINTAH*", "",
        "`/report`                - Mulai report interaktif",
        "`/addsender <nomor>`     - Tambah akun sender",
        "`/listsender`            - Lihat semua akun",
        "`/removesender <nomor>`  - Hapus akun",
        "`/checklabel <username>` - Cek label scam/fake target",
        "`/history`               - Lihat riwayat report",
        "`/stats`                 - Statistik report",
        "`/cara`                  - Panduan cara pakai bot",
        "`/faq`                   - Pertanyaan yang sering ditanya",
        "`/cancel`                - Batal sesi", "",
        "_Semua perintah hanya berfungsi di Saved Messages._"
    ].join("\n");
    return client.sendMessage(message.peerId, { message: help, parseMode: "markdown" });
}

async function handleHistory(client, message) {
    const text = buildHistoryMessage(20);
    return client.sendMessage(message.peerId, { message: text, parseMode: "markdown" });
}
module.exports = { handleHelp, handleHistory };