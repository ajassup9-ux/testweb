const STEPS = require("../constants/steps");
const C = require("../constants/commands");
const { isValid } = require("../constants/reasons");
const { isValidUsername } = require("../utils/validator");
const { progressBar } = require("../utils/formatter");
const stateStore = require("../middleware/stateStore");
const { runReport } = require("../services/reportService");
const { size } = require("../core/clientPool");
const logger = require("../utils/logger");

async function handleReport(client, message, senderId, text) {
    const state = stateStore.get(senderId);

    if (state.step === STEPS.IDLE) {
        if (text.toLowerCase() !== C.REPORT) return;
        if (size() === 0) return client.sendMessage(message.peerId, {
            message: "⚠️ Belum ada akun. Tambahkan via `/addsender <nomor>`", parseMode: "markdown"
        });
        stateStore.set(senderId, { step: STEPS.WAITING_REASON });
        return client.sendMessage(message.peerId, {
            message: `🛡️ *MULAI REPORT*\nAkun aktif: ${size()}\n\nPilih metode:\n- Child abuse\n- Violence\n- Scam or fraud\n- Spam\n- Personal data\n- Copyright\n- Other`,
            parseMode: "markdown"
        });
    }

    if (state.step === STEPS.WAITING_REASON) {
        if (!isValid(text)) return client.sendMessage(message.peerId, { message: "⚠️ Metode tidak valid." });
        stateStore.set(senderId, { step: STEPS.WAITING_MESSAGE, reason: text });
        return client.sendMessage(message.peerId, {
            message: `✅ Metode: *${text}*\n\nMasukkan *Teks Keterangan*:`, parseMode: "markdown"
        });
    }

    if (state.step === STEPS.WAITING_MESSAGE) {
        if (text.trim().length < 5) return client.sendMessage(message.peerId, { message: "⚠️ Teks minimal 5 karakter." });
        stateStore.set(senderId, { step: STEPS.WAITING_TARGET, reason: state.reason, message: text.trim() });
        return client.sendMessage(message.peerId, {
            message: "✅ Tersimpan.\n\nMasukkan *Username Target* (tanpa @):", parseMode: "markdown"
        });
    }

    if (state.step === STEPS.WAITING_TARGET) {
        const target = text.replace(/^@/, "").trim();
        if (!isValidUsername(target)) return client.sendMessage(message.peerId, { message: "⚠️ Username tidak valid." });

        stateStore.clear(senderId);
        await client.sendMessage(message.peerId, {
            message: `⏳ *MEMPROSES LAPORAN*\n\nTarget: @${target}\nAlasan: ${state.reason}\nAkun: ${size()}`,
            parseMode: "markdown"
        });

        try {
            const res = await runReport(state.reason, state.message, target, async (p) => {
                try {
                    await client.sendMessage(message.peerId, {
                        message: `📊 ${progressBar(p.done, p.total)}\nAkun: ${p.phone}\nTerkirim: ${p.sent}`
                    });
                } catch (_) {}
            });

            if (res.success) {
                await client.sendMessage(message.peerId, {
                    message: `✅ *SELESAI!*\nTarget: @${target}\nAkun: ${res.accounts}\nTerkirim: ${res.totalSent}\n\n_Ketik_ \`/checklabel ${target}\` _untuk cek label._`,
                    parseMode: "markdown"
                });
            } else {
                await client.sendMessage(message.peerId, { message: `❌ ${res.error}` });
            }
        } catch (e) {
            logger.error(`Report error: ${e.message}`);
            await client.sendMessage(message.peerId, { message: `❌ ${e.message}` });
        }
    }
}
module.exports = { handleReport };