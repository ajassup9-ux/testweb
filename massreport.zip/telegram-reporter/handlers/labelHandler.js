const { checkLabel, formatLabel } = require("../core/labelChecker");

async function handleCheckLabel(client, message, args) {
    const username = (args || "").trim();
    if (!username) return client.sendMessage(message.peerId, { message: "⚠️ Format: `/checklabel username`", parseMode: "markdown" });
    try {
        const status = await checkLabel(username);
        return client.sendMessage(message.peerId, { message: formatLabel(status), parseMode: "markdown" });
    } catch (e) {
        return client.sendMessage(message.peerId, { message: `❌ Gagal cek: ${e.message}` });
    }
}
module.exports = { handleCheckLabel };