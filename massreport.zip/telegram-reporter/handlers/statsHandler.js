const { buildMessage } = require("../services/statsService");

async function handleStats(client, message) {
    return client.sendMessage(message.peerId, { message: buildMessage(), parseMode: "markdown" });
}
module.exports = { handleStats };