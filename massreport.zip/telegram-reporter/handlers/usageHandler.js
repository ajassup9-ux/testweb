async function handleUsage(client, message) {
    const usage = [
        "📖 *CARA MENGGUNAKAN BOT*", "",
        "🎯 *SKENARIO 1: Report Akun Penipu*",
        "1️⃣ Ketik: `/report`",
        "2️⃣ Balas metode: `Scam or fraud`",
        "3️⃣ Balas keterangan: _contoh:_ `Bot ini melakukan penipuan`",
        "4️⃣ Balas username target: _contoh:_ `OfficialPolkadotInvesmentBot`",
        "5️⃣ Tunggu proses selesai",
        "6️⃣ Cek label: `/checklabel OfficialPolkadotInvesmentBot`", "",
        "📥 *SKENARIO 2: Tambah Akun Sender*",
        "1️⃣ Ketik: `/addsender +628123456789`",
        "2️⃣ Buka terminal, masukkan OTP",
        "3️⃣ Bot balas: ✅ Akun terdaftar", "",
        "🔍 *SKENARIO 3: Cek Label*",
        "Ketik: `/checklabel <username>`", "",
        "💡 _Semua perintah hanya di Saved Messages._"
    ].join("\n");
    return client.sendMessage(message.peerId, { message: usage, parseMode: "markdown" });
}
module.exports = { handleUsage };