module.exports = {
    ...require("./reportHandler"),
    ...require("./senderHandler"),
    ...require("./labelHandler"),
    ...require("./helpHandler"),
    ...require("./faqHandler"),
    ...require("./usageHandler"),
    ...require("./cancelHandler"),
    ...require("./statsHandler")
};