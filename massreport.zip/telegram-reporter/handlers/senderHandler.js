const { registerNewSender } = require("../services/senderService");
const { getSessions, removeSession } = require("../storage/store");
const { accountList } = require("../utils/formatter");

async function handleAddSender(client, message, args) {
    const phone = (args || "").trim();
    if (!phone) return client.sendMessage(message.peerId, { message: "⚠️ Format: `/addsender +628123456789`", parseMode: "markdown" });
    await client.sendMessage(message.peerId, { message: `📲 Memproses login *${phone}*...\nCek terminal untuk OTP.`, parseMode: "markdown" });
    const res = await registerNewSender(phone);
    if (!res.success) return client.sendMessage(message.peerId, { message: `❌ Gagal: ${res.error}` });
    return client.sendMessage(message.peerId, { message: `✅ Akun ${res.phone} terdaftar.\nTotal: ${getSessions().length}` });
}

async function handleListSender(client, message) {
    const s = getSessions();
    return client.sendMessage(message.peerId, {
        message: `📋 *DAFTAR AKUN (${s.length})*\n\n${accountList(s)}`, parseMode: "markdown"
    });
}

async function handleRemoveSender(client, message, args) {
    const phone = (args || "").trim();
    if (!phone) return client.sendMessage(message.peerId, { message: "⚠️ Format: `/removesender +628123456789`", parseMode: "markdown" });
    const remaining = removeSession(phone);
    if (remaining < 0) return client.sendMessage(message.peerId, { message: `❌ Akun ${phone} tidak ditemukan.` });
    return client.sendMessage(message.peerId, { message: `✅ Dihapus. Sisa: ${remaining}` });
}
module.exports = { handleAddSender, handleListSender, handleRemoveSender };