const stateStore = require("../middleware/stateStore");

async function handleCancel(client, message, senderId) {
    stateStore.clear(senderId);
    return client.sendMessage(message.peerId, { message: "🛑 Sesi dibatalkan." });
}
module.exports = { handleCancel };