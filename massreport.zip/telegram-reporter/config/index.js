require("dotenv").config();

module.exports = Object.freeze({
    API_ID: parseInt(process.env.API_ID, 10) || 123456,
    API_HASH: process.env.API_HASH || "MASUKKAN_API_HASH_DISINI",
    SESSIONS_FILE: "./storage/sessions.json",
    COMMAND_PREFIX: process.env.COMMAND_PREFIX || "/",
    LOG_LEVEL: process.env.LOG_LEVEL || "info",
    MAX_REPORTS_PER_ACCOUNT: 10,
    DELAY_BETWEEN_REPORTS: 45000,
    DELAY_BETWEEN_ACCOUNTS: 5000
});