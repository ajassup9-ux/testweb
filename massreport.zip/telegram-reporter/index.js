const { validateConfig } = require("./utils/validator");
const { checkAll } = require("./utils/configChecker");
const { loadFromDisk, size, getPrimary } = require("./core/clientPool");
const { initializeRouter } = require("./events/router");
const { registerNewSender } = require("./services/senderService");
const { showStartupUI } = require("./services/uiService");
const proxyService = require("./services/proxyService");
const notificationService = require("./services/notificationService");
const { initializeCallbackRouter } = require("./handlers/menuHandler");
const logger = require("./utils/logger");
const input = require("input");

async function main() {
    logger.info("=== TELEGRAM REPORTER v1.0 ===");
    logger.warn("⚠️  Brigading melanggar ToS Telegram.");

    if (!validateConfig()) process.exit(1);
    checkAll();
    proxyService.load();

    await loadFromDisk();

    if (size() === 0) {
        logger.warn("Pool kosong. Bootstrap akun pertama...");
        const phone = await input.text("Nomor Telegram akun pertama (+62...): ");
        const res = await registerNewSender(phone);
        if (!res.success) { logger.error(`Gagal: ${res.error}`); process.exit(1); }
    }

    const primary = getPrimary();
    initializeRouter(primary);
    initializeCallbackRouter(primary);

    const me = await primary.getMe();
    notificationService.bind(primary, me.id);
    await showStartupUI(primary, me.id);

    logger.success("Sistem siap. Buka Saved Messages di Telegram.");
    logger.info("Perintah: /help, /report, /addsender, /listsender, /removesender, /checklabel, /history, /stats, /cara, /faq, /cancel");
}

process.on("SIGINT", () => { logger.warn("Menutup..."); process.exit(0); });
main().catch((err) => { logger.error(`Fatal: ${err.message}`); process.exit(1); });