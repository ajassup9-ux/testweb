const STEPS = require("../constants/steps");

class StateStore {
    constructor() { this.map = new Map(); }
    get(id) { return this.map.get(id) || { step: STEPS.IDLE }; }
    set(id, s) { this.map.set(id, s); }
    clear(id) { this.map.delete(id); }
}
module.exports = new StateStore();