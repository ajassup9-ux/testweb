const { NewMessage } = require("telegram/events");
const logger = require("../utils/logger");
const C = require("../constants/commands");
const {
    handleReport, handleAddSender, handleListSender, handleRemoveSender,
    handleCheckLabel, handleHistory, handleStats,
    handleHelp, handleFaq, handleUsage, handleCancel
} = require("../handlers");

function initializeRouter(client) {
    logger.info("Router aktif.");
    client.addEventHandler(async (event) => {
        const message = event.message;
        if (!message || !message.text) return;
        if (!message.isPrivate || !message.out) return;

        const senderId = message.senderId ? message.senderId.toString() : "unknown";
        const text = message.text.trim();
        const lower = text.toLowerCase();
        const [cmd] = lower.split(/\s+/);
        const args = text.split(/\s+/).slice(1).join(" ");

        logger.debug(`[MSG] ${text}`);

        if (cmd === C.HELP) return handleHelp(client, message);
        if (cmd === C.FAQ) return handleFaq(client, message);
        if (cmd === C.USAGE) return handleUsage(client, message);
        if (cmd === C.HISTORY) return handleHistory(client, message);
        if (cmd === C.STATS) return handleStats(client, message);
        if (cmd === C.LIST_SENDER) return handleListSender(client, message);
        if (cmd === C.ADD_SENDER) return handleAddSender(client, message, args);
        if (cmd === C.REMOVE_SENDER) return handleRemoveSender(client, message, args);
        if (cmd === C.CHECK_LABEL) return handleCheckLabel(client, message, args);
        if (cmd === C.CANCEL) return handleCancel(client, message, senderId);

        return handleReport(client, message, senderId, text);
    }, new NewMessage({}));
}
module.exports = { initializeRouter };