# Telegram Reporter Bot

Userbot Telegram untuk report akun/bot pelanggar ToS.

## Setup
1. Isi API_ID & API_HASH di .env (my.telegram.org)
2. npm install
3. npm start
4. Masukkan nomor HP pertama & OTP
5. Buka Saved Messages, ketik /help

## Perintah
/report, /addsender, /listsender, /removesender, /checklabel, /history, /stats, /cara, /faq, /cancel

## Peringatan
Brigading melanggar ToS Telegram.