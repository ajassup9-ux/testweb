const logger = require("../utils/logger");

class NotificationService {
    constructor() { this.client = null; this.peerId = null; }

    bind(client, peerId) {
        this.client = client;
        this.peerId = peerId;
        logger.info("[NOTIF] Service terikat ke peer.");
    }

    async send(text, parseMode = "markdown") {
        if (!this.client || !this.peerId) return;
        try {
            await this.client.sendMessage(this.peerId, { message: text, parseMode });
        } catch (e) {
            logger.warn(`[NOTIF] Gagal kirim: ${e.message}`);
        }
    }

    async reportStart(target, accounts) {
        await this.send(`🚀 *Laporan dimulai*\nTarget: @${target}\nAkun: ${accounts}`);
    }
    async reportProgress(done, total, phone, sent) {
        await this.send(`📊 Progress: ${done}/${total}\nAkun: ${phone}\nTerkirim: ${sent}`);
    }
    async reportDone(target, total) {
        await this.send(`✅ *Selesai!*\nTarget: @${target}\nTotal terkirim: ${total}`);
    }
}
module.exports = new NotificationService();