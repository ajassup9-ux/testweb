const fs = require("fs");
const path = require("path");
const logger = require("../utils/logger");

const LOG_FILE = path.resolve("./storage/report-history.log");

function load() {
    try {
        if (!fs.existsSync(LOG_FILE)) return [];
        return fs.readFileSync(LOG_FILE, "utf-8").trim().split("\n").filter(Boolean);
    } catch (e) {
        logger.error(`Stats load error: ${e.message}`);
        return [];
    }
}
function compute() {
    const lines = load();
    const today = new Date().toISOString().substring(0, 10);
    const stats = { total: lines.length, today: 0, ok: 0, fail: 0, flood: 0 };
    for (const l of lines) {
        if (l.startsWith(`[${today}`)) stats.today++;
        if (l.includes("| OK")) stats.ok++;
        if (l.includes("| FAIL")) stats.fail++;
        if (l.includes("FLOOD_WAIT")) stats.flood++;
    }
    return stats;
}
function buildMessage() {
    const s = compute();
    return [
        "📊 *STATISTIK REPORT*", "",
        `📈 Total: *${s.total}*`,
        `📅 Hari ini: *${s.today}*`,
        `✅ Sukses: *${s.ok}*`,
        `❌ Gagal: *${s.fail}*`,
        `⏱️ FloodWait: *${s.flood}*`
    ].join("\n");
}
module.exports = { load, compute, buildMessage };