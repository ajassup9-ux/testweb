const logger = require("../utils/logger");
const jobs = new Map();

function schedule(name, delayMs, fn) {
    const timer = setTimeout(async () => {
        try {
            logger.info(`[SCHED] Menjalankan: ${name}`);
            await fn();
        } catch (e) { logger.error(`[SCHED] ${name} error: ${e.message}`); }
        jobs.delete(name);
    }, delayMs);
    jobs.set(name, { timer, scheduledAt: Date.now() + delayMs });
    logger.info(`[SCHED] ${name} dijadwalkan dalam ${Math.round(delayMs / 1000)}s`);
}
function cancel(name) {
    if (jobs.has(name)) {
        clearTimeout(jobs.get(name).timer);
        jobs.delete(name);
        return true;
    }
    return false;
}
function cancelAll() { for (const [, j] of jobs) clearTimeout(j.timer); jobs.clear(); }
function list() {
    return Array.from(jobs.entries()).map(([n, j]) => ({
        name: n, runIn: Math.max(0, Math.round((j.scheduledAt - Date.now()) / 1000)) + "s"
    }));
}
module.exports = { schedule, cancel, cancelAll, list };