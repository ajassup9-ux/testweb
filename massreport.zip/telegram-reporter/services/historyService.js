const fs = require("fs");
const path = require("path");
const logger = require("../utils/logger");

const LOG_FILE = path.resolve("./storage/report-history.log");

function loadHistory() {
    try {
        if (!fs.existsSync(LOG_FILE)) return [];
        return fs.readFileSync(LOG_FILE, "utf-8").trim().split("\n").filter(Boolean).map(l => l.trim());
    } catch (e) {
        logger.error(`History load error: ${e.message}`);
        return [];
    }
}
function getRecent(limit = 20) { return loadHistory().slice(-limit).reverse(); }
function buildHistoryMessage(limit = 20) {
    const lines = getRecent(limit);
    if (!lines.length) return "📜 *RIWAYAT REPORT*\n\n_Belum ada riwayat._";
    const body = lines.map((l, i) => `${i + 1}. ${l}`).join("\n");
    return `📜 *RIWAYAT REPORT (${lines.length} terakhir)*\n\n${body}`;
}
function countToday() {
    const today = new Date().toISOString().substring(0, 10);
    return loadHistory().filter(l => l.startsWith(`[${today}`)).length;
}
module.exports = { loadHistory, getRecent, buildHistoryMessage, countToday };