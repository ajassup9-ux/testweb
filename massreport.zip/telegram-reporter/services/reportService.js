const logger = require("../utils/logger");
const { sleep } = require("../utils/delay");
const { getPrimary, getAll } = require("../core/clientPool");
const { resolveTarget } = require("../core/resolver");
const { reportFromAccount } = require("../core/reporter");
const { filterAliveClients } = require("../utils/healthCheck");
const { validateReportRequest } = require("../utils/reportValidator");
const { isReasonableHour } = require("../utils/timeGuard");

async function runReport(reasonText, message, targetUsername, onProgress) {
    const v = validateReportRequest(reasonText, message, targetUsername);
    if (!v.valid) return { success: false, error: v.errors.join(", ") };
    if (!isReasonableHour()) logger.warn("Jam tidak wajar, tapi lanjut saja.");

    let accounts = getAll();
    if (!accounts.length) return { success: false, error: "Tidak ada akun di pool." };
    accounts = await filterAliveClients(accounts);
    if (!accounts.length) return { success: false, error: "Semua akun mati." };

    let targetEntity;
    try { targetEntity = await resolveTarget(getPrimary(), targetUsername); }
    catch (e) { return { success: false, error: e.message }; }

    logger.info(`=== REPORT: ${accounts.length} akun → @${targetUsername} ===`);
    let totalSent = 0, done = 0;

    for (const [phone, client] of accounts) {
        try {
            const count = await reportFromAccount(client, phone, targetEntity, reasonText, message);
            totalSent += count;
        } catch (e) { logger.error(`[${phone}] Error: ${e.message}`); }
        done++;
        if (onProgress) { try { await onProgress({ done, total: accounts.length, phone, sent: totalSent }); } catch (_) {} }
        if (done < accounts.length) await sleep(5000 + Math.floor(Math.random() * 5000));
    }
    logger.info(`=== DONE: ${totalSent} terkirim ===`);
    return { success: true, totalSent, accounts: accounts.length };
}
module.exports = { runReport };