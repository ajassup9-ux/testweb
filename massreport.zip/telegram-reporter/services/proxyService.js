const fs = require("fs");
const path = require("path");
const logger = require("../utils/logger");

const PROXY_FILE = path.resolve("./storage/proxies.json");
let proxies = [];

function load() {
    try {
        if (!fs.existsSync(PROXY_FILE)) { fs.writeFileSync(PROXY_FILE, "[]"); proxies = []; return; }
        proxies = JSON.parse(fs.readFileSync(PROXY_FILE, "utf-8") || "[]");
        logger.info(`[PROXY] Loaded ${proxies.length} konfigurasi.`);
    } catch (e) { logger.error(`[PROXY] Load error: ${e.message}`); proxies = []; }
}
function save() { fs.writeFileSync(PROXY_FILE, JSON.stringify(proxies, null, 2)); }
function getFor(phone) { return proxies.find(p => p.phone === phone) || null; }
function set(phone, cfg) {
    const i = proxies.findIndex(p => p.phone === phone);
    if (i >= 0) proxies[i] = { phone, ...cfg }; else proxies.push({ phone, ...cfg });
    save();
    logger.success(`[PROXY] ${phone} → ${cfg.host}:${cfg.port}`);
}
function remove(phone) {
    const before = proxies.length;
    proxies = proxies.filter(p => p.phone !== phone);
    save();
    return before !== proxies.length;
}
function list() { return proxies; }
module.exports = { load, save, getFor, set, remove, list };