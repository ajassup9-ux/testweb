const input = require("input");
const config = require("../config");
const logger = require("../utils/logger");
const { createEmpty } = require("../core/clientFactory");
const { add: addToPool } = require("../core/clientPool");
const { addSession } = require("../storage/store");
const { isValidPhone } = require("../utils/validator");

async function registerNewSender(phoneRaw) {
    const phone = (phoneRaw || "").trim();
    if (!isValidPhone(phone)) return { success: false, error: "Format nomor tidak valid." };
    logger.info(`Registrasi sender: ${phone}`);
    const client = createEmpty();
    try {
        await client.start({
            phoneNumber: async () => phone,
            password: async () => await input.text(`[${phone}] 2FA (Enter jika kosong): `),
            phoneCode: async () => await input.text(`[${phone}] OTP: `),
            onError: (err) => logger.error(`Login error: ${err.message}`)
        });
        const entry = {
            phone, session: client.session.save(),
            apiId: config.API_ID, apiHash: config.API_HASH,
            addedAt: new Date().toISOString()
        };
        addSession(entry);
        await addToPool(entry);
        logger.success(`Sender ${phone} terdaftar.`);
        return { success: true, phone };
    } catch (e) {
        logger.error(`Registrasi ${phone} gagal: ${e.message}`);
        return { success: false, error: e.message };
    }
}
module.exports = { registerNewSender };