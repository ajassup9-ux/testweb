const { Api } = require("telegram");
const logger = require("../utils/logger");
const { sleep } = require("../utils/delay");

const START = Date.now();
function runtime() {
    const s = Math.floor((Date.now() - START) / 1000);
    return `${Math.floor(s / 3600)} Jam ${Math.floor((s % 3600) / 60)} Menit ${s % 60} Detik`;
}
function keyboard() {
    return new Api.ReplyInlineMarkup({
        rows: [
            new Api.KeyboardButtonRow({
                buttons: [new Api.KeyboardButtonCallback({ text: "⚙️ OPEN MAIN MENU", data: Buffer.from("menu") })]
            }),
            new Api.KeyboardButtonRow({
                buttons: [
                    new Api.KeyboardButtonCallback({ text: "👨‍💻 Developer", data: Buffer.from("dev") }),
                    new Api.KeyboardButtonCallback({ text: "🛒 Buy Script", data: Buffer.from("buy") })
                ]
            })
        ]
    });
}
async function showStartupUI(client, peerId) {
    logger.info("Menampilkan UI Startup...");
    const loadingMsg = await client.sendMessage(peerId, {
        message: "🔄 *Memuat sistem...*\n\nMenghubungkan ke server Telegram.",
        parseMode: "markdown"
    });
    await sleep(3000);

    const me = await client.getMe();
    const botId = me.id.toString();
    const botUsername = me.username || "user";

    const uiText = `
<blockquote>👋 <b>Alohaa</b> – @${botUsername}</blockquote>

<b>MASS REPORT j4eDvnnn</b> — Telegram
Bot ini akan membantu Anda dengan cepat, mudah, aman, dan nyaman.

<blockquote>👤 <b>USER INFO</b>
ID : <code>${botId}</code>
Username : @${botUsername}
Tier : CEO PANEL
Akses : SRV1, SRV2, SRV3</blockquote>

<blockquote>🛰️ <b>SYSTEM INFO</b>
Runtime : ${runtime()}
Versi : 1.0
Status : Online</blockquote>

<b>❓ Bantuan? Chat @ampasluhaha</b>
    `.trim();

    try {
        await client.editMessage(peerId, {
            message: loadingMsg.id, text: uiText,
            parseMode: "html", replyMarkup: keyboard()
        });
        logger.success("UI Startup ditampilkan!");
    } catch (e) { logger.error(`UI gagal: ${e.message}`); }
}
module.exports = { showStartupUI };