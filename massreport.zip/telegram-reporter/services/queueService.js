const logger = require("../utils/logger");

class Queue {
    constructor() {
        this.items = [];
        this.running = false;
        this.handler = null;
    }
    setHandler(fn) { this.handler = fn; }
    push(item) {
        this.items.push(item);
        logger.info(`[QUEUE] +1 item (total: ${this.items.length})`);
        this._run();
    }
    async _run() {
        if (this.running) return;
        this.running = true;
        while (this.items.length) {
            const item = this.items.shift();
            try {
                if (this.handler) await this.handler(item);
            } catch (e) {
                logger.error(`[QUEUE] Error: ${e.message}`);
            }
        }
        this.running = false;
    }
    size() { return this.items.length; }
    clear() { this.items = []; }
}
module.exports = new Queue();