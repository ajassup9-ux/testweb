# Telegram Reporter Bot 🤖

Bot Telegram untuk melakukan report otomatis terhadap channel dan account Telegram yang melanggar aturan.

## ⚠️ Disclaimer
**Warning!** Bot ini adalah untuk tujuan testing dan edukasi. Segala penyalahgunaan adalah tanggung jawab pengguna.

## 🚀 Fitur

- **Report Channel**: Melaporkan channel Telegram dengan berbagai kategori
- **Report Account**: Melaporkan akun pengguna Telegram  
- **Report Group**: Melaporkan Group Telegram  
- **Multiple Report Types**: Spam, Violence, Pornography, Copyright, dll.
- **User-Friendly Interface**: Interface bot yang mudah digunakan
- **Batch Reporting**: Kirim multiple reports sekaligus

## 📋 Persyaratan

1. Python 3.7+
2. Token Bot Telegram (dari @BotFather)
3. Telegram API credentials (API ID & API Hash)

## 🛠️ Instalasi

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Dapatkan Bot Token:**
   - Buka @BotFather di Telegram
   - Buat bot baru dengan `/newbot`
   - Salin token yang diberikan

3. **Konfigurasi Bot:**
   - Edit file `telegram_bot.py`
   - Ganti `YOUR_BOT_TOKEN_HERE` dengan token bot Anda

4. **Jalankan Bot:**
   ```bash
   python telegram_bot.py
   ```

## 🎯 Cara Penggunaan

1. Cari bot Anda di Telegram
2. Kirim `/start`
3. Pilih jenis report (Channel/Account)
4. Masukkan API credentials Anda
5. Pilih metode report
6. Masukkan target dan jumlah report

## 📊 Jenis Report

### Channel Report:
* Spam 🔆
* Other 🔆
* Violence 🔆
* Pornography 🔆
* Copyright 🔆
* Fake 🔆
* Geo Irrelevant 🔆
* Illegal Drugs 🔆
* Personal Details 🔆

### Account Report:
* Spam 🔆
* Pornography 🔆
* Violence 🔆
* Child Abuse 🔆
* Other 🔆
* Copyright 🔆
* Fake 🔆
* Geo Irrelevant 🔆
* Illegal Drugs 🔆
* Personal Details 🔆

### Channel Report:
* Spam 🔆
* Other 🔆
* Violence 🔆
* Pornography 🔆
* Copyright 🔆
* Fake 🔆
* Geo Irrelevant 🔆
* Illegal Drugs 🔆
* Personal Details 🔆


## 📁 File Structure

```
├── telegram_bot.py      # Main bot file
├── config.py           # Configuration
├── requirements.txt    # Dependencies
├── main.py            # Original CLI script
└── report/            # Original report modules
```

## 🚨 Keamanan & Tips

- Jangan share API credentials dengan orang lain ❌
- Gunakan dengan bijak - jangan spam report ❌
- Segala tindak kejahatan dengan tool ini adalah tanggung jawab pengguna ❌
- Ini adalah versi trial! ♨️

## 🔧 Support

- Linux ✅
- Windows ✅  
- Termux ✅
- Panel ✅️

Channel: @kinzxxoffcial

---

### Original CLI Version
Untuk menggunakan versi CLI original:
```bash
python telegram_bot.py
``` 
