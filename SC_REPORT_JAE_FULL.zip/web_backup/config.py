# ==================== KONFIGURASI BOT TELEGRAM MASS REPORTER ====================

# -------------------- BOT CONFIGURATION --------------------
# Token bot dari @BotFather
BOT_TOKEN = ""

# Banner URL (gambar yang tampil di atas pesan)
# Bisa pakai link gambar dari telegram atau imgur
BANNER_URL = "https://files.catbox.moe/6neyjr.jpg"

# -------------------- OWNER CONFIGURATION --------------------
# ID Telegram owner (bisa satu atau lebih)
# Cara dapat ID: @userinfobot atau @getidsbot
OWNER_ID = 111  # Ganti dengan ID Telegram Anda

# Untuk multiple owner, gunakan list:
# OWNER_ID = [123456789, 987654321]

# -------------------- PREMIUM CONFIGURATION --------------------
# Kontak untuk beli premium (format: @username)
PREMIUM_CONTACT = "@username"

# Harga premium (bisa diubah sesuai keinginan)
PREMIUM_PRICE = "15.000"

# -------------------- API CONFIGURATION --------------------
# API ID dan Hash default untuk Telegram Client
# Biarkan default (ini sudah valid)
DEFAULT_API_ID = 111
DEFAULT_API_HASH = "api hash lu"

# -------------------- FILE CONFIGURATION --------------------
# File untuk menyimpan session login
SESSIONS_FILE = "sessions.json"

# File untuk menyimpan daftar user premium
PREMIUM_USERS_FILE = "premium_users.json"

# -------------------- OPTIONAL CONFIGURATION --------------------
# Maksimal report per akun (default 50, jangan terlalu besar)
MAX_REPORT_PER_ACCOUNT = 15

# Delay antar report dalam detik (untuk menghindari flood)
REPORT_DELAY = 10.0

# Timeout untuk koneksi (detik)
CONNECTION_TIMEOUT = 59

# ==================== END OF CONFIG ====================