import os
import asyncio
import json
import logging
import re
import zipfile
import time
from datetime import datetime, timedelta
from threading import Thread
from typing import Dict, Set, Optional, Tuple, List, Any
from collections import defaultdict

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telethon import TelegramClient, functions, types
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, FloodWaitError, RPCError
from telethon.tl.types import InputPeerUser, InputPeerChannel, InputPeerChat

import config

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', 
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Banner foto
BANNER_URL = config.BANNER_URL

class TelegramReporterBot:
    def __init__(self, token):
        self.token = token
        # Support multiple sessions per user
        self.user_sessions: Dict[int, List[Dict]] = {}  # List of sessions per user
        self.premium_users = self.load_premium_users()
        self.active_reports: Dict[int, Dict] = {}
        self.load_sessions()
        
        # ==================== CHANNEL/GROUP REPORT ====================
        self.channel_reports = {
            "Spam": {
                'name': '📧 Spam',
                'options': {
                    '1': {'name': 'Insults or false information', 'reason': types.InputReportReasonSpam(), 'default_message': 'This channel contains insults or false information.'},
                    '2': {'name': 'Promoting illegal content', 'reason': types.InputReportReasonSpam(), 'default_message': 'This channel promotes illegal content.'},
                    '3': {'name': 'Promoting other content', 'reason': types.InputReportReasonSpam(), 'default_message': 'This channel promotes other content excessively.'}
                }
            },
            "Violence": {
                'name': '🔪 Violence',
                'options': {
                    '1': {'name': 'Insults or false information', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel contains insults or false information.'},
                    '2': {'name': 'Graphic or disturbing content', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel contains graphic or disturbing content.'},
                    '3': {'name': 'Extreme violence, dismemberment', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel contains extreme violence and dismemberment.'},
                    '4': {'name': 'Hate speech or symbols', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel contains hate speech or symbols.'},
                    '5': {'name': 'Calling for violence', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel is calling for violence.'},
                    '6': {'name': 'Organized crime', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel is related to organized crime.'},
                    '7': {'name': 'Terrorism', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel contains terrorism content.'},
                    '8': {'name': 'Animal abuse', 'reason': types.InputReportReasonViolence(), 'default_message': 'This channel contains animal abuse.'}
                }
            },
            "Child Abuse": {
                'name': '🔞 Child Abuse',
                'options': {
                    '1': {'name': 'Child physical abuse', 'reason': types.InputReportReasonChildAbuse(), 'default_message': 'This channel contains child physical abuse.'},
                    '2': {'name': 'Child sexual abuse', 'reason': types.InputReportReasonChildAbuse(), 'default_message': 'This channel contains child sexual abuse.'}
                }
            },
            "Illegal Adult Content": {
                'name': '🔞 Illegal Adult Content',
                'options': {
                    '1': {'name': 'Child abuse', 'reason': types.InputReportReasonPornography(), 'default_message': 'This channel contains child abuse.'},
                    '2': {'name': 'Illegal sexual services', 'reason': types.InputReportReasonPornography(), 'default_message': 'This channel offers illegal sexual services.'},
                    '3': {'name': 'Animal abuse', 'reason': types.InputReportReasonPornography(), 'default_message': 'This channel contains animal abuse.'},
                    '4': {'name': 'Non-consensual sexual imagery', 'reason': types.InputReportReasonPornography(), 'default_message': 'This channel contains non-consensual sexual imagery.'},
                    '5': {'name': 'Pornography', 'reason': types.InputReportReasonPornography(), 'default_message': 'This channel contains pornography.'},
                    '6': {'name': 'Other illegal sexual content', 'reason': types.InputReportReasonPornography(), 'default_message': 'This channel contains other illegal sexual content.'}
                }
            },
            "Illegal Goods and Services": {
                'name': '🔫 Illegal Goods and Services',
                'options': {
                    '1': {'name': 'Weapons', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells illegal weapons.'},
                    '2': {'name': 'Drugs', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells illegal drugs.'},
                    '3': {'name': 'Fake documents', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells fake documents.'},
                    '4': {'name': 'Counterfeit money', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells counterfeit money.'},
                    '5': {'name': 'Hacking tools and malware', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells hacking tools and malware.'},
                    '6': {'name': 'Counterfeit merchandise', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells counterfeit merchandise.'},
                    '7': {'name': 'Other goods and services', 'reason': types.InputReportReasonIllegalDrugs(), 'default_message': 'This channel sells other illegal goods and services.'}
                }
            },
            "Personal Data": {
                'name': '📱 Personal Data',
                'options': {
                    '1': {'name': 'Private images', 'reason': types.InputReportReasonPersonalDetails(), 'default_message': 'This channel shares private images.'},
                    '2': {'name': 'Phone number', 'reason': types.InputReportReasonPersonalDetails(), 'default_message': 'This channel shares private phone numbers.'},
                    '3': {'name': 'Address', 'reason': types.InputReportReasonPersonalDetails(), 'default_message': 'This channel shares residential addresses.'},
                    '4': {'name': 'Stolen data or credentials', 'reason': types.InputReportReasonPersonalDetails(), 'default_message': 'This channel shares stolen data or credentials.'},
                    '5': {'name': 'Other personal information', 'reason': types.InputReportReasonPersonalDetails(), 'default_message': 'This channel shares other personal information.'}
                }
            },
            "Scam or Fraud": {
                'name': '🎭 Scam or Fraud',
                'options': {
                    '1': {'name': 'Impersonation', 'reason': types.InputReportReasonFake(), 'default_message': 'This channel is impersonating someone.'},
                    '2': {'name': 'Deceptive or unrealistic financial claims', 'reason': types.InputReportReasonFake(), 'default_message': 'This channel makes deceptive financial claims.'},
                    '3': {'name': 'Malware, phishing', 'reason': types.InputReportReasonFake(), 'default_message': 'This channel contains malware or phishing.'},
                    '4': {'name': 'Fraudulent seller, product or service', 'reason': types.InputReportReasonFake(), 'default_message': 'This channel is a fraudulent seller.'}
                }
            },
            "Copyright": {
                'name': '©️ Copyright',
                'options': {
                    '1': {'name': 'Custom Text / Deskripsi Pelanggaran', 'reason': types.InputReportReasonCopyright(), 'default_message': 'This channel violates copyright.', 'always_custom': True}
                }
            },
            "Other": {
                'name': '📌 Other',
                'options': {
                    '1': {'name': "I don't like it", 'reason': types.InputReportReasonOther(), 'default_message': "I don't like this content."},
                    '2': {'name': 'False information or defamation', 'reason': types.InputReportReasonOther(), 'default_message': 'This channel contains false information or defamation.'},
                    '3': {'name': 'Illegal adult content', 'reason': types.InputReportReasonOther(), 'default_message': 'This channel contains illegal adult content.'},
                    '4': {'name': 'Illegal goods and services', 'reason': types.InputReportReasonOther(), 'default_message': 'This channel offers illegal goods and services.'},
                    '5': {'name': 'Something else (Custom Text)', 'reason': types.InputReportReasonOther(), 'default_message': 'This channel violates Telegram Terms.', 'always_custom': True}
                }
            },
            "It's not illegal, but must be taken down": {
                'name': '⚠️ Not Illegal But Must Be Taken Down',
                'options': {
                    '1': {'name': 'Langsung report', 'reason': types.InputReportReasonOther(), 'default_message': 'This content must be taken down.'}
                }
            }
        }
        
        # ==================== ACCOUNT REPORT (FOTO PROFIL) ====================
        self.account_reports = {
            "Spam": {'name': '📧 Spam', 'reason': types.InputReportReasonSpam()},
            "Akun Palsu": {'name': '👤 Akun Palsu', 'reason': types.InputReportReasonFake()},
            "Kekerasan": {'name': '🔪 Kekerasan', 'reason': types.InputReportReasonViolence()},
            "Kekerasan Anak": {'name': '👶 Kekerasan Anak', 'reason': types.InputReportReasonChildAbuse()},
            "Narkotika": {'name': '💊 Narkotika', 'reason': types.InputReportReasonIllegalDrugs()},
            "Data Pribadi": {'name': '📱 Data Pribadi', 'reason': types.InputReportReasonPersonalDetails()},
            "Pornografi": {'name': '🔞 Pornografi', 'reason': types.InputReportReasonPornography()},
            "Lainnya": {'name': '📌 Lainnya', 'reason': types.InputReportReasonOther(), 'custom': True}
        }
        
        # Start auto-save thread
        self.start_backup_scheduler()
    
    # ==================== FILE MANAGEMENT ====================
    def load_premium_users(self) -> Set[int]:
        try:
            if os.path.exists(config.PREMIUM_USERS_FILE):
                with open(config.PREMIUM_USERS_FILE, 'r') as f:
                    return set(json.load(f))
            return set()
        except Exception as e:
            logger.error(f"Error loading premium users: {e}")
            return set()
    
    def save_premium_users(self):
        try:
            with open(config.PREMIUM_USERS_FILE, 'w') as f:
                json.dump(list(self.premium_users), f, indent=2)
        except Exception as e:
            logger.error(f"Error saving premium users: {e}")
    
    def load_sessions(self):
        """Load multiple sessions per user"""
        try:
            if os.path.exists(config.SESSIONS_FILE):
                with open(config.SESSIONS_FILE, 'r') as f:
                    sessions_data = json.load(f)
                for user_id_str, sessions_list in sessions_data.items():
                    user_id = int(user_id_str)
                    self.user_sessions[user_id] = []
                    for data in sessions_list:
                        self.user_sessions[user_id].append({
                            'logged_in': True,
                            'phone': data.get('phone', ''),
                            'api_id': data.get('api_id', config.DEFAULT_API_ID),
                            'api_hash': data.get('api_hash', config.DEFAULT_API_HASH),
                            'session_name': data.get('session_name', f'session_{user_id}_{int(time.time())}')
                        })
                    logger.info(f"Loaded {len(self.user_sessions[user_id])} sessions for user {user_id}")
        except Exception as e:
            logger.error(f"Error loading sessions: {e}")
            self.user_sessions = {}
    
    def save_sessions(self):
        """Save multiple sessions per user"""
        try:
            sessions_data = {}
            for user_id, sessions_list in self.user_sessions.items():
                sessions_data[str(user_id)] = []
                for session in sessions_list:
                    if session.get('logged_in'):
                        sessions_data[str(user_id)].append({
                            'phone': session.get('phone', ''),
                            'api_id': session.get('api_id', config.DEFAULT_API_ID),
                            'api_hash': session.get('api_hash', config.DEFAULT_API_HASH),
                            'session_name': session.get('session_name', '')
                        })
            with open(config.SESSIONS_FILE, 'w') as f:
                json.dump(sessions_data, f, indent=2)
            
            total_sessions = sum(len(v) for v in sessions_data.values())
            logger.info(f"Sessions saved: {total_sessions} accounts")
        except Exception as e:
            logger.error(f"Error saving sessions: {e}")
    
    def start_backup_scheduler(self):
        def backup_loop():
            while True:
                time.sleep(3600)
                self.save_sessions()
                self.save_premium_users()
                logger.info("Auto-save completed")
        thread = Thread(target=backup_loop, daemon=True)
        thread.start()
    
    async def reconnect_client(self, user_id: int, session_index: int) -> bool:
        """Reconnect client for specific session"""
        try:
            sessions = self.user_sessions.get(user_id)
            if not sessions or session_index >= len(sessions):
                return False
            
            session = sessions[session_index]
            if 'client' in session:
                try:
                    await session['client'].disconnect()
                except:
                    pass
            
            client = TelegramClient(session['session_name'], session['api_id'], session['api_hash'])
            await client.connect()
            
            if await client.is_user_authorized():
                session['client'] = client
                session['logged_in'] = True
                return True
            else:
                await client.disconnect()
                session['logged_in'] = False
                self.save_sessions()
                return False
                
        except Exception as e:
            logger.error(f"Reconnect error for {user_id}: {e}")
            return False
    
    def is_owner(self, user_id: int) -> bool:
        if isinstance(config.OWNER_ID, list):
            return user_id in config.OWNER_ID
        return user_id == config.OWNER_ID
    
    def is_premium(self, user_id: int) -> bool:
        return user_id in self.premium_users or self.is_owner(user_id)
    
    def extract_from_link(self, text: str) -> Tuple[Optional[str], Optional[int]]:
        patterns = [
            r't\.me/([a-zA-Z0-9_]+)/(\d+)',
            r'https?://t\.me/([a-zA-Z0-9_]+)/(\d+)',
            r'@?([a-zA-Z0-9_]+)/(\d+)'
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1), int(match.group(2))
        return None, None
    
    def extract_username(self, text: str) -> str:
        text = text.strip()
        if text.startswith('@'):
            text = text[1:]
        if 't.me/' in text:
            text = text.split('t.me/')[-1].split('/')[0]
        return text
    
    # ==================== GET ALL ACTIVE ACCOUNTS FROM ALL PREMIUM USERS ====================
    def get_all_active_accounts(self) -> List[Tuple[int, int, Dict]]:
        """
        Mengambil SEMUA akun yang login dari SEMUA user premium
        Returns: List of (user_id, session_index, session_dict)
        """
        all_accounts = []
        
        # Loop semua user premium
        for user_id in self.premium_users:
            if user_id in self.user_sessions:
                for idx, session in enumerate(self.user_sessions[user_id]):
                    if session.get('logged_in'):
                        all_accounts.append((user_id, idx, session))
        
        logger.info(f"Total active accounts from all premium users: {len(all_accounts)}")
        return all_accounts
    
    # ==================== CEK ACC ====================
    async def cek_acc(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Command /cekacc untuk ngecek akun beku atau aktif"""
        user_id = update.effective_user.id
        
        # Cek premium
        if not self.is_premium(user_id):
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>❌ AKSES DITOLAK</blockquote></b>\n\n"
                "<blockquote>Anda bukan user premium!</blockquote>\n"
                f"<blockquote>Beli akses ke: {config.PREMIUM_CONTACT}</blockquote>",
                parse_mode='HTML'
            )
            return
        
        # Cek login
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>❌ ANDA BELUM LOGIN</blockquote></b>\n\n"
                "<blockquote>Silakan /start dan login dulu</blockquote>",
                parse_mode='HTML'
            )
            return
        
        args = context.args
        if not args:
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>🔍 CEK AKUN/CHANNEL/GROUP</blockquote></b>\n\n"
                "<blockquote>Cara pakai: /cekacc [username/link]</blockquote>\n\n"
                "<b>Contoh:</b>\n"
                "<code>/cekacc @username</code>\n"
                "<code>/cekacc https://t.me/username</code>\n\n"
                "<b>Fungsi:</b> Ngecek apakah target masih AKTIF atau sudah BEKU/FREEZE",
                parse_mode='HTML'
            )
            return
        
        target = args[0]
        username = self.extract_username(target)
        
        if not username:
            await update.message.reply_text("❌ Username tidak valid!")
            return
        
        status_msg = await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b><blockquote>🔍 MENGECEK: @{username}</blockquote></b>\n\n"
            "<blockquote>⏳ Mohon tunggu, sedang diproses...</blockquote>",
            parse_mode='HTML'
        )
        
        try:
            # Use first session
            session = self.user_sessions[user_id][0]
            if 'client' not in session:
                success = await self.reconnect_client(user_id, 0)
                if not success:
                    await status_msg.edit_text("❌ Gagal konek ke Telegram. Login ulang.")
                    return
            client = session['client']
            
            try:
                entity = await client.get_entity(username)
                entity_ditemukan = True
            except Exception as e:
                entity_ditemukan = False
                error_msg = str(e).lower()
            
            if not entity_ditemukan:
                if "username not found" in error_msg or "no user" in error_msg:
                    result_text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>🔍 HASIL CEK: @{username}</blockquote></b>
<blockquote><b>❌ STATUS: TIDAK DITEMUKAN / BEKU</b></blockquote>
<blockquote>⏰ Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</blockquote>
<blockquote>📌 Keterangan: Akun/channel/group sudah tidak ada,</blockquote>
<blockquote>dihapus, atau dibekukan permanen oleh Telegram.</blockquote>
<blockquote>⚠️ KESIMPULAN: SUDAH KEBEKU/FREEZE</blockquote>
                    """
                    await status_msg.edit_text(result_text, parse_mode='HTML')
                else:
                    await status_msg.edit_text(f"❌ Error: {str(e)}")
                return
            
            if hasattr(entity, 'broadcast') and entity.broadcast:
                entity_type = "📢 CHANNEL"
            elif hasattr(entity, 'megagroup') and entity.megagroup:
                entity_type = "👥 SUPERGROUP"
            elif hasattr(entity, 'gigagroup') and entity.gigagroup:
                entity_type = "👥 GIGAGROUP"
            elif hasattr(entity, 'chat') or (hasattr(entity, 'id') and not hasattr(entity, 'username')):
                entity_type = "👥 GROUP"
            else:
                entity_type = "👤 AKUN"
            
            status = "✅ AKTIF"
            keterangan = "Masih aktif dan bisa diakses"
            
            scam = "❌ Tidak"
            fake = "❌ Tidak"
            if hasattr(entity, 'scam') and entity.scam:
                scam = "⚠️ Ya (Scam)"
                keterangan += ", terdeteksi sebagai SCAM"
            if hasattr(entity, 'fake') and entity.fake:
                fake = "⚠️ Ya (Fake)"
                keterangan += ", terdeteksi sebagai FAKE"
            
            restricted = False
            if hasattr(entity, 'restriction_reason') and entity.restriction_reason:
                restricted = True
                status = "❌ BEKU "
                keterangan += ", Akun sudah dihapus/dibekukan"
            
            try:
                if entity_type == "👤 AKUN":
                    full = await client(functions.users.GetFullUserRequest(entity.id))
                    if full.full_user.deleted:
                        status = "❌ BEKU"
                        keterangan = "Akun sudah dihapus/dibekukan"
                    elif full.user.restricted:
                        status = "❌ BEKU "
                        keterangan = "Akun sudah dihapus/dibekukan"
            except:
                pass
            
            result_text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>🔍 HASIL CEK: @{username}</blockquote></b>

<blockquote><b>📌 INFORMASI:</b></blockquote>
<blockquote>• Tipe: {entity_type}</blockquote>
<blockquote>• ID: <code>{entity.id}</code></blockquote>
<blockquote>• Nama: {getattr(entity, 'title', getattr(entity, 'first_name', 'Tidak diketahui'))}</blockquote>

<blockquote><b>🔍 STATUS:</b></blockquote>
<blockquote>• {status}</blockquote>
<blockquote>• Scam: {scam}</blockquote>
<blockquote>• Fake: {fake}</blockquote>
<blockquote>• Restriksi: {'⚠️ Ada' if restricted else '✅ Tidak ada'}</blockquote>

<blockquote><b>📝 KETERANGAN:</b></blockquote>
<blockquote>{keterangan}</blockquote>
<blockquote><b>⏰ WAKTU CEK:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</blockquote>
<blockquote><b>✅ KESIMPULAN: {status}</b></blockquote>
            """
            
            keyboard = [[InlineKeyboardButton("🔙 Menu Utama", callback_data='back_to_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await status_msg.edit_text(result_text, reply_markup=reply_markup, parse_mode='HTML')
            
        except Exception as e:
            logger.error(f"Error cek_acc: {e}")
            await status_msg.edit_text(f"❌ Error: {str(e)}")
    
    # ==================== BROADCAST ====================
    async def broadcast(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        
        if not self.is_owner(user_id):
            await update.message.reply_text("❌ Hanya owner yang bisa!")
            return
        
        if not update.message.reply_to_message:
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>📢 BROADCAST</blockquote></b>\n\n"
                "<blockquote>Gunakan /broadcast dengan reply ke pesan!</blockquote>\n\n"
                "Contoh: Reply pesan ➡️ /broadcast",
                parse_mode='HTML'
            )
            return
        
        replied = update.message.reply_to_message
        users = list(self.user_sessions.keys())
        
        if not users:
            await update.message.reply_text("❌ Belum ada user")
            return
        
        progress = await update.message.reply_text(
            f"<b>📢 Broadcast ke {len(users)} user...</b>",
            parse_mode='HTML'
        )
        
        success = 0
        failed = 0
        
        for target_id in users:
            if target_id == user_id:
                continue
            try:
                if replied.photo:
                    await context.bot.send_photo(
                        target_id, replied.photo[-1].file_id,
                        caption=f"<b>📢 BROADCAST:</b>\n\n{replied.caption or ''}",
                        parse_mode='HTML'
                    )
                elif replied.video:
                    await context.bot.send_video(
                        target_id, replied.video.file_id,
                        caption=f"<b>📢 BROADCAST:</b>\n\n{replied.caption or ''}",
                        parse_mode='HTML'
                    )
                elif replied.document:
                    await context.bot.send_document(
                        target_id, replied.document.file_id,
                        caption=f"<b>📢 BROADCAST:</b>\n\n{replied.caption or ''}",
                        parse_mode='HTML'
                    )
                elif replied.text:
                    await context.bot.send_message(
                        target_id,
                        f"<b>📢 BROADCAST:</b>\n\n{replied.text}",
                        parse_mode='HTML'
                    )
                else:
                    await context.bot.copy_message(
                        target_id, update.effective_chat.id, replied.message_id
                    )
                success += 1
                await asyncio.sleep(0.3)
            except Exception as e:
                logger.error(f"Broadcast error to {target_id}: {e}")
                failed += 1
        
        await progress.edit_text(
            f"<b><blockquote>✅ BROADCAST SELESAI</blockquote></b>\n\n"
            f"<blockquote>✓ Berhasil: {success}</blockquote>\n"
            f"<blockquote>✗ Gagal: {failed}</blockquote>\n"
            f"<blockquote>📊 Total: {success + failed}</blockquote>",
            parse_mode='HTML'
        )
    
    # ==================== PREMIUM COMMANDS WITH BUTTONS ====================
    async def add_premium_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Command /addprem untuk menambah user premium"""
        user_id = update.effective_user.id
        
        if not self.is_owner(user_id):
            await update.message.reply_text("❌ Hanya owner yang bisa!")
            return
        
        if not context.args:
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>➕ ADD PREMIUM</blockquote></b>\n\n"
                "<blockquote>Cara pakai:</blockquote>\n"
                "<code>/addprem 123456789</code>\n"
                "<code>/addprem @username</code>\n"
                "<code>/addprem (reply ke user)</code>\n\n"
                "<blockquote>Atau gunakan tombol di Owner Panel</blockquote>",
                parse_mode='HTML'
            )
            return
        
        target_id = None
        
        # Cek jika reply ke user
        if update.message.reply_to_message and update.message.reply_to_message.from_user:
            target_id = update.message.reply_to_message.from_user.id
        
        # Cek jika mention username
        elif context.args[0].startswith('@'):
            username = context.args[0][1:]
            try:
                async for member in context.bot.get_chat_members(update.effective_chat.id):
                    if member.user.username == username:
                        target_id = member.user.id
                        break
            except:
                pass
        
        # Cek jika ID langsung
        else:
            try:
                target_id = int(context.args[0])
            except:
                pass
        
        if not target_id:
            await update.message.reply_text("❌ Gagal menemukan user!")
            return
        
        if target_id in self.premium_users:
            await update.message.reply_text(f"⚠️ User `{target_id}` sudah premium!", parse_mode='Markdown')
        else:
            self.premium_users.add(target_id)
            self.save_premium_users()
            
            # Notifikasi ke user yang ditambah
            try:
                await context.bot.send_message(
                    target_id,
                    f"<a href=\"{BANNER_URL}\"> </a>\n"
                    "<b><blockquote>🎉 SELAMAT!</blockquote></b>\n\n"
                    "<blockquote>Anda sekarang menjadi user PREMIUM!</blockquote>\n"
                    "<blockquote>Nikmati semua fitur tanpa batasan.</blockquote>\n\n"
                    "<blockquote>Terima kasih telah membeli akses!</blockquote>",
                    parse_mode='HTML'
                )
            except:
                pass
            
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>✅ PREMIUM ADDED</blockquote></b>\n\n"
                f"<blockquote>User: <code>{target_id}</code></blockquote>\n"
                f"<blockquote>Status: PREMIUM</blockquote>",
                parse_mode='HTML'
            )
    
    async def list_premium_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Command /listprem untuk lihat user premium"""
        user_id = update.effective_user.id
        
        if not self.is_owner(user_id):
            await update.message.reply_text("❌ Hanya owner yang bisa!")
            return
        
        if not self.premium_users:
            text = f"<a href=\"{BANNER_URL}\"> </a>\n<b><blockquote>📋 PREMIUM USERS</blockquote></b>\n\n<blockquote>❌ Belum ada user premium</blockquote>"
        else:
            premium_list = "\n".join([f"<blockquote>• <code>{uid}</code></blockquote>" for uid in self.premium_users])
            text = f"<a href=\"{BANNER_URL}\"> </a>\n<b><blockquote>📋 PREMIUM USERS ({len(self.premium_users)})</blockquote></b>\n\n{premium_list}"
        
        await update.message.reply_text(text, parse_mode='HTML')
    
    async def del_premium_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Command /delprem untuk hapus user premium"""
        user_id = update.effective_user.id
        
        if not self.is_owner(user_id):
            await update.message.reply_text("❌ Hanya owner yang bisa!")
            return
        
        if not context.args:
            await update.message.reply_text(
                "<b>❌ Cara pakai:</b>\n"
                "<code>/delprem 123456789</code>\n"
                "<code>/delprem @username</code>",
                parse_mode='HTML'
            )
            return
        
        target_id = None
        
        if context.args[0].startswith('@'):
            username = context.args[0][1:]
            try:
                async for member in context.bot.get_chat_members(update.effective_chat.id):
                    if member.user.username == username:
                        target_id = member.user.id
                        break
            except:
                pass
        else:
            try:
                target_id = int(context.args[0])
            except:
                pass
        
        if not target_id:
            await update.message.reply_text("❌ Gagal menemukan user!")
            return
        
        if target_id in self.premium_users:
            self.premium_users.remove(target_id)
            self.save_premium_users()
            
            try:
                await context.bot.send_message(
                    target_id,
                    f"<a href=\"{BANNER_URL}\"> </a>\n"
                    "<b><blockquote>⚠️ PREMIUM EXPIRED</blockquote></b>\n\n"
                    "<blockquote>Status premium Anda telah dihapus.</blockquote>\n"
                    f"<blockquote>Beli lagi ke {config.PREMIUM_CONTACT} untuk akses.</blockquote>",
                    parse_mode='HTML'
                )
            except:
                pass
            
            await update.message.reply_text(f"✅ User `{target_id}` dihapus dari premium!", parse_mode='Markdown')
        else:
            await update.message.reply_text(f"⚠️ User `{target_id}` bukan user premium!", parse_mode='Markdown')
    
    # ==================== START & MAIN MENU ====================
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        
        # Cek premium
        if not self.is_premium(user_id):
            keyboard = [[InlineKeyboardButton("💎 Beli Premium", url=f"https://t.me/{config.PREMIUM_CONTACT[1:]}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>🤖 MASS REPORTER V4.0</blockquote></b>\n"
                "<blockquote>🔴 100% REAL REPORT</blockquote>\n"
                f"<blockquote>💎 HARGA: {config.PREMIUM_PRICE}</blockquote>\n"
                f"<blockquote>📞 BELI: {config.PREMIUM_CONTACT}</blockquote>\n\n"
                "<blockquote>⚠️ Akses hanya untuk PREMIUM USER!</blockquote>\n"
                "<blockquote>Silakan beli akses terlebih dahulu.</blockquote>",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            return
        
        if user_id in self.user_sessions and self.user_sessions[user_id]:
            await self.show_main_menu(update)
        else:
            keyboard = [[InlineKeyboardButton("🔐 Login Akun", callback_data='login_new')]]
            if self.is_owner(user_id):
                keyboard.append([InlineKeyboardButton("👑 Owner", callback_data='owner_panel')])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>🤖 BOT REPORT X8</blockquote></b>
<blockquote>🔴 100% REAL REPORT</blockquote>
<blockquote>💎 PREMIUM USER : @j4eDvn</blockquote>
<blockquote>Belum ada akun yang login. Login dulu bg!</blockquote>
            """
            await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='HTML')
    
    async def show_main_menu(self, update):
        """Show main menu with multiple accounts support"""
        if hasattr(update, 'message') and update.message:
            user_id = update.message.from_user.id
            send_func = update.message.reply_text
        elif hasattr(update, 'callback_query') and update.callback_query:
            user_id = update.callback_query.from_user.id
            query = update.callback_query
            send_func = query.edit_message_text
        else:
            user_id = update.from_user.id
            send_func = update.edit_message_text
        
        active_accounts = 0
        if user_id in self.user_sessions:
            active_accounts = len([s for s in self.user_sessions[user_id] if s.get('logged_in')])
        
        # Hitung total akun dari semua premium user
        total_all_accounts = len(self.get_all_active_accounts())
        
        keyboard = [
            [InlineKeyboardButton("🔥 Report Channel", callback_data='report_channel')],
            [InlineKeyboardButton("⚠️ Report Group", callback_data='report_group')],
            [InlineKeyboardButton("👾 Report Account (Foto Profil)", callback_data='report_account')],
            [InlineKeyboardButton("📖 Report Story", callback_data='report_story')],
            [InlineKeyboardButton("🥶 Cek Akun Freeze", callback_data='cek_acc_manual')],
            [InlineKeyboardButton(f"👤 Akun Saya", callback_data='my_accounts')],
            [InlineKeyboardButton(f"💯 Total Akun Semua User ({total_all_accounts})", callback_data='total_accounts')],
            [InlineKeyboardButton("📛 Tambah Akun Baru", callback_data='login_new')]
        ]
        if self.is_owner(user_id):
            keyboard.append([InlineKeyboardButton("⿻ Owner Panel", callback_data='owner_panel')])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status_text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>🎯 BOT REPORT X8</blockquote></b>
<blockquote>💎 PREMIUM USER</blockquote>
<blockquote>🌍 Total Akun Semua Premium: {total_all_accounts} akun</blockquote>
<blockquote>💾 Multiple accounts supported</blockquote>
<blockquote>🔴 100% REAL REPORT</blockquote>
<blockquote>Pilih jenis report:</blockquote>
        """
        await send_func(status_text, reply_markup=reply_markup, parse_mode='HTML')
    
    async def show_total_accounts(self, query):
        """Show total accounts from all premium users"""
        user_id = query.from_user.id
        
        all_accounts = self.get_all_active_accounts()
        
        # Group by user
        user_stats = {}
        for uid, idx, sess in all_accounts:
            if uid not in user_stats:
                user_stats[uid] = {'count': 0, 'phones': []}
            user_stats[uid]['count'] += 1
            phone = sess.get('phone', 'Unknown')
            user_stats[uid]['phones'].append(phone[:4] + "****" + phone[-4:] if len(phone) > 8 else phone)
        
        stats_text = ""
        for uid, stats in user_stats.items():
            stats_text += f"<blockquote>👤 User {uid}: {stats['count']} akun</blockquote>\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data='back_to_menu')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🌍 TOTAL AKUN SEMUA PREMIUM USER</blockquote></b>\n\n"
            f"<blockquote><b>Total Akun: {len(all_accounts)}</b></blockquote>\n\n"
            f"{stats_text}",
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
    
    async def show_my_accounts(self, query):
        """Show all accounts for user"""
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>📊 AKUN SAYA</blockquote></b>\n\n"
                "<blockquote>❌ Belum ada akun yang login</blockquote>\n\n"
                "<blockquote>Gunakan tombol 'Tambah Akun Baru' untuk login</blockquote>",
                parse_mode='HTML'
            )
            return
        
        accounts_text = ""
        for idx, session in enumerate(self.user_sessions[user_id], 1):
            phone = session.get('phone', 'Unknown')
            hidden_phone = phone[:4] + "****" + phone[-4:] if len(phone) > 8 else phone
            status = "✅" if session.get('logged_in') else "❌"
            accounts_text += f"<blockquote>{idx}. {status} {hidden_phone}</blockquote>\n"
        
        keyboard = [
            [InlineKeyboardButton("➕ Tambah Akun", callback_data='login_new')],
            [InlineKeyboardButton("🔙 Back", callback_data='back_to_menu')]
        ]
        
        # Tambah tombol hapus per akun
        for idx in range(len(self.user_sessions[user_id])):
            keyboard.insert(-1, [InlineKeyboardButton(f"🗑️ Hapus Akun {idx+1}", callback_data=f'delete_account_{idx}')])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>📊 AKUN SAYA</blockquote></b>
{accounts_text}
<blockquote><b>Total: {len(self.user_sessions[user_id])} akun</b></blockquote>
        """
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='HTML')
    
    async def delete_account(self, query, index: int):
        """Delete specific account"""
        user_id = query.from_user.id
        
        if user_id in self.user_sessions and index < len(self.user_sessions[user_id]):
            session = self.user_sessions[user_id][index]
            if 'client' in session:
                try:
                    await session['client'].disconnect()
                except:
                    pass
            
            # Hapus file session
            session_name = session.get('session_name', '')
            if session_name and os.path.exists(f"{session_name}.session"):
                try:
                    os.remove(f"{session_name}.session")
                except:
                    pass
            
            self.user_sessions[user_id].pop(index)
            self.save_sessions()
            
            await query.answer("✅ Akun dihapus!")
            await self.show_my_accounts(query)
        else:
            await query.answer("❌ Gagal menghapus akun!")
    
    # ==================== LOGIN ====================
    async def start_login(self, query):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = []
        
        # Create unique session name
        session_name = f'session_{user_id}_{len(self.user_sessions[user_id])}_{int(time.time())}'
        
        self.user_sessions[user_id].append({
            'step': 'phone',
            'api_id': config.DEFAULT_API_ID,
            'api_hash': config.DEFAULT_API_HASH,
            'session_name': session_name,
            'logged_in': False
        })
        
        current_index = len(self.user_sessions[user_id]) - 1
        self.user_sessions[user_id][current_index]['index'] = current_index
        
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🔐 LOGIN AKUN BARU</blockquote></b>\n\n"
            "<blockquote>Kirim nomor telepon:</blockquote>\n"
            "<code>Contoh: +6281234567890</code>\n\n"
            "<blockquote>Ketik /cancel untuk membatalkan</blockquote>",
            parse_mode='HTML'
        )
    
    async def logout_all(self, query):
        user_id = query.from_user.id
        
        if user_id in self.user_sessions:
            for session in self.user_sessions[user_id]:
                if 'client' in session:
                    try:
                        await session['client'].disconnect()
                    except:
                        pass
                # Hapus file session
                session_name = session.get('session_name', '')
                if session_name and os.path.exists(f"{session_name}.session"):
                    try:
                        os.remove(f"{session_name}.session")
                    except:
                        pass
            del self.user_sessions[user_id]
        
        keyboard = [[InlineKeyboardButton("🔐 Login Akun", callback_data='login_new')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>✅ LOGOUT SEMUA AKUN</blockquote></b>\n\n"
            "<blockquote>Semua session dihapus</blockquote>",
            reply_markup=reply_markup, 
            parse_mode='HTML'
        )
    
    # ==================== BUTTON HANDLER ====================
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id
        data = query.data
        
        logger.info(f"Button: {data} by {user_id}")
        
        # DAFTAR TOMBOL YANG TIDAK PERLU CEK PREMIUM
        no_premium_check = [
            'login_new', 'owner_panel', 'back_to_menu', 'back_to_owner',
            'my_accounts', 'logout_all', 'add_premium', 'remove_premium', 
            'list_premium', 'backup_now', 'stats', 'cek_acc_manual', 'total_accounts'
        ]
        
        # Hanya cek premium jika tombol bukan termasuk dalam daftar di atas
        if data not in no_premium_check:
            if not self.is_premium(user_id):
                keyboard = [[InlineKeyboardButton("💎 Beli Premium", url=f"https://t.me/{config.PREMIUM_CONTACT[1:]}")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(
                    f"<a href=\"{BANNER_URL}\"> </a>\n"
                    "<b><blockquote>⏰ AKSES DITOLAK</blockquote></b>\n\n"
                    "<blockquote>Anda bukan user premium!</blockquote>\n"
                    f"<blockquote>Beli akses ke {config.PREMIUM_CONTACT}</blockquote>",
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
                return
        
        # Proses tombol berdasarkan data
        if data == 'login_new':
            await self.start_login(query)
        elif data == 'logout_all':
            await self.logout_all(query)
        elif data == 'my_accounts':
            await self.show_my_accounts(query)
        elif data == 'total_accounts':
            await self.show_total_accounts(query)
        elif data.startswith('delete_account_'):
            idx = int(data.split('_')[2])
            await self.delete_account(query, idx)
        elif data == 'back_to_menu':
            await self.show_main_menu(query)
        elif data == 'cek_acc_manual':
            await self.cek_acc_manual(query)
        elif data == 'owner_panel' and self.is_owner(user_id):
            await self.show_owner_panel(query)
        elif data == 'add_premium' and self.is_owner(user_id):
            await self.add_premium_panel(query)
        elif data == 'remove_premium' and self.is_owner(user_id):
            await self.remove_premium_panel(query)
        elif data == 'list_premium' and self.is_owner(user_id):
            await self.list_premium_panel(query)
        elif data == 'backup_now' and self.is_owner(user_id):
            await self.backup_files(query)
        elif data == 'back_to_owner' and self.is_owner(user_id):
            await self.show_owner_panel(query)
        elif data == 'stats' and self.is_owner(user_id):
            await self.show_stats(query)
        elif data == 'report_story':
            await self.start_story_report(query)
        elif data == 'story_type_public':
            await self.story_input_public(query)
        elif data == 'story_type_private':
            await self.story_input_private(query)
        elif data.startswith('story_reason_'):
            reason_key = data[len('story_reason_'):]
            await self.story_show_subreason(query, reason_key)
        elif data.startswith('story_sub_'):
            parts = data[len('story_sub_'):].split('|', 1)
            if len(parts) == 2:
                await self.story_select_subreason(query, parts[0], parts[1])
        elif data == 'story_custom_comment':
            await self.story_ask_custom_comment(query)
        elif data.startswith('story_quota_'):
            quota_val = data[len('story_quota_'):]
            await self.story_set_quota(query, quota_val)
        elif data == 'story_quota_manual':
            await self.story_ask_manual_quota(query)
        elif data == 'story_execute':
            await self.story_execute(query)
        elif data == 'story_cancel':
            await self.show_main_menu(query)
        elif data == 'report_channel':
            await self.start_channel_report(query, 'channel')
        elif data == 'report_group':
            await self.start_channel_report(query, 'group')
        elif data == 'report_account':
            await self.start_account_report(query)
        elif data.startswith('cat_'):
            category = data[4:]
            await self.show_channel_options(query, category)
        elif data.startswith('opt_'):
            parts = data.split('_')
            if len(parts) >= 3:
                category = parts[1]
                option = '_'.join(parts[2:])
                await self.show_report_method(query, category, option)
        elif data.startswith('act_'):
            parts = data.split('_')
            if len(parts) >= 4:
                action = parts[1]
                category = parts[2]
                option = '_'.join(parts[3:])
                await self.process_report_action(query, action, category, option)
        elif data.startswith('acc_'):
            option = data[4:]
            await self.handle_account_option(query, option)
        elif data.startswith('again_'):
            report_type = data[6:]
            await self.report_again(query, report_type)
        elif data == 'back_to_channel_categories':
            await self.start_channel_report(query, 'channel')
        elif data == 'back_to_group_categories':
            await self.start_channel_report(query, 'group')
        elif data == 'back_to_account_categories':
            await self.start_account_report(query)
        elif data.startswith('back_to_cat_'):
            category = data[12:]
            await self.show_channel_options(query, category)
        else:
            await query.edit_message_text("❌ Tombol error")
    
    async def cek_acc_manual(self, query):
        """Manual cek acc via button"""
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>❌ ANDA BELUM LOGIN</blockquote></b>\n\n"
                "<blockquote>Silakan login dulu</blockquote>",
                parse_mode='HTML'
            )
            return
        
        # Set step untuk akun pertama
        self.user_sessions[user_id][0]['step'] = 'cek_acc_waiting'
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🔍 CEK AKUN/CHANNEL/GROUP</blockquote></b>\n\n"
            "<blockquote>Kirim username atau link yang ingin dicek:</blockquote>\n\n"
            "<b>Contoh:</b>\n"
            "<code>@username</code>\n"
            "<code>https://t.me/username</code>\n\n"
            "<b>Fungsi:</b> Ngecek apakah target masih AKTIF atau sudah BEKU",
            parse_mode='HTML'
        )
    
    # ==================== REPORT CHANNEL/GROUP ====================
    async def start_channel_report(self, query, report_type):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await query.edit_message_text("❌ Belum ada akun login! Silakan tambah akun dulu.")
            return
        
        logger.info(f"User {user_id} starting {report_type} report")
        self.active_reports[user_id] = {
            'type': report_type,
            'start_time': datetime.now(),
            'status': 'selecting_category'
        }
        
        # Set untuk akun pertama
        self.user_sessions[user_id][0]['report_type'] = report_type
        type_name = "CHANNEL" if report_type == 'channel' else "GROUP"
        
        keyboard = []
        for cat_key, cat_data in self.channel_reports.items():
            keyboard.append([InlineKeyboardButton(cat_data['name'], callback_data=f"cat_{cat_key}")])
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data='back_to_menu')])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b><blockquote>📢 REPORT {type_name}</blockquote></b>\n\n"
            f"<blockquote>Pilih kategori:</blockquote>",
            reply_markup=reply_markup, parse_mode='HTML'
        )
    
    async def show_channel_options(self, query, category):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            return
        
        report_type = self.user_sessions[user_id][0].get('report_type', 'channel')
        type_name = "CHANNEL" if report_type == 'channel' else "GROUP"
        self.user_sessions[user_id][0]['category'] = category
        self.user_sessions[user_id][0]['type'] = report_type
        
        cat_data = self.channel_reports.get(category)
        if not cat_data:
            await query.edit_message_text("❌ Kategori error")
            return
        
        keyboard = []
        for opt_key, opt_data in cat_data['options'].items():
            keyboard.append([InlineKeyboardButton(opt_data['name'], callback_data=f"opt_{category}_{opt_key}")])
        
        back_callback = 'back_to_channel_categories' if report_type == 'channel' else 'back_to_group_categories'
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data=back_callback)])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b><blockquote>{type_name} - {cat_data['name']}</blockquote></b>\n\n"
            f"<blockquote>Pilih alasan:</blockquote>",
            reply_markup=reply_markup, parse_mode='HTML'
        )
    
    async def show_report_method(self, query, category, option):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            return
        
        report_type = self.user_sessions[user_id][0].get('report_type', 'channel')
        cat_data = self.channel_reports[category]
        opt_data = cat_data['options'][option]
        
        self.user_sessions[user_id][0]['category'] = category
        self.user_sessions[user_id][0]['option'] = option
        
        if opt_data.get('always_custom', False):
            self.user_sessions[user_id][0]['use_custom'] = True
            self.user_sessions[user_id][0]['step'] = 'custom_text'
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>📝 Custom Text</blockquote></b>\n\n"
                f"<blockquote>Kirim pesan custom:</blockquote>",
                parse_mode='HTML'
            )
        else:
            keyboard = [
                [InlineKeyboardButton("✅ LANGSUNG", callback_data=f"act_direct_{category}_{option}")],
                [InlineKeyboardButton("📝 CUSTOM", callback_data=f"act_custom_{category}_{option}")],
                [InlineKeyboardButton("🔙 Back", callback_data=f"back_to_cat_{category}")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>{opt_data['name']}</blockquote></b>\n\n"
                f"<blockquote>Pilih metode:</blockquote>",
                reply_markup=reply_markup, parse_mode='HTML'
            )
    
    async def process_report_action(self, query, action, category, option):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            return
        
        report_type = self.user_sessions[user_id][0].get('report_type', 'channel')
        type_name = "CHANNEL" if report_type == 'channel' else "GROUP"
        
        self.user_sessions[user_id][0]['category'] = category
        self.user_sessions[user_id][0]['option'] = option
        self.user_sessions[user_id][0]['use_custom'] = (action == 'custom')
        self.user_sessions[user_id][0]['type'] = report_type
        
        if action == 'custom':
            self.user_sessions[user_id][0]['step'] = 'custom_text'
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>📝 Custom Text - {type_name}</blockquote></b>\n\n"
                f"<blockquote>Kirim pesan custom:</blockquote>",
                parse_mode='HTML'
            )
        else:
            self.user_sessions[user_id][0]['step'] = 'target'
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>✅ LANGSUNG REPORT</blockquote></b>\n\n"
                f"<blockquote>Kirim link atau username:</blockquote>\n"
                f"<code>Contoh: @username atau https://t.me/username/123</code>",
                parse_mode='HTML'
            )
    
    # ==================== REPORT ACCOUNT ====================
    async def start_account_report(self, query):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await query.edit_message_text("❌ Belum ada akun login!")
            return
        
        logger.info(f"User {user_id} starting account report")
        self.active_reports[user_id] = {
            'type': 'account',
            'start_time': datetime.now(),
            'status': 'selecting_category'
        }
        
        self.user_sessions[user_id][0]['type'] = 'account'
        
        keyboard = [
            [InlineKeyboardButton("📧 Spam", callback_data='acc_Spam')],
            [InlineKeyboardButton("👤 Akun Palsu", callback_data='acc_Akun Palsu')],
            [InlineKeyboardButton("🔪 Kekerasan", callback_data='acc_Kekerasan')],
            [InlineKeyboardButton("👶 Kekerasan Anak", callback_data='acc_Kekerasan Anak')],
            [InlineKeyboardButton("💊 Narkotika", callback_data='acc_Narkotika')],
            [InlineKeyboardButton("📱 Data Pribadi", callback_data='acc_Data Pribadi')],
            [InlineKeyboardButton("🔞 Pornografi", callback_data='acc_Pornografi')],
            [InlineKeyboardButton("📌 Lainnya (Custom)", callback_data='acc_Lainnya')],
            [InlineKeyboardButton("🔙 Back", callback_data='back_to_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>👤 REPORT ACCOUNT (FOTO PROFIL)</blockquote></b>\n\n"
            "<blockquote>Pilih alasan report foto profil:</blockquote>",
            reply_markup=reply_markup, parse_mode='HTML'
        )
    
    async def handle_account_option(self, query, option):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            return
        
        self.user_sessions[user_id][0]['account_option'] = option
        self.user_sessions[user_id][0]['type'] = 'account'
        
        if option == "Lainnya":
            self.user_sessions[user_id][0]['step'] = 'custom_text'
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>📝 Custom Text</blockquote></b>\n\n"
                f"<blockquote>Kirim pesan custom untuk report foto profil:</blockquote>",
                parse_mode='HTML'
            )
        else:
            self.user_sessions[user_id][0]['step'] = 'target'
            await query.edit_message_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                f"<b><blockquote>✅ {self.account_reports[option]['name']}</blockquote></b>\n\n"
                f"<blockquote>Kirim username target (yang foto profilnya mau direport):</blockquote>\n"
                f"<code>Contoh: @username</code>\n\n"
                f"<i>⚠️ Bot akan otomatis report foto profil akun tersebut</i>",
                parse_mode='HTML'
            )
    
    # ==================== MESSAGE HANDLER ====================
    async def message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        text = update.message.text
        
        # Cek premium untuk user non-owner
        if not self.is_premium(user_id) and not self.is_owner(user_id):
            keyboard = [[InlineKeyboardButton("💎 Beli Premium", url=f"https://t.me/{config.PREMIUM_CONTACT[1:]}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>⏰ AKSES DITOLAK</blockquote></b>\n\n"
                "<blockquote>Anda bukan user premium!</blockquote>",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            return
        
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await update.message.reply_text("Silakan /start dulu dan login.")
            return
        
        # Cek step untuk setiap session
        for idx, session in enumerate(self.user_sessions[user_id]):
            step = session.get('step')
            
            if step == 'story_input_public':
                await self.story_process_public_target(update, text, idx)
                return
            elif step == 'story_input_join_link':
                await self.story_process_join_link(update, text, idx)
                return
            elif step == 'story_input_private_link':
                await self.story_process_private_link(update, text, idx)
                return
            elif step == 'story_input_custom_comment':
                await self.story_process_custom_comment(update, text, idx)
                return
            elif step == 'story_input_manual_quota':
                await self.story_process_manual_quota(update, text, idx)
                return
            elif step == 'cek_acc_waiting':
                await self.process_cek_acc_manual(update, text, idx)
                return
            
            elif step == 'phone':
                await self.process_phone(update, text, idx)
                return
            
            elif step == 'verification_code':
                await self.process_code(update, text, idx)
                return
            
            elif step == '2fa_password':
                await self.process_2fa(update, text, idx)
                return
            
            elif step == 'custom_text':
                session['custom_message'] = text
                session['step'] = 'target'
                await update.message.reply_text(
                    f"<b>✅ Custom tersimpan!</b>\n\n"
                    f"<blockquote>Sekarang kirim target:</blockquote>",
                    parse_mode='HTML'
                )
                return
            
            elif step == 'target':
                await self.process_target(update, text, idx)
                return
            
            elif step == 'count':
                await self.process_count(update, text, idx)
                return
            
            elif step == 'waiting_add_premium' and self.is_owner(user_id):
                await self.process_add_premium(update, text, idx)
                return
            
            elif step == 'waiting_remove_premium' and self.is_owner(user_id):
                await self.process_remove_premium(update, text, idx)
                return
    
    async def process_cek_acc_manual(self, update: Update, target: str, session_idx: int):
        """Process manual cek acc"""
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        
        username = self.extract_username(target)
        if not username:
            await update.message.reply_text("❌ Username tidak valid!")
            session['step'] = None
            return
        
        status_msg = await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b><blockquote>🔍 MENGECEK: @{username}</blockquote></b>\n\n"
            "<blockquote>⏳ Mohon tunggu, sedang diproses...</blockquote>",
            parse_mode='HTML'
        )
        
        try:
            if 'client' not in session:
                success = await self.reconnect_client(user_id, session_idx)
                if not success:
                    await status_msg.edit_text("❌ Gagal konek ke Telegram. Login ulang.")
                    session['step'] = None
                    return
            client = session['client']
            
            try:
                entity = await client.get_entity(username)
                entity_ditemukan = True
            except Exception as e:
                entity_ditemukan = False
                error_msg = str(e).lower()
            
            if not entity_ditemukan:
                if "username not found" in error_msg or "no user" in error_msg:
                    result_text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>🔍 HASIL CEK: @{username}</blockquote></b>
<blockquote><b>❌ STATUS: TIDAK DITEMUKAN / BEKU</b></blockquote>
<blockquote>⏰ Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</blockquote>
<blockquote>📌 Keterangan: Akun/channel/group sudah tidak ada,</blockquote>
<blockquote>dihapus, atau dibekukan permanen oleh Telegram.</blockquote>
<blockquote>⚠️ KESIMPULAN: SUDAH KEBEKU/FREEZE</blockquote>
                    """
                    await status_msg.edit_text(result_text, parse_mode='HTML')
                else:
                    await status_msg.edit_text(f"❌ Error: {str(e)}")
                session['step'] = None
                return
            
            if hasattr(entity, 'broadcast') and entity.broadcast:
                entity_type = "📢 CHANNEL"
            elif hasattr(entity, 'megagroup') and entity.megagroup:
                entity_type = "👥 SUPERGROUP"
            elif hasattr(entity, 'gigagroup') and entity.gigagroup:
                entity_type = "👥 GIGAGROUP"
            elif hasattr(entity, 'chat') or (hasattr(entity, 'id') and not hasattr(entity, 'username')):
                entity_type = "👥 GROUP"
            else:
                entity_type = "👤 AKUN"
            
            status = "✅ AKTIF"
            keterangan = "Masih aktif dan bisa diakses"
            
            scam = "❌ Tidak"
            fake = "❌ Tidak"
            if hasattr(entity, 'scam') and entity.scam:
                scam = "⚠️ Ya (Scam)"
                keterangan += ", terdeteksi sebagai SCAM"
            if hasattr(entity, 'fake') and entity.fake:
                fake = "⚠️ Ya (Fake)"
                keterangan += ", terdeteksi sebagai FAKE"
            
            restricted = False
            if hasattr(entity, 'restriction_reason') and entity.restriction_reason:
                restricted = True
                status = "❌ BEKU "
                keterangan += ",Akun sudah dihapus/dibekukan"
            
            try:
                if entity_type == "👤 AKUN":
                    full = await client(functions.users.GetFullUserRequest(entity.id))
                    if full.full_user.deleted:
                        status = "❌ BEKU "
                        keterangan = "Akun sudah dihapus/dibekukan"
                    elif full.user.restricted:
                        status = "❌ BEKU "
                        keterangan = "Akun sudah dihapus/dibekukan"
            except:
                pass
            
            result_text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>🔍 HASIL CEK: @{username}</blockquote></b>

<blockquote><b>📌 INFORMASI:</b></blockquote>
<blockquote>• Tipe: {entity_type}</blockquote>
<blockquote>• ID: <code>{entity.id}</code></blockquote>
<blockquote>• Nama: {getattr(entity, 'title', getattr(entity, 'first_name', 'Tidak diketahui'))}</blockquote>

<blockquote><b>🔍 STATUS:</b></blockquote>
<blockquote>• {status}</blockquote>
<blockquote>• Scam: {scam}</blockquote>
<blockquote>• Fake: {fake}</blockquote>
<blockquote>• Restriksi: {'⚠️ Ada' if restricted else '✅ Tidak ada'}</blockquote>

<blockquote><b>📝 KETERANGAN:</b></blockquote>
<blockquote>{keterangan}</blockquote>
<blockquote><b>⏰ WAKTU CEK:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</blockquote>
<blockquote><b>✅ KESIMPULAN: {status}</b></blockquote>
            """
            
            keyboard = [[InlineKeyboardButton("🔙 Menu Utama", callback_data='back_to_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await status_msg.edit_text(result_text, reply_markup=reply_markup, parse_mode='HTML')
            
        except Exception as e:
            logger.error(f"Error cek_acc manual: {e}")
            await status_msg.edit_text(f"❌ Error: {str(e)}")
        
        session['step'] = None
    
    async def process_target(self, update: Update, text: str, session_idx: int):
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        report_type = session.get('type', 'channel')
        
        channel_name, msg_id = self.extract_from_link(text)
        
        if channel_name and msg_id and report_type in ['channel', 'group']:
            session['target'] = channel_name
            session['message_id'] = msg_id
            session['step'] = 'count'
            await update.message.reply_text(
                f"<b>✅ Target: @{channel_name}</b>\n"
                f"Message ID: {msg_id}\n\n"
                f"Berapa kali report? (max 15)",
                parse_mode='HTML'
            )
        else:
            username = self.extract_username(text)
            if not username:
                await update.message.reply_text("❌ Username tidak valid!")
                return
            session['target'] = username
            session['step'] = 'count'
            await update.message.reply_text(
                f"<b>✅ Target: @{username}</b>\n\n"
                f"Berapa kali report? (max 15)",
                parse_mode='HTML'
            )
    
    async def process_count(self, update: Update, text: str, session_idx: int):
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        
        try:
            count = int(text.strip())
            if count <= 0 or count > 15:
                await update.message.reply_text("❌ Masukkan angka 1-15!")
                return
            session['count'] = count
            session['step'] = 'executing'
            await self.execute_report(update, session_idx)
        except:
            await update.message.reply_text("❌ Masukkan angka yang valid!")
    
    async def process_add_premium(self, update: Update, text: str, session_idx: int):
        user_id = update.effective_user.id
        target_text = text.strip()
        
        target_id = None
        
        if target_text.startswith('@'):
            username = target_text[1:]
            for uid in self.user_sessions:
                if str(uid) == username or (hasattr(uid, 'username') and uid.username == username):
                    target_id = uid
                    break
        else:
            try:
                target_id = int(target_text)
            except:
                pass
        
        if not target_id:
            await update.message.reply_text("❌ Gagal menemukan user! Kirim User ID angka.")
            return
        
        if target_id in self.premium_users:
            await update.message.reply_text(f"⚠️ User `{target_id}` sudah premium!", parse_mode='Markdown')
        else:
            self.premium_users.add(target_id)
            self.save_premium_users()
            
            try:
                await update.message.bot.send_message(
                    target_id,
                    f"<a href=\"{BANNER_URL}\"> </a>\n"
                    "<b><blockquote>🎉 SELAMAT!</blockquote></b>\n\n"
                    "<blockquote>Anda sekarang menjadi user PREMIUM!</blockquote>\n"
                    "<blockquote>Nikmati semua fitur tanpa batasan.</blockquote>",
                    parse_mode='HTML'
                )
            except:
                pass
            
            await update.message.reply_text(f"✅ User `{target_id}` ditambahkan ke premium!", parse_mode='Markdown')
        
        self.user_sessions[user_id][session_idx]['step'] = None
    
    async def process_remove_premium(self, update: Update, text: str, session_idx: int):
        user_id = update.effective_user.id
        
        try:
            target_id = int(text.strip())
            if target_id in self.premium_users:
                self.premium_users.remove(target_id)
                self.save_premium_users()
                
                try:
                    await update.message.bot.send_message(
                        target_id,
                        f"<a href=\"{BANNER_URL}\"> </a>\n"
                        "<b><blockquote>⚠️ PREMIUM EXPIRED</blockquote></b>\n\n"
                        "<blockquote>Status premium Anda telah dihapus.</blockquote>\n"
                        f"<blockquote>Beli lagi ke {config.PREMIUM_CONTACT} untuk akses.</blockquote>",
                        parse_mode='HTML'
                    )
                except:
                    pass
                
                await update.message.reply_text(f"✅ User `{target_id}` dihapus dari premium!", parse_mode='Markdown')
            else:
                await update.message.reply_text(f"⚠️ User `{target_id}` bukan user premium!", parse_mode='Markdown')
        except:
            await update.message.reply_text("❌ Kirim User ID angka yang valid!")
        
        self.user_sessions[user_id][session_idx]['step'] = None
    
    # ==================== LOGIN PROCESS ====================
    async def process_phone(self, update: Update, phone: str, session_idx: int):
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        
        try:
            if not phone.startswith('+'):
                phone = '+' + phone
            
            client = TelegramClient(session['session_name'], session['api_id'], session['api_hash'])
            await client.connect()
            await client.send_code_request(phone)
            
            session['client'] = client
            session['phone'] = phone
            session['step'] = 'verification_code'
            
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>📱 KODE DIKIRIM</blockquote></b>\n\n"
                "<blockquote>Kirim kode dari Telegram:</blockquote>",
                parse_mode='HTML'
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
            session['step'] = None
    
    async def process_code(self, update: Update, code: str, session_idx: int):
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        
        try:
            client = session['client']
            code = code.strip()
            
            try:
                await client.sign_in(session['phone'], code)
                session['logged_in'] = True
                session['step'] = None
                self.save_sessions()
                
                await update.message.reply_text(
                    f"<a href=\"{BANNER_URL}\"> </a>\n"
                    "<b><blockquote>✅ LOGIN BERHASIL</blockquote></b>\n\n"
                    f"<blockquote>Akun ke-{session_idx+1} tersimpan!</blockquote>",
                    parse_mode='HTML'
                )
                await self.show_main_menu(update)
                
            except SessionPasswordNeededError:
                session['step'] = '2fa_password'
                await update.message.reply_text(
                    f"<a href=\"{BANNER_URL}\"> </a>\n"
                    "<b><blockquote>🔐 PASSWORD 2FA</blockquote></b>\n\n"
                    "<blockquote>Kirim password 2FA:</blockquote>",
                    parse_mode='HTML'
                )
            except PhoneCodeInvalidError:
                await update.message.reply_text("❌ Kode salah!")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def process_2fa(self, update: Update, password: str, session_idx: int):
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        
        try:
            client = session['client']
            await client.sign_in(password=password.strip())
            
            session['logged_in'] = True
            session['step'] = None
            self.save_sessions()
            
            await update.message.reply_text(
                f"<a href=\"{BANNER_URL}\"> </a>\n"
                "<b><blockquote>✅ LOGIN BERHASIL</blockquote></b>\n\n"
                f"<blockquote>Akun ke-{session_idx+1} tersimpan!</blockquote>",
                parse_mode='HTML'
            )
            await self.show_main_menu(update)
        except Exception as e:
            await update.message.reply_text(f"❌ Password salah: {str(e)}")
    
    # ==================== EXECUTE REPORT (REAL - NO SIMULASI) ====================
    async def execute_report(self, update, session_idx: int = 0):
        user_id = update.effective_user.id
        main_session = self.user_sessions[user_id][session_idx]
        
        if user_id in self.active_reports:
            self.active_reports[user_id]['status'] = 'executing'
            self.active_reports[user_id]['target'] = main_session.get('target')
        
        logger.info(f"User {user_id} EXECUTING REPORT - Target: {main_session.get('target')}")
        
        # ==================== AMBIL SEMUA AKUN DARI SEMUA USER PREMIUM ====================
        all_accounts = self.get_all_active_accounts()
        
        if not all_accounts:
            await update.message.reply_text("❌ Tidak ada akun aktif dari semua user premium!")
            if user_id in self.active_reports:
                del self.active_reports[user_id]
            return
        
        total = len(all_accounts)
        per_account = main_session['count']
        report_type = main_session.get('type', 'channel').upper()
        
        target_display = f"@{main_session['target']}"
        if 'message_id' in main_session:
            target_display = f"https://t.me/{main_session['target']}/{main_session['message_id']}"
        
        start_time = datetime.now()
        
        await update.message.reply_text(
            f"<b><blockquote>🔄 BOT REPORT X8 DIMULAI (REAL - NO SIMULASI)</blockquote></b>\n\n"
            f"<blockquote>🌍 SEMUA AKUN PREMIUM: {total}</blockquote>\n"
            f"<blockquote>🎯 Target: {target_display}</blockquote>\n"
            f"<blockquote>📊 Report/akun: {per_account}</blockquote>\n"
            f"<blockquote>📈 Total: {total * per_account}</blockquote>\n\n"
            f"<blockquote>⏳ Proses...</blockquote>",
            parse_mode='HTML'
        )
        
        print("\n" + "="*70)
        print(f"🔴 BOT REPORT X8 (REAL) - {target_display}")
        print("="*70)
        print(f"👤 Initiated by: {user_id}")
        print(f"📅 Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"🌍 Total Akun Premium: {total}")
        print("="*70)
        
        success = 0
        failed = 0
        total_sent = 0
        error_details = []
        
        # Loop semua akun dari semua user premium
        for idx, (uid, acc_idx, acc_sess) in enumerate(all_accounts, 1):
            try:
                # Pastikan client connected
                if 'client' not in acc_sess:
                    success_reconnect = await self.reconnect_client(uid, acc_idx)
                    if not success_reconnect:
                        failed += 1
                        error_details.append(f"Akun {idx}: Gagal reconnect")
                        print(f"  ❌ Akun {idx}/{total} - Gagal reconnect")
                        continue
                
                client = acc_sess['client']
                if not client.is_connected():
                    await client.connect()
                
                if not await client.is_user_authorized():
                    failed += 1
                    error_details.append(f"Akun {idx}: Tidak authorized")
                    print(f"  ❌ Akun {idx}/{total} - Tidak authorized")
                    continue
                
                # Copy report data ke session
                acc_sess['target'] = main_session['target']
                if 'message_id' in main_session:
                    acc_sess['message_id'] = main_session['message_id']
                if 'category' in main_session:
                    acc_sess['category'] = main_session['category']
                if 'option' in main_session:
                    acc_sess['option'] = main_session['option']
                if 'use_custom' in main_session:
                    acc_sess['use_custom'] = main_session['use_custom']
                if 'account_option' in main_session:
                    acc_sess['account_option'] = main_session['account_option']
                if 'custom_message' in main_session:
                    acc_sess['custom_message'] = main_session['custom_message']
                acc_sess['type'] = main_session['type']
                acc_sess['count'] = main_session['count']
                
                phone = acc_sess.get('phone', 'Unknown')[:10] + "..."
                print(f"\n▶️ Akun {idx}/{total} - User {uid} - {phone}")
                
                # KIRIM REPORT REAL KE TELEGRAM
                sent = await self.report_real(uid, acc_sess, acc_idx)
                
                if sent > 0:
                    success += 1
                    total_sent += sent
                    print(f"  ✅ Berhasil: {sent} report REAL terkirim")
                else:
                    failed += 1
                    error_details.append(f"Akun {idx}: Gagal kirim report")
                    print(f"  ❌ Gagal - Tidak ada report terkirim")
                    
            except FloodWaitError as e:
                failed += 1
                error_details.append(f"Akun {idx}: Flood wait {e.seconds}s")
                print(f"  ⏳ Flood wait {e.seconds}s - Skip akun ini")
                await asyncio.sleep(e.seconds)
            except Exception as e:
                failed += 1
                error_details.append(f"Akun {idx}: {str(e)[:15]}")
                print(f"  ❌ Error: {str(e)[:15]}")
            
            # Delay antar akun untuk menghindari flood
            if idx < total:
                await asyncio.sleep(0.1)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        print("-"*70)
        print(f"✅ SELESAI - {total_sent} report REAL terkirim dari {total} akun")
        print("="*70)
        
        result_text = f"""
<b><blockquote>✅ MASS REPORT SELESAI (100% REAL)</blockquote></b>
<blockquote>🌍 Akun premium total: {total}</blockquote>
<blockquote>✅ Berhasil: {success} akun</blockquote>
<blockquote>❌ Gagal: {failed} akun</blockquote>
<blockquote>📨 Total report terkirim: {total_sent}</blockquote>
<blockquote>⏱️ Durasi: {duration:.1f} detik</blockquote>
<blockquote>🎯 Target: {target_display}</blockquote>
        """
        
        # Tambahkan detail error jika ada
        if error_details and len(error_details) <= 5:
            result_text += "\n<blockquote><b>📋 Detail Error:</b></blockquote>\n"
            for err in error_details[:5]:
                result_text += f"<blockquote>• {err}</blockquote>\n"
        
        back_callback = 'again_channel' if report_type == 'CHANNEL' else 'again_group' if report_type == 'GROUP' else 'again_account'
        keyboard = [
            [InlineKeyboardButton("🔄 Report Lagi", callback_data=back_callback)],
            [InlineKeyboardButton("🏠 Menu Utama", callback_data='back_to_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(result_text, reply_markup=reply_markup, parse_mode='HTML')
        
        if user_id in self.active_reports:
            del self.active_reports[user_id]
        
        main_session['step'] = None
    
    async def report_real(self, user_id: int, session, session_idx: int) -> int:
        """Report REAL ke Telegram - Tanpa Simulasi"""
        try:
            client = session['client']
            count = session['count']
            sent = 0
            
            if session['type'] in ['channel', 'group']:
                # Report channel/group
                entity = await client.get_entity(session['target'])
                
                # Dapatkan reason
                category = session.get('category')
                option = session.get('option', '1')
                cat_data = self.channel_reports.get(category)
                
                if cat_data and option in cat_data['options']:
                    opt_data = cat_data['options'][option]
                    reason = opt_data['reason']
                    if session.get('use_custom') and session.get('custom_message'):
                        message = session['custom_message']
                    else:
                        message = opt_data['default_message']
                else:
                    reason = types.InputReportReasonOther()
                    message = "Violates Telegram Terms"
                
                # Konversi ke peer
                if hasattr(entity, 'broadcast') and entity.broadcast:
                    peer = types.InputPeerChannel(channel_id=entity.id, access_hash=entity.access_hash)
                elif hasattr(entity, 'megagroup') and entity.megagroup:
                    peer = types.InputPeerChannel(channel_id=entity.id, access_hash=entity.access_hash)
                else:
                    peer = types.InputPeerChat(chat_id=entity.id)
                
                # KIRIM REPORT REAL KE TELEGRAM
                for i in range(count):
                    try:
                        result = await client(functions.account.ReportPeerRequest(
                            peer=peer, reason=reason, message=message
                        ))
                        if result:
                            sent += 1
                            print(f"    ✅ Report {i+1}/{count} terkirim REAL")
                        
                        # Report pesan spesifik jika ada message_id
                        if 'message_id' in session and i == 0:
                            try:
                                await client(functions.messages.ReportRequest(
                                    peer=entity, id=[session['message_id']], 
                                    reason=reason, message=message
                                ))
                                print(f"    ✅ Report message spesifik terkirim")
                            except Exception as e:
                                logger.error(f"Error reporting specific message: {e}")
                                
                    except FloodWaitError as e:
                        logger.warning(f"Flood wait {e.seconds}s")
                        print(f"    ⏳ Flood wait {e.seconds}s - menunggu...")
                        await asyncio.sleep(e.seconds)
                        i -= 1
                    except Exception as e:
                        logger.error(f"Report error: {e}")
                        print(f"    ❌ Error: {str(e)[:15]}")
                    
                    if i < count - 1:
                        await asyncio.sleep(0.1)
            
            else:
                # Report account (FOTO PROFIL)
                try:
                    user = await client.get_entity(session['target'])
                except Exception as e:
                    logger.error(f"Error getting user entity: {e}")
                    print(f"    ❌ Gagal dapat user entity: {e}")
                    return 0
                    
                peer = types.InputPeerUser(user_id=user.id, access_hash=user.access_hash)
                
                option = session.get('account_option', 'Spam')
                acc_data = self.account_reports.get(option, self.account_reports['Spam'])
                reason = acc_data['reason']
                
                # KIRIM REPORT REAL KE TELEGRAM untuk foto profil
                for i in range(count):
                    try:
                        if option == "Lainnya" and session.get('custom_message'):
                            result = await client(functions.account.ReportPeerRequest(
                                peer=peer, reason=reason, message=f"Profile picture violation: {session['custom_message']}"
                            ))
                        else:
                            result = await client(functions.account.ReportPeerRequest(
                                peer=peer, reason=reason, message=f"This account's profile picture violates Telegram Terms of Service regarding {acc_data['name']}"
                            ))
                        
                        if result:
                            sent += 1
                            print(f"    ✅ Report foto profil {i+1}/{count} terkirim REAL")
                            
                    except FloodWaitError as e:
                        logger.warning(f"Flood wait {e.seconds}s")
                        print(f"    ⏳ Flood wait {e.seconds}s - menunggu...")
                        await asyncio.sleep(e.seconds)
                        i -= 1
                    except Exception as e:
                        logger.error(f"Report error: {e}")
                        print(f"    ❌ Error: {str(e)[:15]}")
                    
                    if i < count - 1:
                        await asyncio.sleep(0.1)
            
            return sent
            
        except Exception as e:
            logger.error(f"Report error for session {session_idx}: {e}")
            print(f"  ❌ Fatal error: {str(e)[:100]}")
            return 0
    
    # ==================== REPORT STORY ====================
    # Alasan utama & sub-alasan persis seperti UI Telegram asli
    STORY_REASONS = {
        "i_dont_like_it": {
            "label": "👎 I don't like it",
            "sub": {},
            "reason": None,  # reason_key tanpa sub
            "message": "I don't like this story."
        },
        "child_abuse": {
            "label": "⚠️ Child abuse",
            "sub": {
                "child_sexual_abuse": ("Child sexual abuse", "This story contains child sexual abuse content."),
                "child_physical_abuse": ("Child physical abuse", "This story contains child physical abuse content."),
            },
            "reason": None,
            "message": "This story contains child abuse."
        },
        "violence": {
            "label": "💥 Violence",
            "sub": {
                "graphic_disturbing": ("Graphic or disturbing content", "This story contains graphic or disturbing content."),
                "extreme_violence": ("Extreme violence, dismemberment", "This story contains extreme violence."),
                "hate_speech": ("Hate speech or symbols", "This story contains hate speech."),
                "calling_violence": ("Calling for violence", "This story calls for violence."),
                "terrorism": ("Terrorism", "This story contains terrorism content."),
                "animal_abuse": ("Animal abuse", "This story contains animal abuse."),
            },
            "reason": None,
            "message": "This story contains violent content."
        },
        "illegal_goods": {
            "label": "📦 Illegal goods and services",
            "sub": {
                "weapons": ("Weapons", "This story promotes illegal weapons."),
                "drugs": ("Drugs", "This story promotes illegal drugs."),
                "fake_documents": ("Fake documents", "This story promotes fake documents."),
                "hacking_tools": ("Hacking tools and malware", "This story promotes hacking tools."),
                "other_illegal": ("Other goods and services", "This story promotes other illegal goods/services."),
            },
            "reason": None,
            "message": "This story promotes illegal goods/services."
        },
        "illegal_adult_content": {
            "label": "🔞 Illegal adult content",
            "sub": {
                "child_abuse_sexual": ("Child abuse", "This story contains child sexual abuse."),
                "illegal_sexual_services": ("Illegal sexual services", "This story promotes illegal sexual services."),
                "animal_abuse_sexual": ("Animal abuse", "This story contains animal sexual abuse."),
                "non_consensual": ("Non-consensual sexual imagery", "This story contains non-consensual sexual imagery."),
                "pornography": ("Pornography", "This story contains pornographic content."),
                "other_sexual": ("Other illegal sexual content", "This story contains other illegal sexual content."),
            },
            "reason": None,
            "message": "This story contains illegal adult content."
        },
        "personal_data": {
            "label": "🆔 Personal data",
            "sub": {
                "private_images": ("Private images", "This story contains private images."),
                "phone_number": ("Phone number", "This story contains private phone numbers."),
                "address": ("Address", "This story contains residential addresses."),
                "stolen_data": ("Stolen data or credentials", "This story contains stolen data."),
                "other_personal": ("Other personal information", "This story contains other personal information."),
            },
            "reason": None,
            "message": "This story contains personal data."
        },
        "scam_fraud": {
            "label": "⚠️ Scam or fraud",
            "sub": {
                "impersonation": ("Impersonation", "This story is impersonating someone."),
                "financial_scam": ("Deceptive or unrealistic financial claims", "This story makes deceptive financial claims."),
                "malware_phishing": ("Malware, phishing", "This story contains malware or phishing."),
                "fraudulent_seller": ("Fraudulent seller, product or service", "This story is a fraudulent seller."),
            },
            "reason": None,
            "message": "This story is a scam or fraud."
        },
        "copyright": {
            "label": "© Copyright",
            "sub": {},
            "reason": None,
            "message": "This story violates copyright."
        },
        "spam": {
            "label": "🚫 Spam",
            "sub": {},
            "reason": None,
            "message": "This story is spam."
        },
        "other": {
            "label": "❗ Other",
            "sub": {},
            "reason": None,
            "message": "This story violates Telegram Terms of Service."
        },
        "not_illegal_must_down": {
            "label": "🔴 Not illegal, but must be taken down",
            "sub": {},
            "reason": None,
            "message": "This story must be taken down."
        },
    }

    def _story_reason_obj(self, reason_key: str, sub_key: str = None):
        """Mapping reason_key → Telethon InputReportReason"""
        MAP = {
            "i_dont_like_it": types.InputReportReasonOther(),
            "child_abuse": types.InputReportReasonChildAbuse(),
            "violence": types.InputReportReasonViolence(),
            "illegal_goods": types.InputReportReasonIllegalDrugs(),
            "illegal_adult_content": types.InputReportReasonPornography(),
            "personal_data": types.InputReportReasonPersonalDetails(),
            "scam_fraud": types.InputReportReasonFake(),
            "copyright": types.InputReportReasonCopyright(),
            "spam": types.InputReportReasonSpam(),
            "other": types.InputReportReasonOther(),
            "not_illegal_must_down": types.InputReportReasonOther(),
        }
        return MAP.get(reason_key, types.InputReportReasonOther())

    async def start_story_report(self, query):
        """Step 1: Pilih tipe target story (Public / Private)"""
        user_id = query.from_user.id
        if user_id not in self.user_sessions or not self.user_sessions[user_id]:
            await query.edit_message_text("❌ Belum ada akun login! Silakan tambah akun dulu.")
            return
        keyboard = [
            [InlineKeyboardButton("🌐 Public (Link Story t.me/user/s/123 atau @username)", callback_data='story_type_public')],
            [InlineKeyboardButton("🔒 Private (2 Link: Join Link + Link Story)", callback_data='story_type_private')],
            [InlineKeyboardButton("↩️ Kembali", callback_data='back_to_menu')],
        ]
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>📖 PILIH TIPE TARGET STORY:</blockquote></b>",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    async def story_input_public(self, query):
        """Step 2a: Minta link story public"""
        user_id = query.from_user.id
        self.user_sessions[user_id][0]['story_type'] = 'public'
        self.user_sessions[user_id][0]['step'] = 'story_input_public'
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>📖 INPUT TARGET STORY PUBLIC</blockquote></b>\n\n"
            "<blockquote>Kirim <b>Link Story</b> (https://t.me/username/s/123)\n"
            "atau kirim <b>@username</b> target:</blockquote>\n\n"
            "<code>Contoh: https://t.me/cik_ranisya/s/10</code>\n"
            "<code>Atau: @cik_ranisya</code>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ Kembali", callback_data='report_story')]]),
            parse_mode='HTML'
        )

    async def story_input_private(self, query):
        """Step 2b: Minta join link untuk private story"""
        user_id = query.from_user.id
        self.user_sessions[user_id][0]['story_type'] = 'private'
        self.user_sessions[user_id][0]['step'] = 'story_input_join_link'
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🔒 INPUT STORY PRIVATE — STEP 1/2</blockquote></b>\n\n"
            "<blockquote>Kirim <b>Join Link</b> channel/user private target:\n"
            "Contoh: <code>https://t.me/+AbcXyz123</code></blockquote>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ Kembali", callback_data='report_story')]]),
            parse_mode='HTML'
        )

    async def story_process_public_target(self, update, text: str, session_idx: int):
        """Proses link story public → extract username + story_id"""
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        text = text.strip()

        # Parse: https://t.me/username/s/123 atau @username
        import re
        m = re.match(r'https?://t\.me/([^/]+)/s/(\d+)', text)
        if m:
            username, story_id = m.group(1), int(m.group(2))
        else:
            username = self.extract_username(text)
            story_id = None

        if not username:
            await update.message.reply_text("❌ Link tidak valid! Kirim link story atau @username.")
            return

        session['story_username'] = username
        session['story_id'] = story_id
        session['step'] = None

        target_label = f"https://t.me/{username}/s/{story_id}" if story_id else f"@{username}"
        await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"✅ <b>Target Story:</b> {target_label}\n\n",
            parse_mode='HTML'
        )
        # Langsung minta pilih alasan
        await self._story_show_reasons(update, user_id)

    async def story_process_join_link(self, update, text: str, session_idx: int):
        """Proses join link private story"""
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        session['story_join_link'] = text.strip()
        session['step'] = 'story_input_private_link'
        await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🔒 INPUT STORY PRIVATE — STEP 2/2</blockquote></b>\n\n"
            "<blockquote>Kirim <b>Link Story</b>:\n"
            "Contoh: <code>https://t.me/username/s/10</code></blockquote>",
            parse_mode='HTML'
        )

    async def story_process_private_link(self, update, text: str, session_idx: int):
        """Proses link story private → simpan, lanjut ke alasan"""
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        import re
        m = re.match(r'https?://t\.me/([^/]+)/s/(\d+)', text.strip())
        if m:
            session['story_username'] = m.group(1)
            session['story_id'] = int(m.group(2))
        else:
            session['story_username'] = self.extract_username(text)
            session['story_id'] = None
        session['step'] = None
        await update.message.reply_text(
            f"✅ Join link + Story link tersimpan.\n",
            parse_mode='HTML'
        )
        await self._story_show_reasons(update, user_id)

    async def _story_show_reasons(self, update, user_id: int):
        """Tampilkan pilihan alasan report story (3 level)"""
        rows = []
        keys = list(self.STORY_REASONS.keys())
        for i in range(0, len(keys), 2):
            row = [InlineKeyboardButton(self.STORY_REASONS[keys[i]]['label'], callback_data=f'story_reason_{keys[i]}')]
            if i + 1 < len(keys):
                row.append(InlineKeyboardButton(self.STORY_REASONS[keys[i+1]]['label'], callback_data=f'story_reason_{keys[i+1]}'))
            rows.append(row)
        rows.append([InlineKeyboardButton("❌ Batal", callback_data='story_cancel')])
        await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>⚠️ PILIH ALASAN REPORT STORY (3 LEVEL):</blockquote></b>",
            reply_markup=InlineKeyboardMarkup(rows),
            parse_mode='HTML'
        )

    async def story_show_subreason(self, query, reason_key: str):
        """Step 3: Tampilkan sub-alasan jika ada"""
        user_id = query.from_user.id
        r = self.STORY_REASONS.get(reason_key)
        if not r:
            await query.answer("❌ Alasan tidak valid", show_alert=True)
            return
        self.user_sessions[user_id][0]['story_reason_key'] = reason_key

        if not r['sub']:
            # Tidak ada sub → langsung simpan, minta comment
            self.user_sessions[user_id][0]['story_sub_key'] = None
            self.user_sessions[user_id][0]['story_message'] = r['message']
            await self._story_ask_comment(query)
            return

        rows = []
        for sub_key, (sub_label, _) in r['sub'].items():
            rows.append([InlineKeyboardButton(sub_label, callback_data=f'story_sub_{reason_key}|{sub_key}')])
        rows.append([InlineKeyboardButton("↩️ Kembali", callback_data='report_story')])
        rows.append([InlineKeyboardButton("❌ Batal", callback_data='story_cancel')])
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b><blockquote>⚠️ {r['label']}</blockquote></b>\n\n"
            "<blockquote>Pilih sub-kategori:</blockquote>",
            reply_markup=InlineKeyboardMarkup(rows),
            parse_mode='HTML'
        )

    async def story_select_subreason(self, query, reason_key: str, sub_key: str):
        """Step 4: Sub-alasan dipilih → simpan"""
        user_id = query.from_user.id
        r = self.STORY_REASONS.get(reason_key)
        if not r or sub_key not in r['sub']:
            await query.answer("❌ Sub-alasan tidak valid", show_alert=True)
            return
        sub_label, sub_message = r['sub'][sub_key]
        self.user_sessions[user_id][0]['story_sub_key'] = sub_key
        self.user_sessions[user_id][0]['story_message'] = sub_message
        await self._story_ask_comment(query)

    async def _story_ask_comment(self, query):
        """Step 5: Tanya komentar/teks laporan — bisa skip atau custom"""
        keyboard = [
            [InlineKeyboardButton("✏️ Kirim Komentar Custom", callback_data='story_custom_comment')],
            [InlineKeyboardButton("⏭️ Skip (Pakai Default)", callback_data='story_quota_10')],
            [InlineKeyboardButton("❌ Batal", callback_data='story_cancel')],
        ]
        user_id = query.from_user.id
        r_key = self.user_sessions[user_id][0].get('story_reason_key', '')
        s_key = self.user_sessions[user_id][0].get('story_sub_key', '')
        alasan_label = self.STORY_REASONS.get(r_key, {}).get('label', '-')
        sub_data = self.STORY_REASONS.get(r_key, {}).get('sub', {}).get(s_key, (s_key, ''))[0] if s_key else ''
        alasan_text = f"{alasan_label}" + (f" → {sub_data}" if sub_data else "")
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b><blockquote>⚠️ Alasan: {alasan_text}</blockquote></b>\n\n"
            "<b><blockquote>✏️ KIRIM KOMENTAR / TEKS LAPORAN:</blockquote></b>\n"
            "<blockquote><i>*(Ketik teks alasan detail pelanggaran)*</i></blockquote>",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    async def story_ask_custom_comment(self, query):
        """Step 5b: Minta user ketik comment"""
        user_id = query.from_user.id
        self.user_sessions[user_id][0]['step'] = 'story_input_custom_comment'
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>✏️ KIRIM KOMENTAR / TEKS LAPORAN</blockquote></b>\n\n"
            "<blockquote>Ketik teks komentar laporan kamu:</blockquote>",
            parse_mode='HTML'
        )

    async def story_process_custom_comment(self, update, text: str, session_idx: int):
        """Simpan comment → minta kuota"""
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        session['story_message'] = text.strip()
        session['step'] = None
        await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            f"<b>✏️ Komentar tersimpan ({len(text)} char).</b>",
            parse_mode='HTML'
        )
        await self._story_ask_quota_msg(update)

    async def story_set_quota(self, query, quota_val: str):
        """Step 6: Pilih kuota dari tombol"""
        user_id = query.from_user.id
        try:
            quota = int(quota_val)
        except ValueError:
            await query.answer("❌ Kuota tidak valid", show_alert=True)
            return
        self.user_sessions[user_id][0]['story_quota'] = quota
        await self._story_confirm(query, user_id)

    async def story_ask_manual_quota(self, query):
        """Step 6b: Minta user ketik kuota manual"""
        user_id = query.from_user.id
        self.user_sessions[user_id][0]['step'] = 'story_input_manual_quota'
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>✏️ Input Angka Kuota Report:</blockquote></b>\n\n"
            "<blockquote>Ketik jumlah report (maks 15 per akun):</blockquote>",
            parse_mode='HTML'
        )

    async def story_process_manual_quota(self, update, text: str, session_idx: int):
        user_id = update.effective_user.id
        session = self.user_sessions[user_id][session_idx]
        try:
            quota = int(text.strip())
            if quota <= 0 or quota > 250:
                raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Angka tidak valid (1-250)")
            return
        session['story_quota'] = quota
        session['step'] = None
        await self._story_confirm_msg(update, user_id)

    async def _story_ask_quota_msg(self, update):
        """Tampilkan pilihan kuota via message"""
        keyboard = [
            [InlineKeyboardButton("10x", callback_data='story_quota_10'),
             InlineKeyboardButton("25x", callback_data='story_quota_25'),
             InlineKeyboardButton("50x", callback_data='story_quota_50')],
            [InlineKeyboardButton("100x", callback_data='story_quota_100'),
             InlineKeyboardButton("250x", callback_data='story_quota_250'),
             InlineKeyboardButton("✏️ Input Angka", callback_data='story_quota_manual')],
            [InlineKeyboardButton("❌ Batal", callback_data='story_cancel')],
        ]
        await update.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🔢 Pilih Kuota Laporan:</blockquote></b>",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    async def _story_confirm(self, query, user_id: int):
        """Step 7: Konfirmasi sebelum eksekusi"""
        sess = self.user_sessions[user_id][0]
        r_key = sess.get('story_reason_key', '-')
        s_key = sess.get('story_sub_key', '')
        r_label = self.STORY_REASONS.get(r_key, {}).get('label', '-')
        sub_label = self.STORY_REASONS.get(r_key, {}).get('sub', {}).get(s_key, (s_key,))[0] if s_key else ''
        alasan_text = r_label + (f" → {sub_label}" if sub_label else '')
        story_type = sess.get('story_type', 'public')
        username = sess.get('story_username', '-')
        story_id = sess.get('story_id')
        target_label = f"https://t.me/{username}/s/{story_id}" if story_id else f"@{username}"
        quota = sess.get('story_quota', 10)
        msg = sess.get('story_message', '-')
        mode = "🎯 Gabungan (All Access)"
        all_acc = self.get_all_active_accounts()
        sender_count = len(all_acc)
        comment_preview = (msg[:80] + '...') if len(msg) > 80 else msg
        text = (
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>📋 KONFIRMASI REPORT STORY</blockquote></b>\n\n"
            f"<blockquote>⚙️ Mode   : {mode}</blockquote>\n"
            f"<blockquote>📌 Tipe   : Story {'Public' if story_type == 'public' else 'Private'}</blockquote>\n"
            f"<blockquote>🎯 Target : {target_label}</blockquote>\n"
            f"<blockquote>⚠️ Alasan : {alasan_text}</blockquote>\n"
            f"<blockquote>✏️ Komentar: {comment_preview}</blockquote>\n"
            f"<blockquote>🔢 Kuota  : {quota}x</blockquote>\n"
            f"<blockquote>📱 Sender : {sender_count} akun aktif</blockquote>\n\n"
            "<i>_Klik ✅ EKSEKUSI SEKARANG untuk memulai._</i>"
        )
        keyboard = [
            [InlineKeyboardButton("✅ EKSEKUSI SEKARANG", callback_data='story_execute')],
            [InlineKeyboardButton("❌ BATAL", callback_data='story_cancel')],
        ]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')

    async def _story_confirm_msg(self, update, user_id: int):
        """Konfirmasi via message"""
        sess = self.user_sessions[user_id][0]
        r_key = sess.get('story_reason_key', '-')
        s_key = sess.get('story_sub_key', '')
        r_label = self.STORY_REASONS.get(r_key, {}).get('label', '-')
        sub_label = self.STORY_REASONS.get(r_key, {}).get('sub', {}).get(s_key, (s_key,))[0] if s_key else ''
        alasan_text = r_label + (f" → {sub_label}" if sub_label else '')
        story_type = sess.get('story_type', 'public')
        username = sess.get('story_username', '-')
        story_id = sess.get('story_id')
        target_label = f"https://t.me/{username}/s/{story_id}" if story_id else f"@{username}"
        quota = sess.get('story_quota', 10)
        msg = sess.get('story_message', '-')
        all_acc = self.get_all_active_accounts()
        sender_count = len(all_acc)
        comment_preview = (msg[:80] + '...') if len(msg) > 80 else msg
        text = (
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>📋 KONFIRMASI REPORT STORY</blockquote></b>\n\n"
            f"<blockquote>⚙️ Mode   : 🎯 Gabungan (All Access)</blockquote>\n"
            f"<blockquote>📌 Tipe   : Story {'Public' if story_type == 'public' else 'Private'}</blockquote>\n"
            f"<blockquote>🎯 Target : {target_label}</blockquote>\n"
            f"<blockquote>⚠️ Alasan : {alasan_text}</blockquote>\n"
            f"<blockquote>✏️ Komentar: {comment_preview}</blockquote>\n"
            f"<blockquote>🔢 Kuota  : {quota}x</blockquote>\n"
            f"<blockquote>📱 Sender : {sender_count} akun aktif</blockquote>\n\n"
            "<i>_Klik ✅ EKSEKUSI SEKARANG untuk memulai._</i>"
        )
        keyboard = [
            [InlineKeyboardButton("✅ EKSEKUSI SEKARANG", callback_data='story_execute')],
            [InlineKeyboardButton("❌ BATAL", callback_data='story_cancel')],
        ]
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')

    async def story_execute(self, query):
        """Step 8: Eksekusi mass report story ke Telegram"""
        user_id = query.from_user.id
        sess = self.user_sessions[user_id][0]
        r_key = sess.get('story_reason_key', 'other')
        s_key = sess.get('story_sub_key', '')
        r_label = self.STORY_REASONS.get(r_key, {}).get('label', '-')
        sub_label = self.STORY_REASONS.get(r_key, {}).get('sub', {}).get(s_key, (s_key,))[0] if s_key else ''
        alasan_text = r_label + (f" → {sub_label}" if sub_label else '')
        username = sess.get('story_username', '')
        story_id = sess.get('story_id')
        quota = sess.get('story_quota', 10)
        message_text = sess.get('story_message', 'This story violates Telegram Terms of Service.')
        join_link = sess.get('story_join_link')
        reason_obj = self._story_reason_obj(r_key, s_key)
        target_label = f"https://t.me/{username}/s/{story_id}" if story_id else f"@{username}"

        all_accounts = self.get_all_active_accounts()
        total = len(all_accounts)

        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>🚀 STORY GABUNGAN (ALL)</blockquote></b>\n\n"
            f"<blockquote>🎯 Target: {target_label}</blockquote>\n"
            f"<blockquote>🆔 Detail ID: {username}" + (f" (Story: {story_id})" if story_id else "") + f"</blockquote>\n"
            f"<blockquote>📌 STORY_{'PUBLIC' if sess.get('story_type') == 'public' else 'PRIVATE'} | ⚠️ {alasan_text}</blockquote>\n"
            f"<blockquote>🔢 Kuota: {quota}x | 📱 Akun: {total}</blockquote>\n\n"
            f"<blockquote>━━━━━━━━━━━━━━━━━━━━</blockquote>\n"
            f"<blockquote>[0/{quota}]</blockquote>\n"
            f"<blockquote>✅ 0 | ❌ 0</blockquote>\n"
            f"<blockquote>⏱️ ETA: 0s</blockquote>\n\n"
            f"<blockquote>⏳ Loading {total} sender...</blockquote>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔴 CANCEL / HENTIKAN PROSES", callback_data='story_cancel')]]),
            parse_mode='HTML'
        )

        success = failed = total_sent = 0
        start_time = datetime.now()

        for idx, (uid, acc_idx, acc_sess) in enumerate(all_accounts, 1):
            try:
                if 'client' not in acc_sess:
                    ok = await self.reconnect_client(uid, acc_idx)
                    if not ok:
                        failed += 1
                        continue

                client = acc_sess['client']
                if not client.is_connected():
                    await client.connect()
                if not await client.is_user_authorized():
                    failed += 1
                    continue

                # Join private channel dulu jika ada join_link
                if join_link:
                    try:
                        await client(functions.messages.ImportChatInviteRequest(join_link.split('+')[-1]))
                    except Exception:
                        pass

                # Dapatkan entity target story
                try:
                    entity = await client.get_entity(username)
                except Exception as e:
                    logger.error(f"Story report: gagal get entity {username}: {e}")
                    failed += 1
                    continue

                # Kirim report story
                for i in range(quota):
                    try:
                        if story_id:
                            # Report story spesifik by story_id
                            await client(functions.account.ReportRequest(
                                peer=entity,
                                id=[story_id],
                                reason=reason_obj,
                                message=message_text
                            ))
                        else:
                            # Report user secara keseluruhan jika hanya @username
                            if hasattr(entity, 'id') and hasattr(entity, 'access_hash'):
                                peer = types.InputPeerUser(user_id=entity.id, access_hash=entity.access_hash)
                            else:
                                peer = entity
                            await client(functions.account.ReportPeerRequest(
                                peer=peer,
                                reason=reason_obj,
                                message=message_text
                            ))
                        total_sent += 1
                    except FloodWaitError as e:
                        await asyncio.sleep(e.seconds)
                    except Exception as e:
                        logger.error(f"Story report error akun {idx}: {e}")
                        break

                if total_sent > 0:
                    success += 1
                else:
                    failed += 1

            except Exception as e:
                failed += 1
                logger.error(f"Story execute error akun {idx}: {e}")

            await asyncio.sleep(0.1)

        duration = (datetime.now() - start_time).total_seconds()
        await query.message.reply_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>✅ MASS REPORT STORY SELESAI (100% REAL)</blockquote></b>\n\n"
            f"<blockquote>🎯 Target: {target_label}</blockquote>\n"
            f"<blockquote>⚠️ Alasan: {alasan_text}</blockquote>\n"
            f"<blockquote>📱 Total Akun: {total}</blockquote>\n"
            f"<blockquote>✅ Berhasil: {success} akun</blockquote>\n"
            f"<blockquote>❌ Gagal: {failed} akun</blockquote>\n"
            f"<blockquote>📨 Total Report Terkirim: {total_sent}</blockquote>\n"
            f"<blockquote>⏱️ Durasi: {duration:.1f} detik</blockquote>",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Report Story Lagi", callback_data='report_story')],
                [InlineKeyboardButton("🏠 Menu Utama", callback_data='back_to_menu')],
            ]),
            parse_mode='HTML'
        )

    # ==================== END REPORT STORY ====================

    async def report_again(self, query, report_type):
        if report_type == 'channel':
            await self.start_channel_report(query, 'channel')
        elif report_type == 'group':
            await self.start_channel_report(query, 'group')
        else:
            await self.start_account_report(query)
    
    # ==================== OWNER PANEL ====================
    async def show_owner_panel(self, query):
        keyboard = [
            [InlineKeyboardButton("➕ Add Premium", callback_data='add_premium')],
            [InlineKeyboardButton("➖ Remove Premium", callback_data='remove_premium')],
            [InlineKeyboardButton("📋 List Premium", callback_data='list_premium')],
            [InlineKeyboardButton("📦 Backup", callback_data='backup_now')],
            [InlineKeyboardButton("📊 Stats", callback_data='stats')],
            [InlineKeyboardButton("🔙 Back", callback_data='back_to_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        total_sessions = sum(len(sessions) for sessions in self.user_sessions.values())
        total_all_accounts = len(self.get_all_active_accounts())
        
        text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>👑 OWNER PANEL</blockquote></b>
<blockquote>💎 Premium: {len(self.premium_users)}</blockquote>
<blockquote>👥 Total Sessions: {total_sessions}</blockquote>
<blockquote>🌍 Total Akun Premium: {total_all_accounts}</blockquote>
<blockquote>👤 Users: {len(self.user_sessions)}</blockquote>
<blockquote>🔄 Active Reports: {len(self.active_reports)}</blockquote>
        """
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='HTML')
    
    async def show_stats(self, query):
        user_id = query.from_user.id
        if not self.is_owner(user_id):
            return
        
        total_sessions = sum(len(sessions) for sessions in self.user_sessions.values())
        total_all_accounts = len(self.get_all_active_accounts())
        
        text = f"""
<a href=\"{BANNER_URL}\"> </a>
<b><blockquote>📊 STATISTIK LENGKAP</blockquote></b>
<blockquote><b>👥 PREMIUM USERS: {len(self.premium_users)}</b></blockquote>
<blockquote><b>🌍 TOTAL AKUN PREMIUM: {total_all_accounts}</b></blockquote>
<blockquote><b>📱 TOTAL SESSIONS: {total_sessions}</b></blockquote>
<blockquote><b>👤 TOTAL USERS: {len(self.user_sessions)}</b></blockquote>
<blockquote><b>🔄 ACTIVE REPORTS: {len(self.active_reports)}</b></blockquote>

<blockquote><b>⚙️ KONFIGURASI:</b></blockquote>
<blockquote>├ 💎 Harga Premium: {config.PREMIUM_PRICE}</blockquote>
<blockquote>└ 📞 Kontak: {config.PREMIUM_CONTACT}</blockquote>
        """
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data='back_to_owner')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='HTML')
    
    async def add_premium_panel(self, query):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = [{'step': 'waiting_add_premium'}]
        else:
            self.user_sessions[user_id][0]['step'] = 'waiting_add_premium'
        
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>➕ ADD PREMIUM</blockquote></b>\n\n"
            "<blockquote>Kirim User ID atau username:</blockquote>\n"
            "<code>Contoh: 1234567890</code>\n"
            "<code>atau: @username</code>",
            parse_mode='HTML'
        )
    
    async def remove_premium_panel(self, query):
        user_id = query.from_user.id
        
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = [{'step': 'waiting_remove_premium'}]
        else:
            self.user_sessions[user_id][0]['step'] = 'waiting_remove_premium'
        
        await query.edit_message_text(
            f"<a href=\"{BANNER_URL}\"> </a>\n"
            "<b><blockquote>➖ REMOVE PREMIUM</blockquote></b>\n\n"
            "<blockquote>Kirim User ID:</blockquote>",
            parse_mode='HTML'
        )
    
    async def list_premium_panel(self, query):
        if not self.premium_users:
            text = f"<a href=\"{BANNER_URL}\"> </a>\n<b><blockquote>📋 PREMIUM USERS</blockquote></b>\n\n<blockquote>❌ Kosong</blockquote>"
        else:
            premium_list = "\n".join([f"<blockquote>• <code>{uid}</code></blockquote>" for uid in self.premium_users])
            text = f"<a href=\"{BANNER_URL}\"> </a>\n<b><blockquote>📋 PREMIUM USERS ({len(self.premium_users)})</blockquote></b>\n\n{premium_list}"
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data='back_to_owner')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='HTML')
    
    async def backup_files(self, query):
        try:
            backup_dir = "backups"
            os.makedirs(backup_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            zip_filename = f"{backup_dir}/backup_{timestamp}.zip"
            
            with zipfile.ZipFile(zip_filename, 'w') as zipf:
                files_to_backup = [config.SESSIONS_FILE, config.PREMIUM_USERS_FILE, "config.py"]
                for file in files_to_backup:
                    if os.path.exists(file):
                        zipf.write(file, arcname=os.path.basename(file))
                
                # Backup semua session files
                for file in os.listdir('.'):
                    if file.endswith('.session'):
                        zipf.write(file, arcname=file)
            
            await query.message.reply_document(
                document=open(zip_filename, 'rb'),
                filename=f"backup_{timestamp}.zip",
                caption=f"✅ Backup {timestamp}"
            )
            
            os.remove(zip_filename)
            
        except Exception as e:
            logger.error(f"Backup error: {e}")
            await query.edit_message_text(f"❌ Gagal: {e}")
        
        await self.show_owner_panel(query)
    
    # ==================== RUN BOT ====================
    def run(self):
        app = Application.builder().token(self.token).build()
        app.add_handler(CommandHandler("start", self.start))
        app.add_handler(CommandHandler("cekacc", self.cek_acc))
        app.add_handler(CommandHandler("broadcast", self.broadcast))
        app.add_handler(CommandHandler("addprem", self.add_premium_command))
        app.add_handler(CommandHandler("listprem", self.list_premium_command))
        app.add_handler(CommandHandler("delprem", self.del_premium_command))
        app.add_handler(CallbackQueryHandler(self.button_handler))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.message_handler))
        
        print("\n" + "="*70)
        print("🔥 BOT REPORT X8 ")
        print("="*70)
        print(f"📅 Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"💎 Premium Users: {len(self.premium_users)}")
        print(f"👥 Total Sessions: {sum(len(s) for s in self.user_sessions.values())}")
        print(f"👤 Registered Users: {len(self.user_sessions)}")
        print(f"🌍 Total Active Accounts: {len(self.get_all_active_accounts())}")
        print(f"🔴 FITUR: /cekacc | /broadcast | /addprem | /listprem | /delprem")
        print(f"💎 HARGA: {config.PREMIUM_PRICE}")
        print(f"⚠️ MODE: 100% REAL REPORT - TANPA SIMULASI!")
        print("="*70 + "\n")
        
        app.run_polling()

if __name__ == "__main__":
    if config.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ Isi BOT_TOKEN di config.py dulu!")
        exit(1)
    
    bot = TelegramReporterBot(config.BOT_TOKEN)
    bot.run()